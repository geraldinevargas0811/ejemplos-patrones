package co.edu.udistrital.model;

public class ReporteBasico implements Reporte {
    private String estudiante;
    private double promedio;

    public ReporteBasico(String estudiante, double promedio) {
        this.estudiante = estudiante;
        this.promedio = promedio;
    }

    @Override
    public String generar() {
        return "Estudiante: " + estudiante + "\nPromedio: " + promedio;
    }
}

