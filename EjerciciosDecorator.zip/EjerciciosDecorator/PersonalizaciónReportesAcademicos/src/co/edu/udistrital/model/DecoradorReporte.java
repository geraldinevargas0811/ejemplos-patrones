package co.edu.udistrital.model;

public abstract class DecoradorReporte implements Reporte {
    protected Reporte base;

    public DecoradorReporte(Reporte base) {
        this.base = base;
    }

    @Override
    public String generar() {
        return base.generar();
    }
}
