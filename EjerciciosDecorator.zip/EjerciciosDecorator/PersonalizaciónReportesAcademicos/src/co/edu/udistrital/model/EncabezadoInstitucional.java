package co.edu.udistrital.model;

public class EncabezadoInstitucional extends DecoradorReporte {

    public EncabezadoInstitucional(Reporte base) {
        super(base);
    }

    @Override
    public String generar() {
        return "UNIVERSIDAD DISTRITAL FRANCISCO JOSÉ DE CALDAS\nFacultad de Ingeniería\n\n" + base.generar();
    }
}

