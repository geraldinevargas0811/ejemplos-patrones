package co.edu.udistrital.model;

public class EnHTML extends DecoradorReporte {

    public EnHTML(Reporte base) {
        super(base);
    }

    @Override
    public String generar() {
        return "<html><body><pre>" + base.generar() + "</pre></body></html>";
    }
}
