package co.edu.udistrital.model;

public class PieLegal extends DecoradorReporte {

    public PieLegal(Reporte base) {
        super(base);
    }

    @Override
    public String generar() {
        return base.generar() + "\n\nEste reporte es confidencial. No divulgar sin autorización.";
    }
}
