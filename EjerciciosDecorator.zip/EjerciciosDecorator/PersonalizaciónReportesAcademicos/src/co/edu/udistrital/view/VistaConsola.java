package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarReporte(String texto) {
        System.out.println("-----Reporte Académico-----");
        System.out.println(texto);
    }
}
