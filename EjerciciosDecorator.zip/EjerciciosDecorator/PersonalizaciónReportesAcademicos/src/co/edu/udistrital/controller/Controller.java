package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Reporte reporte = new ReporteBasico("Geraldine Vargas", 4.5);

        reporte = new EncabezadoInstitucional(reporte);
        reporte = new PieLegal(reporte);
        reporte = new EnHTML(reporte);

        vista.mostrarReporte(reporte.generar());
    }
}

