package co.edu.udistrital.view;

public class VistaConsola {
	
	public void mostrarMensaje(String mensaje) {
        System.out.println("[Notificación]");
        System.out.println(mensaje);
    }

}
