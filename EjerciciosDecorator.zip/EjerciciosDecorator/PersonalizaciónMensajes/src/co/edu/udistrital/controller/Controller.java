package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {

        Mensaje mensaje = new MensajeSimple("Tu pedido ha sido entregado exitosamente");

        mensaje = new ConFecha(mensaje);
        mensaje = new ConFirma(mensaje);
        mensaje = new EnMayusculas(mensaje);

        vista.mostrarMensaje(mensaje.getContenido());
    }
}

