package co.edu.udistrital.model;

public class EnMayusculas extends DecoradorMensaje {

    public EnMayusculas(Mensaje base) {
        super(base);
    }

    @Override
    public String getContenido() {
        return base.getContenido().toUpperCase();
    }
}
