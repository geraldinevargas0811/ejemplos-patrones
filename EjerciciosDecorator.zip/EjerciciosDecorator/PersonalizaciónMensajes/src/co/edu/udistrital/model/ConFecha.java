package co.edu.udistrital.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ConFecha extends DecoradorMensaje {

    public ConFecha(Mensaje base) {
        super(base);
    }

    @Override
    public String getContenido() {
        String fecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        return base.getContenido() + " [" + fecha + "]";
    }
}
