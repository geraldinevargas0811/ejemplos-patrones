package co.edu.udistrital.model;

public class ConFirma extends DecoradorMensaje {

    public ConFirma(Mensaje base) {
        super(base);
    }

    @Override
    public String getContenido() {
        return base.getContenido() + "\n-- Equipo de Atención al Cliente";
    }
}

