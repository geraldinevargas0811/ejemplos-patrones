package co.edu.udistrital.model;

public class MensajeSimple implements Mensaje {
    private String contenido;

    public MensajeSimple(String contenido) {
        this.contenido = contenido;
    }

    @Override
    public String getContenido() {
        return contenido;
    }
}

