package co.edu.udistrital.model;

public abstract class DecoradorMensaje implements Mensaje {
    protected Mensaje base;

    public DecoradorMensaje(Mensaje base) {
        this.base = base;
    }

    @Override
    public String getContenido() {
        return base.getContenido(); // Por defecto no altera
    }
}
