package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarVehiculo(String desc, int velocidad) {
        System.out.println("-----Simulación de Vehículo-----");
        System.out.println("Descripción: " + desc);
        System.out.println("Velocidad Máx: " + velocidad + " km/h");
    }
}
