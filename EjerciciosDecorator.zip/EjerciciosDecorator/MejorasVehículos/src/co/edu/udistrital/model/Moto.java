package co.edu.udistrital.model;

public class Moto implements Vehiculo {
    @Override
    public String getDescripcion() {
        return "Moto deportiva";
    }

    @Override
    public int getVelocidadMax() {
        return 200;
    }
}
