package co.edu.udistrital.model;

public class Turbo extends DecoradorVehiculo {
    public Turbo(Vehiculo base) {
        super(base);
    }

    @Override
    public String getDescripcion() {
        return base.getDescripcion() + " + Turbo";
    }

    @Override
    public int getVelocidadMax() {
        return base.getVelocidadMax() + 50;
    }
}
