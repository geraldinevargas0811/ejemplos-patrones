package co.edu.udistrital.model;

public class Navegacion extends DecoradorVehiculo {
    public Navegacion(Vehiculo base) {
        super(base);
    }

    @Override
    public String getDescripcion() {
        return base.getDescripcion() + " + Sistema de Navegación";
    }
}
