package co.edu.udistrital.model;

public class Auto implements Vehiculo {
    @Override
    public String getDescripcion() {
        return "Auto estándar";
    }

    @Override
    public int getVelocidadMax() {
        return 180;
    }
}

