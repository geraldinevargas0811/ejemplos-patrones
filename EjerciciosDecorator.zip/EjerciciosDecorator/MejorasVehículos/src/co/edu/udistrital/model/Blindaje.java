package co.edu.udistrital.model;

public class Blindaje extends DecoradorVehiculo {
    public Blindaje(Vehiculo base) {
        super(base);
    }

    @Override
    public String getDescripcion() {
        return base.getDescripcion() + " + Blindaje";
    }

    @Override
    public int getVelocidadMax() {
        return base.getVelocidadMax() - 20; // por peso extra
    }
}
