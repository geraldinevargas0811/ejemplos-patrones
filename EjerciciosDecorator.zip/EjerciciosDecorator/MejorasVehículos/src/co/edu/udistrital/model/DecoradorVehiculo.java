package co.edu.udistrital.model;

public abstract class DecoradorVehiculo implements Vehiculo {
    protected Vehiculo base;

    public DecoradorVehiculo(Vehiculo base) {
        this.base = base;
    }

    @Override
    public String getDescripcion() {
        return base.getDescripcion();
    }

    @Override
    public int getVelocidadMax() {
        return base.getVelocidadMax();
    }
}
