package co.edu.udistrital.model;

public interface Vehiculo {
	String getDescripcion();
    int getVelocidadMax();
}
