package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Vehiculo vehiculo = new Auto();

        vehiculo = new Turbo(vehiculo);
        vehiculo = new Navegacion(vehiculo);
        vehiculo = new Blindaje(vehiculo);

        vista.mostrarVehiculo(vehiculo.getDescripcion(), vehiculo.getVelocidadMax());
    }
}

