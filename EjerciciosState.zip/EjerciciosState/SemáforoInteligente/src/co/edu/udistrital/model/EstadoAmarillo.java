package co.edu.udistrital.model;

public class EstadoAmarillo implements EstadoSemaforo {

    @Override
    public void siguiente(Semaforo s) {
        s.setEstado(new EstadoRojo());
    }

    @Override
    public String mostrar() {
        return "🟡 Semáforo en AMARILLO - Precaución.";
    }
}
