package co.edu.udistrital.model;

public class Semaforo {
    private EstadoSemaforo estado;

    public Semaforo() {
        estado = new EstadoRojo();
    }

    public void cambiar() {
        estado.siguiente(this);
    }

    public String mostrarEstado() {
        return estado.mostrar();
    }

    public void setEstado(EstadoSemaforo nuevoEstado) {
        this.estado = nuevoEstado;
    }
}
