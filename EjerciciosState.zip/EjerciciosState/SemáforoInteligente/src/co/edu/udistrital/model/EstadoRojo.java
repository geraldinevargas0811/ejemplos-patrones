package co.edu.udistrital.model;

public class EstadoRojo implements EstadoSemaforo {

    @Override
    public void siguiente(Semaforo s) {
        s.setEstado(new EstadoVerde());
    }

    @Override
    public String mostrar() {
        return "🔴 Semáforo en ROJO - Detenerse.";
    }
}
