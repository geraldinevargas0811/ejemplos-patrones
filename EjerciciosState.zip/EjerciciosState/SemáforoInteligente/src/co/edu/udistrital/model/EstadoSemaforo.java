package co.edu.udistrital.model;

public interface EstadoSemaforo {
    void siguiente(Semaforo s);
    String mostrar();
}
