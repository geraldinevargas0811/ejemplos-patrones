package co.edu.udistrital.model;

public class EstadoVerde implements EstadoSemaforo {

    @Override
    public void siguiente(Semaforo s) {
        s.setEstado(new EstadoAmarillo());
    }

    @Override
    public String mostrar() {
        return "🟢 Semáforo en VERDE - Avanzar.";
    }
}
