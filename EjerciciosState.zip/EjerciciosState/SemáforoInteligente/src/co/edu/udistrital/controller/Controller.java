package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Semaforo semaforo = new Semaforo();

        for (int i = 0; i < 6; i++) {
            vista.mostrar(semaforo.mostrarEstado());
            semaforo.cambiar();

            try {
                Thread.sleep(1000); // simulación del tiempo entre cambios
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

