package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        SolicitudPrestamo solicitud = new SolicitudPrestamo();

        vista.mostrar(solicitud.mostrarEstado());

        solicitud.avanzar();
        vista.mostrar(solicitud.mostrarEstado());

        solicitud.avanzar(); // Aprobado o Rechazado
        vista.mostrar(solicitud.mostrarEstado());

        // Intento de avanzar desde estado final (no hace nada)
        solicitud.avanzar();
        vista.mostrar(solicitud.mostrarEstado());
    }
}

