package co.edu.udistrital.model;

public class EstadoEvaluacion implements EstadoSolicitud {

    @Override
    public void avanzar(SolicitudPrestamo s) {
        // Simulación simple: si nombre contiene "a", se aprueba; si no, se rechaza
        boolean aprobacion = Math.random() < 0.5;
        if (aprobacion) {
            s.setEstado(new EstadoAprobado());
        } else {
            s.setEstado(new EstadoRechazado());
        }
    }

    @Override
    public String mostrar() {
        return "🔍 Estado: En evaluación - Analizando condiciones del préstamo.";
    }
}
