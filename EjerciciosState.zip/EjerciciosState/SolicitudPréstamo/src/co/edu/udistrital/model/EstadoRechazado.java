package co.edu.udistrital.model;

public class EstadoRechazado implements EstadoSolicitud {

    @Override
    public void avanzar(SolicitudPrestamo s) {
        // No hay avance desde aquí
    }

    @Override
    public String mostrar() {
        return "❌ Estado: Rechazado - Su préstamo ha sido denegado.";
    }
}
