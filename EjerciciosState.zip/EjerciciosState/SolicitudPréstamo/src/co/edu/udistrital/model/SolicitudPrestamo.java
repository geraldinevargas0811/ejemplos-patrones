package co.edu.udistrital.model;

public class SolicitudPrestamo {
    private EstadoSolicitud estado;

    public SolicitudPrestamo() {
        this.estado = new EstadoRegistrado(); // estado inicial
    }

    public void avanzar() {
        estado.avanzar(this);
    }

    public String mostrarEstado() {
        return estado.mostrar();
    }

    public void setEstado(EstadoSolicitud nuevoEstado) {
        this.estado = nuevoEstado;
    }
}

