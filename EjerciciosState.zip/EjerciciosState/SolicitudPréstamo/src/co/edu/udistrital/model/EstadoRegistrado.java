package co.edu.udistrital.model;

public class EstadoRegistrado implements EstadoSolicitud {

    @Override
    public void avanzar(SolicitudPrestamo s) {
        s.setEstado(new EstadoEvaluacion());
    }

    @Override
    public String mostrar() {
        return "📄 Estado: Registrado - Solicitud recibida.";
    }
}

