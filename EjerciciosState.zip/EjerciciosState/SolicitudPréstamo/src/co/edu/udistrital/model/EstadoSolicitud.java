package co.edu.udistrital.model;

public interface EstadoSolicitud {
    void avanzar(SolicitudPrestamo s);
    String mostrar();
}

