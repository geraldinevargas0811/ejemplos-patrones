package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        MaquinaExpendedora maquina = new MaquinaExpendedora();

        vista.mostrar(maquina.mostrarEstado());

        maquina.seleccionar();
        vista.mostrar(maquina.mostrarEstado());

        maquina.pagar();
        vista.mostrar(maquina.mostrarEstado());

        maquina.entregar();
        vista.mostrar(maquina.mostrarEstado());
    }
}
