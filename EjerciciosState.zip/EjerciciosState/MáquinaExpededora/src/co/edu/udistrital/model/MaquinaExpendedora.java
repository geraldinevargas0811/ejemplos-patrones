package co.edu.udistrital.model;

public class MaquinaExpendedora {
    private EstadoMaquina estado;

    public MaquinaExpendedora() {
        this.estado = new EstadoSeleccion();
    }

    public void seleccionar() {
        estado.seleccionarProducto(this);
    }

    public void pagar() {
        estado.pagar(this);
    }

    public void entregar() {
        estado.entregar(this);
    }

    public void setEstado(EstadoMaquina nuevoEstado) {
        this.estado = nuevoEstado;
    }

    public String mostrarEstado() {
        return estado.mostrar();
    }
}
