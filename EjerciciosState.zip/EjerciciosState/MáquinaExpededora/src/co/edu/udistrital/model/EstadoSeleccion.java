package co.edu.udistrital.model;

public class EstadoSeleccion implements EstadoMaquina {

    @Override
    public void seleccionarProducto(MaquinaExpendedora m) {
        m.setEstado(new EstadoPago());
    }

    @Override
    public void pagar(MaquinaExpendedora m) {
        // no se puede pagar aún
    }

    @Override
    public void entregar(MaquinaExpendedora m) {
        // no se puede entregar aún
    }

    @Override
    public String mostrar() {
        return "🔘 Estado: Selección de producto";
    }
}
