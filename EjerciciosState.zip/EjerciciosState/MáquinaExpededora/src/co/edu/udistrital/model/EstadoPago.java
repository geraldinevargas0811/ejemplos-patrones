package co.edu.udistrital.model;

public class EstadoPago implements EstadoMaquina {

    @Override
    public void seleccionarProducto(MaquinaExpendedora m) {
        // ya se seleccionó
    }

    @Override
    public void pagar(MaquinaExpendedora m) {
        m.setEstado(new EstadoEntrega());
    }

    @Override
    public void entregar(MaquinaExpendedora m) {
        // no se puede entregar sin pagar
    }

    @Override
    public String mostrar() {
        return "💳 Estado: Esperando pago";
    }
}
