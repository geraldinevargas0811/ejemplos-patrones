package co.edu.udistrital.model;

public interface EstadoMaquina {
    void seleccionarProducto(MaquinaExpendedora m);
    void pagar(MaquinaExpendedora m);
    void entregar(MaquinaExpendedora m);
    String mostrar();
}
