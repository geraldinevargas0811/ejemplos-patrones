package co.edu.udistrital.model;

public class EstadoEntrega implements EstadoMaquina {

    @Override
    public void seleccionarProducto(MaquinaExpendedora m) {
        // ya se entregará el producto
    }

    @Override
    public void pagar(MaquinaExpendedora m) {
        // ya se pagó
    }

    @Override
    public void entregar(MaquinaExpendedora m) {
        m.setEstado(new EstadoSeleccion()); // vuelve al inicio
    }

    @Override
    public String mostrar() {
        return "📦 Estado: Entregando producto...";
    }
}

