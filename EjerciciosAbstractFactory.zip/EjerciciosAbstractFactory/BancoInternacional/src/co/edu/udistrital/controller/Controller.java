package co.edu.udistrital.controller;


import co.edu.udistrital.model.fabricaAbstracta.BancoFactory;
import co.edu.udistrital.model.fabricaAbstracta.BancoOperaciones;
import co.edu.udistrital.model.fabricaConcreta.ColombiaConcreto;
import co.edu.udistrital.model.fabricaConcreta.USAConcreto;
import co.edu.udistrital.view.VistaConsola;

import java.util.Scanner;

public class Controller {
private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	int op = 0;
        do{
            op=menu();
            switch(op){
                case 1:
                    pais(new ColombiaConcreto());
                    break;
                case 2:
                    pais(new USAConcreto());
                    break;
                case 3:
                    vista.mostrarInformacion("Cerrando Programa");
                    System.exit(0);
                default :
                	 vista.mostrarInformacion(".....Opcion invalida....");
            }
            vista.mostrarInformacion("");
        }while(op!=4);
    }
    
    public void pais(BancoFactory operaciones) {
        BancoOperaciones operacion = operaciones.crearOperacion();

        int opcionOperacion;
        do {
        	opcionOperacion = menuOperaciones();
        	switch (opcionOperacion) {
            	case 1:
            		double monto = vista.leerDatoDecimal("Ingrese el monto para calcular intereses:");
            		String resultadoInteres = operacion.ejecutarCalculadorIntereses(monto);
            		vista.mostrarInformacion(resultadoInteres);
            		break;
            	case 2:
            		String documento = "";
            		do {
            			documento = vista.leerTexto("Ingrese el documento del cliente:");
            			if (documento.length() < 3) {
            				vista.mostrarInformacion("Documento inválido. Debe tener al menos 3 caracteres.");
            			}
            		} while (documento.length() < 3);
            		String resultadoTarjeta = operacion.validarTarjetaCredito(documento);
            		vista.mostrarInformacion(resultadoTarjeta);
            		break;
            	case 3:
            		vista.mostrarInformacion("Volviendo al menú principal...");
	                break;
            	default:
            		vista.mostrarInformacion("Opción inválida en operaciones.");
        	}
        }while (opcionOperacion != 3);
    }
    
    public int  menu(){
        String menu2 = 
                "MENU DE OPCIONES\n"
                + "1.   Ejecutar procesos de Colombia. \n"
                + "2.   Ejecutar procesos de USA. \n"
                + "3.   Cerrar programa. \n\n"
                + "Seleccion opcion...";
        return vista.leerDatoEntero(menu2);
    }
    
    public int menuOperaciones() {
        String menu = 
                "¿Qué operación desea realizar?\n"
                + "1. Calcular intereses\n"
                + "2. Emitir tarjeta de credito\n"
                + "3. Volver al menu principal\n\n"
                + "Seleccione opción...";
        return vista.leerDatoEntero(menu);
    }
    
}