package co.edu.udistrital.model.fabricaAbstracta;

public interface BancoOperaciones {
	
	String ejecutarCalculadorIntereses(double monto);
	String validarTarjetaCredito(String documento);

}
