package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.BancoOperaciones;

public class Colombia implements BancoOperaciones{
	public double Monto;
    public String DocumentoCliente;
    public double InteresCalculado;
    public String numeroTarjetaGenerado;
    public boolean Aprobada;

	@Override
	public String ejecutarCalculadorIntereses(double monto) {
		this.Monto = monto;
		InteresCalculado = this.Monto * 0.3;
	    return "Interés calculado: $" + InteresCalculado;
	}

	@Override
	public String validarTarjetaCredito(String documento) {
		this.DocumentoCliente = documento;
		
		this.numeroTarjetaGenerado = "TC-" + DocumentoCliente.substring(0, 3).toUpperCase() + "-" + (int)(Math.random() * 10000);
        this.Aprobada = true;
        return "Tarjeta de crédito Colombiana emitida exitosamente: " + numeroTarjetaGenerado;
        
	}

}
