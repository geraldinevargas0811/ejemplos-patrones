package co.edu.udistrital.model.fabricaAbstracta;

public interface BancoFactory {
	
	BancoOperaciones crearOperacion();

}
