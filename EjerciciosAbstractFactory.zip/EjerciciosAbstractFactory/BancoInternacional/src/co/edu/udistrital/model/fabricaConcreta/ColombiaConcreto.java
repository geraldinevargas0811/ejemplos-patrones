package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.Colombia;
import co.edu.udistrital.model.fabricaAbstracta.BancoFactory;
import co.edu.udistrital.model.fabricaAbstracta.BancoOperaciones;

public class ColombiaConcreto implements BancoFactory {

	@Override
	public BancoOperaciones crearOperacion() {
		return new Colombia();
	}

}
