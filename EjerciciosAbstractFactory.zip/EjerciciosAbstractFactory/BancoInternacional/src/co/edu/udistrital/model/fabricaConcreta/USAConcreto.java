package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.USA;
import co.edu.udistrital.model.fabricaAbstracta.BancoFactory;
import co.edu.udistrital.model.fabricaAbstracta.BancoOperaciones;


public class USAConcreto implements BancoFactory{

	@Override
	public BancoOperaciones crearOperacion() {
		return new USA();
	}
	
	
}
