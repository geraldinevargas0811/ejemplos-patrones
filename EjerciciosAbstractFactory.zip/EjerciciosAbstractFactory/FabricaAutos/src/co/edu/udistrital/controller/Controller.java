package co.edu.udistrital.controller;

import co.edu.udistrital.model.fabricaAbstracta.*;
import co.edu.udistrital.model.fabricaConcreta.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}
	
	public void run() {
		int op=0;
		do {
			op=menu();
			switch(op) {
				case 1:
					auto(new AutoElectricoConcreta());
					break;
				case 2:
					auto(new AutoGasolinaConcreta());
					break;
				case 3:
					auto(new AutoHibridoConcreta());
					break;
				case 4:
					vista.mostrarInformacion("Cerrando Programa");
                    System.exit(0);
				default:
					vista.mostrarInformacion(".....Opcion invalida....");
			}
			vista.mostrarInformacion("");
		}while(op!=5);
	}
	
	public void auto(FabricaFactory partes) {
		FabricaPartes parte = partes.crearPartes();
		
		int opcionOperacion;
	    do {
	        opcionOperacion = menuOperaciones();
	        switch (opcionOperacion) {
	            case 1:
	                vista.mostrarInformacion(parte.crearBateria());
	                break;
	            case 2:
	                vista.mostrarInformacion(parte.crearMotor());
	                break;
	            case 3:
	                vista.mostrarInformacion(parte.crearSistemaControl());
	                break;
	            case 4:
	                vista.mostrarInformacion("Volviendo al menú principal...");
	                break;
	            default:
	                vista.mostrarInformacion("Opción inválida en operaciones.");
	        }
	    } while (opcionOperacion != 4);
		
		
	}
	public int  menu(){
        String menu2 = 
                "MENU DE OPCIONES\n"
                + "1.   Crear auto electrico. \n"
                + "2.   Crear auto gasolina. \n"
                + "3.   Crear auto hibrido. \n"
                + "4.   Salir. \n\n"
                + "Seleccion opcion...";
        return vista.leerDatoEntero(menu2);
    }
	
	public int menuOperaciones() {
        String menu = 
                "¿Qué operación desea realizar? \n"
                + "1. Crear bateria. \n"
                + "2. Crear motor. \n"
                + "3. Crear sistema de control. \n"
                + "4. Volver al menu principar. \n\n"
                + "Seleccione opción...";
        return vista.leerDatoEntero(menu);
    }

}
