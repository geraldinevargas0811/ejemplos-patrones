package co.edu.udistrital.model.fabricaAbstracta;

public interface FabricaFactory {
	
	FabricaPartes crearPartes();

}
