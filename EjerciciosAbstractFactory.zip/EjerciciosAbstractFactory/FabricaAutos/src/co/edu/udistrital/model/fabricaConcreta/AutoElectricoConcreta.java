package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.AutoElectrico;
import co.edu.udistrital.model.fabricaAbstracta.FabricaFactory;
import co.edu.udistrital.model.fabricaAbstracta.FabricaPartes;

public class AutoElectricoConcreta implements FabricaFactory{

	@Override
	public FabricaPartes crearPartes() {
		return new AutoElectrico();
	}

}
