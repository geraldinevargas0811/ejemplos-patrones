package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.AutoGasolina;
import co.edu.udistrital.model.fabricaAbstracta.FabricaFactory;
import co.edu.udistrital.model.fabricaAbstracta.FabricaPartes;

public class AutoGasolinaConcreta implements FabricaFactory{

	@Override
	public FabricaPartes crearPartes() {
		return new AutoGasolina();
	}

}
