package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.FabricaPartes;

public class AutoElectrico implements FabricaPartes{

	@Override
	public String crearMotor() {
		return "Ensamblando motor eléctrico.\n";
	}

	@Override
	public String crearBateria() {
		return "Cargando batería de litio.\n";
	}

	@Override
	public String crearSistemaControl() {
		return "Calibrando sistema de control electrónico.\n";
	}

}
