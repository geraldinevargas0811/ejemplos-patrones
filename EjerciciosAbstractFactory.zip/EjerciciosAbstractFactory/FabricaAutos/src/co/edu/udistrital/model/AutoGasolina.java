package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.FabricaPartes;

public class AutoGasolina implements FabricaPartes{

	@Override
	public String crearMotor() {
		return "Ensamblando motor de combustión interna.\n";
	}

	@Override
	public String crearBateria() {
		return "Verificando batería de arranque.\n";
	}

	@Override
	public String crearSistemaControl() {
		return "Calibrando sistema de control mecánico.\n";
	}

}
