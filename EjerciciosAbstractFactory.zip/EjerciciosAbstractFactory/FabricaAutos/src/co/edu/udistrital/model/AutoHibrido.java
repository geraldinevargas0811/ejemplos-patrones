package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.FabricaPartes;

public class AutoHibrido implements FabricaPartes{

	@Override
	public String crearMotor() {
		return "Ensamblando motor híbrido (eléctrico + combustión).\n";
	}

	@Override
	public String crearBateria() {
		return "Cargando batería híbrida.\n";
	}

	@Override
	public String crearSistemaControl() {
		return "Calibrando sistema de control híbrido.\n";
	}

}
