package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.AutoHibrido;
import co.edu.udistrital.model.fabricaAbstracta.FabricaFactory;
import co.edu.udistrital.model.fabricaAbstracta.FabricaPartes;

public class AutoHibridoConcreta implements FabricaFactory{

	@Override
	public FabricaPartes crearPartes() {
		return new AutoHibrido();
	}
	

}
