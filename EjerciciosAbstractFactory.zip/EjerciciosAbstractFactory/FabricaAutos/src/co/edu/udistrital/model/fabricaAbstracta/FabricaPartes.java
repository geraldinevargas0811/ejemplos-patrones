package co.edu.udistrital.model.fabricaAbstracta;

public interface FabricaPartes {
	
	String crearMotor();
	String crearBateria();
	String crearSistemaControl();

}
