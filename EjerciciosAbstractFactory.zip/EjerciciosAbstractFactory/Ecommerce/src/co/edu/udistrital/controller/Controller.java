package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.fabricaAbstracta.*;
import co.edu.udistrital.model.fabricaConcreta.*;

public class Controller {
	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}
	
	public void run() {
		int op=0;
		do {
			op=menu();
			switch(op) {
				case 1:
					tienda(new TiendaAlimentosConcreta());
					break;
				case 2:
					tienda(new TiendaRopaConcreta());
					break;
				case 3:
					tienda(new TiendaTecnologiaConcreta());
					break;
				case 4:
					vista.mostrarInformacion("Cerrando Programa");
                    System.exit(0);
				default:
					vista.mostrarInformacion(".....Opcion invalida....");
			}
			vista.mostrarInformacion("");
		}while(op!=5);
	}
	
	public void tienda(EcommerceFactory productos) {
		EcommerceProducto producto = productos.crearProducto();
		
		int opcionOperacion;
	    do {
	        opcionOperacion = menuOperaciones();
	        switch (opcionOperacion) {
	            case 1:
	                vista.mostrarInformacion(producto.mostrarCatalogo());
	                break;
	            case 2:
	                vista.mostrarInformacion(producto.ejecutarPago());
	                break;
	            case 3:
	                vista.mostrarInformacion(producto.validarEnvio());
	                break;
	            case 4:
	                vista.mostrarInformacion("Volviendo al menú principal...");
	                break;
	            default:
	                vista.mostrarInformacion("Opción inválida en operaciones.");
	        }
	    } while (opcionOperacion != 4);
		
		
	}
	public int  menu(){
        String menu2 = 
                "MENU DE OPCIONES\n"
                + "1.   Ir a la tienda de alimentos. \n"
                + "2.   Ir a la tienda de ropa. \n"
                + "3.   Ir a la tienda de tecnologia. \n"
                + "4.   Salir. \n\n"
                + "Seleccion opcion...";
        return vista.leerDatoEntero(menu2);
    }
	
	public int menuOperaciones() {
        String menu = 
                "¿Qué operación desea realizar? \n"
                + "1. Ver el catalogo de la tienda. \n"
                + "2. Ejecutar el pago del pedido. \n"
                + "3. Hacer el envio del pedido. \n"
                + "4. Volver al menu principar. \n\n"
                + "Seleccione opción...";
        return vista.leerDatoEntero(menu);
    }

}
