package co.edu.udistrital.controller;

public class AplEcommerce {
	
	public static void main(String[] args) {

		Controller control;
		control = new Controller();
		control.run();

	}

}
