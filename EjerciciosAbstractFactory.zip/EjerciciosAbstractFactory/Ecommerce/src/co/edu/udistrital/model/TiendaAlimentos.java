package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.EcommerceProducto;

public class TiendaAlimentos implements EcommerceProducto{

	@Override
	public String mostrarCatalogo() {
		return  "Mostrando catálogo de alimentos: "+"\n"+"-mini donas"+"\n"+ "-cupcakes"+"\n"+ "-fresas con chocolate\n";
	}

	@Override
	public String ejecutarPago() {
		return "Procesando pago por banco digital para alimentos.\n";
	}

	@Override
	public String validarEnvio() {
		return "Enviando alimentos con transporte refigerado.\n";
	}

}
