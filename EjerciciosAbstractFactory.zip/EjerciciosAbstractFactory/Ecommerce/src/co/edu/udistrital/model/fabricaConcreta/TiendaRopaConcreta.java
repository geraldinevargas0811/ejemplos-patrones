package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.TiendaRopa;
import co.edu.udistrital.model.fabricaAbstracta.EcommerceFactory;
import co.edu.udistrital.model.fabricaAbstracta.EcommerceProducto;

public class TiendaRopaConcreta implements EcommerceFactory{

	@Override
	public EcommerceProducto crearProducto() {
		return new TiendaRopa();
	}

}
