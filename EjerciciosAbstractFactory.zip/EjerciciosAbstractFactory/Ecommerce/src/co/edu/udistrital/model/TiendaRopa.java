package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.EcommerceProducto;

public class TiendaRopa implements EcommerceProducto{

	@Override
	public String mostrarCatalogo() {
		return "Mostrando catálogo de ropa: "+"\n"+"-chaquetas"+"\n"+ "-faldas"+"\n"+ "-jeans\n";
	}

	@Override
	public String ejecutarPago() {
		return "Procesando pago contra entrega para ropa.\n";
	}

	@Override
	public String validarEnvio() {
		return "Enviando ropa en paquete estándar.\n";
	}

}
