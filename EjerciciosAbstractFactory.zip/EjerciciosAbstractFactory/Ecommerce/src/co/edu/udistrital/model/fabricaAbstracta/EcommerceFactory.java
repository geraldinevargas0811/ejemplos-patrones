package co.edu.udistrital.model.fabricaAbstracta;

public interface EcommerceFactory {
	
	EcommerceProducto crearProducto();

}
