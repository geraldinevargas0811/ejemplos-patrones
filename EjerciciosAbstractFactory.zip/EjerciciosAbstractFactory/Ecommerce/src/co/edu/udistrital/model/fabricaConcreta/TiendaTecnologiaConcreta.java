package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.TiendaTecnologia;
import co.edu.udistrital.model.fabricaAbstracta.EcommerceFactory;
import co.edu.udistrital.model.fabricaAbstracta.EcommerceProducto;

public class TiendaTecnologiaConcreta implements EcommerceFactory{

	@Override
	public EcommerceProducto crearProducto() {
		return new TiendaTecnologia();
	}

}
