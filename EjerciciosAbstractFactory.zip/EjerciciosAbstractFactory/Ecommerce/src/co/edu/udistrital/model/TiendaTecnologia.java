package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.EcommerceProducto;

public class TiendaTecnologia implements EcommerceProducto{

	@Override
	public String mostrarCatalogo() {
		return "Mostrando catálogo de ropa: "+"\n"+"-celulares"+"\n"+ "-laptops"+"\n"+ "-TVs\n";
	}

	@Override
	public String ejecutarPago() {
		return "Procesando pago con tarjeta de crédito o transferencia.\n";
	}

	@Override
	public String validarEnvio() {
		return "Enviando tecnología con seguro y guía de seguimiento.\n";
	}

}
