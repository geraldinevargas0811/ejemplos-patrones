package co.edu.udistrital.model.fabricaAbstracta;

public interface EcommerceProducto {
	
	String mostrarCatalogo();
	String ejecutarPago();
	String validarEnvio();

}
