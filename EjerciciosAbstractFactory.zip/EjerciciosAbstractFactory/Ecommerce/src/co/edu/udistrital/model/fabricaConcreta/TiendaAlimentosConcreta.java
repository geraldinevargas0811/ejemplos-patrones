package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.TiendaAlimentos;
import co.edu.udistrital.model.fabricaAbstracta.EcommerceFactory;
import co.edu.udistrital.model.fabricaAbstracta.EcommerceProducto;

public class TiendaAlimentosConcreta implements EcommerceFactory{

	@Override
	public EcommerceProducto crearProducto() {
		return new TiendaAlimentos();
	}

}
