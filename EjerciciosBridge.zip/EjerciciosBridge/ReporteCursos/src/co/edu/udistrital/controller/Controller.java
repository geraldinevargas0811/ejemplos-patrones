package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.implementador.*;
import co.edu.udistrital.model.abstraccion.*;

public class Controller {
	
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void iniciar() {
        ReporteCurso reporteNotasPDF = new ReporteNotas(new ExportarPDF());
        ReporteCurso reporteAsistenciaHTML = new ReporteAsistencia(new ExportarHTML());
        ReporteCurso reporteParticipacionCSV = new ReporteParticipacion(new ExportarCSV());

        vista.mostrar(reporteNotasPDF.generarReporte());
        vista.mostrar(reporteAsistenciaHTML.generarReporte());
        vista.mostrar(reporteParticipacionCSV.generarReporte());
    }

}
