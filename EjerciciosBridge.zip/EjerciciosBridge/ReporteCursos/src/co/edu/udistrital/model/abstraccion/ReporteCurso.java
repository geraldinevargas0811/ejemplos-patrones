package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public abstract class ReporteCurso {
    protected FormatoExportacion formato;

    public ReporteCurso(FormatoExportacion formato) {
        this.formato = formato;
    }

    public abstract String generarReporte();
}