package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class ReporteNotas extends ReporteCurso {

    public ReporteNotas(FormatoExportacion formato) {
        super(formato);
    }

    @Override
    public String generarReporte() {
        String datos = "Estudiante: Ana Pérez\nNota final: 4.3";
        return formato.exportar(datos);
    }
}