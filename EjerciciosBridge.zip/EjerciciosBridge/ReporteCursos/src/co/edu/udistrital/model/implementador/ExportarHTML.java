package co.edu.udistrital.model.implementador;

public class ExportarHTML implements FormatoExportacion {
    @Override
    public String exportar(String datos) {
        return "<html><body><h2>Reporte</h2><p>" + datos.replace("\n", "<br>") + "</p></body></html>";
    }
}