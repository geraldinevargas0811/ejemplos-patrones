package co.edu.udistrital.model.implementador;

public class ExportarCSV implements FormatoExportacion {
    @Override
    public String exportar(String datos) {
        return "Formato CSV:\n" + datos.replace("\n", ", ") + "\n";
    }
}