package co.edu.udistrital.model.implementador;

public interface FormatoExportacion {
	
	String exportar(String datos);

}
