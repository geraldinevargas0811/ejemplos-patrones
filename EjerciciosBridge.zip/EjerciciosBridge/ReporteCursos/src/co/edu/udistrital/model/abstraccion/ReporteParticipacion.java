package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class ReporteParticipacion extends ReporteCurso {

    public ReporteParticipacion(FormatoExportacion formato) {
        super(formato);
    }

    @Override
    public String generarReporte() {
        String datos = "Estudiante: Laura Gómez\nParticipaciones: 15 intervenciones";
        return formato.exportar(datos);
    }
}