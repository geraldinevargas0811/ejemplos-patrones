package co.edu.udistrital.model.implementador;

public class ExportarPDF implements FormatoExportacion {
    @Override
    public String exportar(String datos) {
        return "[PDF]\n---INICIO---\n" + datos + "\n---FIN---";
    }
}
