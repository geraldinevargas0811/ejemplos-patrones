package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class ReporteAsistencia extends ReporteCurso {

    public ReporteAsistencia(FormatoExportacion formato) {
        super(formato);
    }

    @Override
    public String generarReporte() {
        String datos = "Estudiante: Carlos Ruiz\nAsistencias: 22/24";
        return formato.exportar(datos);
    }
}