package co.edu.udistrital.model.implementador;

public class CanalVoz implements CanalComunicacion {
    @Override
    public String transmitir(String mensaje) {
        return "🔊 Voz sintetizada dice: '" + mensaje + "'";
    }
}