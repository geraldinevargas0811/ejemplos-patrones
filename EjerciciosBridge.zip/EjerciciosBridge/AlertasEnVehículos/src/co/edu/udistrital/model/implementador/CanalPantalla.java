package co.edu.udistrital.model.implementador;

public class CanalPantalla implements CanalComunicacion {
    @Override
    public String transmitir(String mensaje) {
        return "🔷 Pantalla del vehículo muestra: " + mensaje;
    }
}