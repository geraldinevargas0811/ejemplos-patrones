package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class AlertaSeguridad extends AlertaVehicular{
	
	public AlertaSeguridad(CanalComunicacion canal) {
        super(canal);
    }

    @Override
    public String emitir() {
        String mensaje = "¡Alerta de seguridad! Puerta del conductor abierta mientras el motor está encendido.";
        return canal.transmitir(mensaje);
    }

}
