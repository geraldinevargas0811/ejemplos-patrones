package co.edu.udistrital.model.implementador;


public class CanalAppMovil implements CanalComunicacion {
    @Override
    public String transmitir(String mensaje) {
        return "📱 Notificación enviada a app móvil: " + mensaje;
    }
}
