package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class AlertaClimatica extends AlertaVehicular {

    public AlertaClimatica(CanalComunicacion canal) {
        super(canal);
    }

    @Override
    public String emitir() {
        String mensaje = "Advertencia: Niebla densa detectada en ruta.";
        return canal.transmitir(mensaje);
    }
}

