package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public abstract class AlertaVehicular {
    protected CanalComunicacion canal;

    public AlertaVehicular(CanalComunicacion canal) {
        this.canal = canal;
    }

    public abstract String emitir();
}