package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class AlertaMantenimiento extends AlertaVehicular {

    public AlertaMantenimiento(CanalComunicacion canal) {
        super(canal);
    }

    @Override
    public String emitir() {
        String mensaje = "Recordatorio de mantenimiento: Cambio de aceite en 300 km.";
        return canal.transmitir(mensaje);
    }
}
