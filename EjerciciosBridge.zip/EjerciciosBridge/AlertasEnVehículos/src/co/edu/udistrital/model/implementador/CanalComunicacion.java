package co.edu.udistrital.model.implementador;

public interface CanalComunicacion {
	
	String transmitir(String mensaje);

}
