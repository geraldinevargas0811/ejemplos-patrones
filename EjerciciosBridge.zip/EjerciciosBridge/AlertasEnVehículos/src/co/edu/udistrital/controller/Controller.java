package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.implementador.*;
import co.edu.udistrital.model.abstraccion.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutarAlertas() {
        AlertaVehicular alerta1 = new AlertaSeguridad(new CanalPantalla());
        AlertaVehicular alerta2 = new AlertaMantenimiento(new CanalAppMovil());
        AlertaVehicular alerta3 = new AlertaClimatica(new CanalVoz());

        vista.mostrar(alerta1.emitir());
        vista.mostrar(alerta2.emitir());
        vista.mostrar(alerta3.emitir());
    }
}
