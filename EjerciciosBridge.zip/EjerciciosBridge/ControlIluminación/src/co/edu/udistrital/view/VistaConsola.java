package co.edu.udistrital.view;

public class VistaConsola {
	
	public void mostrarMensaje(String msg) {
        System.out.println(msg);
    }

    public void mostrarSimulacion(String[] mensajes) {
        for (String msg : mensajes) {
            mostrarMensaje(msg);
        }
    }

}
