package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.implementador.*;
import co.edu.udistrital.model.abstraccion.*;

public class Controller {
	
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void iniciarSistema() {
        TipoLuz led = new LuzLED(80);
        TipoLuz solar = new LuzSolar(true);
        TipoLuz fluorescente = new LuzFluorescente(true);

        ZonaControl interior = new ZonaInterior(led);
        ZonaControl exterior = new ZonaExterior(fluorescente);
        ZonaControl jardin = new ZonaJardin(solar);

        String[] encendidos = {
            interior.encenderZona(),
            exterior.encenderZona(),
            jardin.encenderZona()
        };

        vista.mostrarMensaje("-----Simulación de encendido:-----");
        vista.mostrarSimulacion(encendidos);

        String[] apagados = {
            interior.apagarZona(),
            exterior.apagarZona(),
            jardin.apagarZona()
        };

        vista.mostrarMensaje("\n"+"-----Simulación de apagado:-----");
        vista.mostrarSimulacion(apagados);
    }

}
