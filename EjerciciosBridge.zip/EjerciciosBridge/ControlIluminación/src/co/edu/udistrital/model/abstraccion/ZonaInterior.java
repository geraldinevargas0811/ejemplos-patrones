package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class ZonaInterior extends ZonaControl {

    public ZonaInterior(TipoLuz tipoLuz) {
        super(tipoLuz);
    }

    @Override
    public String encenderZona() {
        return "Zona interior: " + tipoLuz.encender();
    }

    @Override
    public String apagarZona() {
        return "Zona interior: " + tipoLuz.apagar();
    }
}