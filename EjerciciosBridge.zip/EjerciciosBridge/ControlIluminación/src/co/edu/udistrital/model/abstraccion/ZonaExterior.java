package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class ZonaExterior extends ZonaControl {

    public ZonaExterior(TipoLuz tipoLuz) {
        super(tipoLuz);
    }

    @Override
    public String encenderZona() {
        return "Zona exterior: " + tipoLuz.encender();
    }

    @Override
    public String apagarZona() {
        return "Zona exterior: " + tipoLuz.apagar();
    }
}