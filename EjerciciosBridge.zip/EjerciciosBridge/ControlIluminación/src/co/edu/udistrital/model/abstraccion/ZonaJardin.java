package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public class ZonaJardin extends ZonaControl {

    public ZonaJardin(TipoLuz tipoLuz) {
        super(tipoLuz);
    }

    @Override
    public String encenderZona() {
        return "Zona jardín: " + tipoLuz.encender();
    }

    @Override
    public String apagarZona() {
        return "Zona jardín: " + tipoLuz.apagar();
    }
}