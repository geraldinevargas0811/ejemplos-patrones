package co.edu.udistrital.model.implementador;

public class LuzFluorescente implements TipoLuz {
    private boolean tieneBalastro;

    public LuzFluorescente(boolean tieneBalastro) {
        this.tieneBalastro = tieneBalastro;
    }

    @Override
    public String encender() {
        return "Luz fluorescente encendida" + (tieneBalastro ? " con balastro." : ".");
    }

    @Override
    public String apagar() {
        return "Luz fluorescente apagada.";
    }
}
