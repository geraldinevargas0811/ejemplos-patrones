package co.edu.udistrital.model.implementador;

public class LuzSolar implements TipoLuz {
    private boolean panelConectado;

    public LuzSolar(boolean panelConectado) {
        this.panelConectado = panelConectado;
    }

    @Override
    public String encender() {
        if(panelConectado) {
            return "Luz solar encendida mediante panel.";
        } else {
            return "No se puede encender luz solar sin panel.";
        }
    }

    @Override
    public String apagar() {
        return "Luz solar apagada.";
    }
}
