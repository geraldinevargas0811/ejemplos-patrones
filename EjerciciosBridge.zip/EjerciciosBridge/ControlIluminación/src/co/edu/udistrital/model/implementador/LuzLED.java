package co.edu.udistrital.model.implementador;

public class LuzLED implements TipoLuz {
    private int intensidad;

    public LuzLED(int intensidad) {
        this.intensidad = intensidad;
    }

    @Override
    public String encender() {
        return "Luz LED encendida con intensidad " + intensidad + "%.";
    }

    @Override
    public String apagar() {
        return "Luz LED apagada.";
    }
}