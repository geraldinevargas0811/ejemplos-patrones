package co.edu.udistrital.model.implementador;

public interface TipoLuz {
	
	String encender();
    String apagar();

}
