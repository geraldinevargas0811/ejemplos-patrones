package co.edu.udistrital.model.abstraccion;

import co.edu.udistrital.model.implementador.*;

public abstract class ZonaControl {
    protected TipoLuz tipoLuz;

    public ZonaControl(TipoLuz tipoLuz) {
        this.tipoLuz = tipoLuz;
    }

    public abstract String encenderZona();
    public abstract String apagarZona();
}
