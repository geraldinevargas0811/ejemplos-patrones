package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void enviarDocumentos() {
        Impresora canon = new ImpresoraCanon();
        Impresora hp = new AdaptadorHP(new ImpresoraHPExterna());
        Impresora brother = new AdaptadorBrother(new ImpresoraBrotherAPI());

        vista.mostrarResultado("Canon", canon.imprimir("Reporte mensual"));
        vista.mostrarResultado("HP", hp.imprimir("Factura #456"));
        vista.mostrarResultado("Brother", brother.imprimir("Resumen de actividad"));
    }
}
