package co.edu.udistrital.model;

public class ImpresoraHPExterna {
	public boolean send(String data, int copies) {
        System.out.println("HP externa recibió " + copies + " copia(s).");
        return true;
    }

}
