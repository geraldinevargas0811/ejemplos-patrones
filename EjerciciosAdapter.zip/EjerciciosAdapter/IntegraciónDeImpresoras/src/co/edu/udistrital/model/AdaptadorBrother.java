package co.edu.udistrital.model;

public class AdaptadorBrother implements Impresora {
    private ImpresoraBrotherAPI brother;

    public AdaptadorBrother(ImpresoraBrotherAPI brother) {
        this.brother = brother;
    }

    @Override
    public String imprimir(String contenido) {
        byte[] datos = contenido.getBytes();
        brother.startJob(datos);
        return "Brother imprimió el documento.";
    }
}
