package co.edu.udistrital.model;

public class ImpresoraBrotherAPI {
	public void startJob(byte[] bytes) {
        System.out.println("Brother recibió " + bytes.length + " bytes para imprimir.");
    }
}
