package co.edu.udistrital.model;

public interface Impresora {
	String imprimir(String contenido);
}
