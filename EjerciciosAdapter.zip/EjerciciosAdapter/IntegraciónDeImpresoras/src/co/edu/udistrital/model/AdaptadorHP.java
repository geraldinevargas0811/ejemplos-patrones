package co.edu.udistrital.model;

public class AdaptadorHP implements Impresora {
    private ImpresoraHPExterna hp;

    public AdaptadorHP(ImpresoraHPExterna hp) {
        this.hp = hp;
    }

    @Override
    public String imprimir(String contenido) {
        boolean exito = hp.send(contenido, 1);
        return exito ? "HP imprimió correctamente." : "Fallo en impresión con HP.";
    }
}