package co.edu.udistrital.model;

public class ImpresoraCanon implements Impresora {

    @Override
    public String imprimir(String contenido) {
        return "Canon imprimió: " + contenido;
    }
}
