package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarResultado(String nombre, String resultado) {
        System.out.println("[Vista] " + nombre + ": " + resultado);
    }
}
