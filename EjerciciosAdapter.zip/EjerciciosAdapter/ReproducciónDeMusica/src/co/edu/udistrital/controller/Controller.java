package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void reproducirCanciones() {
        FuenteAudio mp3 = new ReproductorMP3();
        FuenteAudio wav = new AdaptadorWAV(new FuenteWAVExterna());
        FuenteAudio ogg = new AdaptadorOGG(new FuenteOGGVintage());
        FuenteAudio stream = new AdaptadorStreaming(new FuenteStreamingAPI());

        vista.mostrarReproduccion("MP3", mp3.reproducir("cancion1.mp3"));
        vista.mostrarReproduccion("WAV", wav.reproducir("melodia.wav"));
        vista.mostrarReproduccion("OGG", ogg.reproducir("pista.ogg"));
        vista.mostrarReproduccion("Streaming", stream.reproducir("live_track"));
    }
}
