package co.edu.udistrital.model;

public interface FuenteAudio {
	String reproducir(String archivo);
}
