package co.edu.udistrital.model;

public class FuenteStreamingAPI {
	public void streamFile(byte[] bytes) {
        System.out.println("Reproduciendo desde streaming de " + bytes.length + " bytes.");
    }

}
