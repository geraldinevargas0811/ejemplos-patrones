package co.edu.udistrital.model;

public class AdaptadorStreaming implements FuenteAudio {
    private FuenteStreamingAPI stream;

    public AdaptadorStreaming(FuenteStreamingAPI stream) {
        this.stream = stream;
    }

    @Override
    public String reproducir(String archivo) {
        byte[] datos = archivo.getBytes(); // simulación
        stream.streamFile(datos);
        return "Reproducción por streaming: " + archivo;
    }
}

