package co.edu.udistrital.model;

public class AdaptadorWAV implements FuenteAudio {
    private FuenteWAVExterna wav;

    public AdaptadorWAV(FuenteWAVExterna wav) {
        this.wav = wav;
    }

    @Override
    public String reproducir(String archivo) {
        wav.start(archivo);
        return "WAV externo adaptado: " + archivo;
    }
}