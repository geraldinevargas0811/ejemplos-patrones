package co.edu.udistrital.model;

public class ReproductorMP3 implements FuenteAudio {
    @Override
    public String reproducir(String archivo) {
        return "Reproduciendo MP3: " + archivo;
    }
}