package co.edu.udistrital.model;

public class FuenteOGGVintage {
	public String loadAndPlay(String name) {
        return "OGG vintage playing: " + name;
    }
}
