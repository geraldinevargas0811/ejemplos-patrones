package co.edu.udistrital.model;

public class AdaptadorOGG implements FuenteAudio {
    private FuenteOGGVintage ogg;

    public AdaptadorOGG(FuenteOGGVintage ogg) {
        this.ogg = ogg;
    }

    @Override
    public String reproducir(String archivo) {
        return ogg.loadAndPlay(archivo);
    }
}
