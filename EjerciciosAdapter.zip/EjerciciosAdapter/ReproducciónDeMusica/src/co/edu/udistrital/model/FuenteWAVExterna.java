package co.edu.udistrital.model;

public class FuenteWAVExterna {
	public void start(String file) {
        System.out.println("WAV externo reproduciendo: " + file);
    }
}
