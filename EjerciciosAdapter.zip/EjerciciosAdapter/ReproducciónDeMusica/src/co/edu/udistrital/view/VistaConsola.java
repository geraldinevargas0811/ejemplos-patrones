package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarReproduccion(String nombre, String mensaje) {
        System.out.println(nombre + ": " + mensaje);
    }
}
