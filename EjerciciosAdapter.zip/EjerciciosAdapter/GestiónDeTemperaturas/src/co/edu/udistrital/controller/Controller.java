package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutarLecturas() {
        SensorTemperatura sensor1 = new SensorCelsius();
        SensorTemperatura sensor2 = new AdaptadorFahrenheit(new SensorFahrenheitExterno());
        SensorTemperatura sensor3 = new AdaptadorKelvin(new SensorKelvinExterno());

        vista.mostrarTemperatura("Celsius Interno", sensor1.leerTemperatura());
        vista.mostrarTemperatura("Fahrenheit Externo", sensor2.leerTemperatura());
        vista.mostrarTemperatura("Kelvin Externo", sensor3.leerTemperatura());
    }
}
