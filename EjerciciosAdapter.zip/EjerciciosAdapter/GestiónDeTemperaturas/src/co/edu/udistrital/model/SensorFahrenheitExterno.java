package co.edu.udistrital.model;

public class SensorFahrenheitExterno {
	public double getFahrenheit() {
        return 75.2; 
    }
}
