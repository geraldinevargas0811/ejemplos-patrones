package co.edu.udistrital.model;

public class SensorCelsius implements SensorTemperatura {
    @Override
    public double leerTemperatura() {
        return 22.5;
    }
}