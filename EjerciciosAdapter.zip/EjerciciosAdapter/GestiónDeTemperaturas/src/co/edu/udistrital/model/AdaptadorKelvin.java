package co.edu.udistrital.model;

public class AdaptadorKelvin implements SensorTemperatura {
    private SensorKelvinExterno sensor;

    public AdaptadorKelvin(SensorKelvinExterno sensor) {
        this.sensor = sensor;
    }

    @Override
    public double leerTemperatura() {
        return sensor.getKelvin() - 273.15;
    }
}