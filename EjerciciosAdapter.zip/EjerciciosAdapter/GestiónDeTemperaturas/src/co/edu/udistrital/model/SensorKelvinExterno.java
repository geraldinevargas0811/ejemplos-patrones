package co.edu.udistrital.model;

public class SensorKelvinExterno {
	public double getKelvin() {
        return 295.15;
    }
}
