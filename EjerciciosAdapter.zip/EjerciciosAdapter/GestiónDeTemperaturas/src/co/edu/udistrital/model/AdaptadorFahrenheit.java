package co.edu.udistrital.model;

public class AdaptadorFahrenheit implements SensorTemperatura {
    private SensorFahrenheitExterno sensor;

    public AdaptadorFahrenheit(SensorFahrenheitExterno sensor) {
        this.sensor = sensor;
    }

    @Override
    public double leerTemperatura() {
        return (sensor.getFahrenheit() - 32) * 5.0 / 9.0;
    }
}