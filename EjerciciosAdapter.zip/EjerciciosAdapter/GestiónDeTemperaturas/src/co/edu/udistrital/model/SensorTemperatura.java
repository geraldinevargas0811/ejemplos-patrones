package co.edu.udistrital.model;

public interface SensorTemperatura {
	double leerTemperatura();
}
