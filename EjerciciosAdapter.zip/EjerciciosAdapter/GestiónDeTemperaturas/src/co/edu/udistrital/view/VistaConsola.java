package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarTemperatura(String nombre, double valor) {
        System.out.printf("Sensor %s: %.2f °C%n", nombre, valor);
    }
}
