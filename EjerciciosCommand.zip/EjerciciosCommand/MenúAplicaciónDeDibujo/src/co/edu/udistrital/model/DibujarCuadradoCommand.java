package co.edu.udistrital.model;

public class DibujarCuadradoCommand implements Comando {
    private Lienzo lienzo;

    public DibujarCuadradoCommand(Lienzo lienzo) {
        this.lienzo = lienzo;
    }

    @Override
    public String ejecutar() {
        return lienzo.dibujar("Cuadrado");
    }
}
