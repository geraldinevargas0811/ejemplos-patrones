package co.edu.udistrital.model;

public class BorrarLienzoCommand implements Comando {
    private Lienzo lienzo;

    public BorrarLienzoCommand(Lienzo lienzo) {
        this.lienzo = lienzo;
    }

    @Override
    public String ejecutar() {
        return lienzo.borrar();
    }
}
