package co.edu.udistrital.model;

public class DibujarCirculoCommand implements Comando {
    private Lienzo lienzo;

    public DibujarCirculoCommand(Lienzo lienzo) {
        this.lienzo = lienzo;
    }

    @Override
    public String ejecutar() {
        return lienzo.dibujar("Círculo");
    }
}
