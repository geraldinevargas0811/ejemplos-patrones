package co.edu.udistrital.model;

public class BotonAccion {
    private Comando comando;

    public void setComando(Comando comando) {
        this.comando = comando;
    }

    public String presionar() {
        if (comando != null) {
            return comando.ejecutar();
        }
        return "No hay comando asignado.";
    }
}
