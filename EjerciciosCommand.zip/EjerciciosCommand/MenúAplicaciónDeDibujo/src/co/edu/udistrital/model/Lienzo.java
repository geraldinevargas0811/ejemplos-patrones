package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Lienzo {
    private List<String> contenido = new ArrayList<>();

    public String dibujar(String figura) {
        contenido.add(figura);
        return "Se dibujó un " + figura + " en el lienzo.";
    }

    public String borrar() {
        contenido.clear();
        return "Lienzo borrado.";
    }
}
