package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Lienzo lienzo = new Lienzo();

        Comando dibujarCirculo = new DibujarCirculoCommand(lienzo);
        Comando dibujarCuadrado = new DibujarCuadradoCommand(lienzo);
        Comando borrar = new BorrarLienzoCommand(lienzo);

        BotonAccion boton = new BotonAccion();

        boton.setComando(dibujarCirculo);
        vista.mostrar(boton.presionar());

        boton.setComando(dibujarCuadrado);
        vista.mostrar(boton.presionar());

        boton.setComando(borrar);
        vista.mostrar(boton.presionar());

        boton.setComando(dibujarCuadrado);
        vista.mostrar(boton.presionar());
    }
}

