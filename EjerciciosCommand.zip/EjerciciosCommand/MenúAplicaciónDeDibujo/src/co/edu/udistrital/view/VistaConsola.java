package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrar(String mensaje) {
        System.out.println("[Aplicación de dibujo]");
        System.out.println(mensaje);
    }
}
