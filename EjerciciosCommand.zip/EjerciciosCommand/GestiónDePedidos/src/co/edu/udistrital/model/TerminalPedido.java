package co.edu.udistrital.model;

public class TerminalPedido {
    private Comando comando;

    public void setComando(Comando comando) {
        this.comando = comando;
    }

    public String ejecutarComando() {
        if (comando != null) {
            return comando.ejecutar();
        }
        return "No hay comando asignado.";
    }
}

