package co.edu.udistrital.model;

public class PrepararTeCommand implements Comando {
    private Barista barista;

    public PrepararTeCommand(Barista barista) {
        this.barista = barista;
    }

    @Override
    public String ejecutar() {
        return barista.prepararTe();
    }
}

