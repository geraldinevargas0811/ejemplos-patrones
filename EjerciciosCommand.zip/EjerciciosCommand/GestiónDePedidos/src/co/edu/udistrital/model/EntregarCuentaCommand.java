package co.edu.udistrital.model;

public class EntregarCuentaCommand implements Comando {
    private Barista barista;

    public EntregarCuentaCommand(Barista barista) {
        this.barista = barista;
    }

    @Override
    public String ejecutar() {
        return barista.entregarCuenta();
    }
}
