package co.edu.udistrital.model;

public class PrepararCafeCommand implements Comando {
    private Barista barista;

    public PrepararCafeCommand(Barista barista) {
        this.barista = barista;
    }

    @Override
    public String ejecutar() {
        return barista.prepararCafe();
    }
}

