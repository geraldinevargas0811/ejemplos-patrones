package co.edu.udistrital.model;

public class Barista {
    public String prepararCafe() {
        return "☕ Se preparó un café.";
    }

    public String prepararTe() {
        return "🍵 Se preparó un té.";
    }

    public String entregarCuenta() {
        return "🧾 Se entregó la cuenta.";
    }
}

