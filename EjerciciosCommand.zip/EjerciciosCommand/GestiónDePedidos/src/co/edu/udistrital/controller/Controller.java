package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Barista barista = new Barista();

        Comando cafe = new PrepararCafeCommand(barista);
        Comando te = new PrepararTeCommand(barista);
        Comando cuenta = new EntregarCuentaCommand(barista);

        TerminalPedido terminal = new TerminalPedido();

        terminal.setComando(cafe);
        vista.mostrar(terminal.ejecutarComando());

        terminal.setComando(te);
        vista.mostrar(terminal.ejecutarComando());

        terminal.setComando(cuenta);
        vista.mostrar(terminal.ejecutarComando());
    }
}

