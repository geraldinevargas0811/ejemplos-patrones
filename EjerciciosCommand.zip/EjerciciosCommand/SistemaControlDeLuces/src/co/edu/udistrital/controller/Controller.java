package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Luz luzSala = new Luz("sala");
        Luz luzCocina = new Luz("cocina");

        Comando encenderSala = new EncenderLuzCommand(luzSala);
        Comando apagarSala = new ApagarLuzCommand(luzSala);
        Comando encenderCocina = new EncenderLuzCommand(luzCocina);

        ControlRemoto control = new ControlRemoto();

        control.setComando(encenderSala);
        vista.mostrar(control.presionarBoton());

        control.setComando(encenderCocina);
        vista.mostrar(control.presionarBoton());

        control.setComando(apagarSala);
        vista.mostrar(control.presionarBoton());
    }
}

