package co.edu.udistrital.model;

public class Luz {
    private String ubicacion;
    private boolean estado; // false = apagada, true = encendida

    public Luz(String ubicacion) {
        this.ubicacion = ubicacion;
        this.estado = false;
    }

    public String encender() {
        if (!estado) {
            estado = true;
            return "Luz de " + ubicacion + " encendida.";
        }
        return "La luz de " + ubicacion + " ya estaba encendida.";
    }

    public String apagar() {
        if (estado) {
            estado = false;
            return "Luz de " + ubicacion + " apagada.";
        }
        return "La luz de " + ubicacion + " ya estaba apagada.";
    }
}

