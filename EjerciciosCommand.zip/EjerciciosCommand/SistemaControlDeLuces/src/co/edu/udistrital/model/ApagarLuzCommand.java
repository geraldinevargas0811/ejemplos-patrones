package co.edu.udistrital.model;

public class ApagarLuzCommand implements Comando {
    private Luz luz;

    public ApagarLuzCommand(Luz luz) {
        this.luz = luz;
    }

    @Override
    public String ejecutar() {
        return luz.apagar();
    }
}
