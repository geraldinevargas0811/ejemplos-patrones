package co.edu.udistrital.model;

public class EncenderLuzCommand implements Comando {
    private Luz luz;

    public EncenderLuzCommand(Luz luz) {
        this.luz = luz;
    }

    @Override
    public String ejecutar() {
        return luz.encender();
    }
}
