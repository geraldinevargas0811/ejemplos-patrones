package co.edu.udistrital.model;

public class ControlRemoto {
    private Comando comando;

    public void setComando(Comando comando) {
        this.comando = comando;
    }

    public String presionarBoton() {
        if (comando != null) {
            return comando.ejecutar();
        }
        return "No se ha asignado un comando.";
    }
}

