package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrar(String texto) {
        System.out.println("[Sistema Domótico]");
        System.out.println(texto);
    }
}
