package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        CalculadoraImpuestos calculadora = new CalculadoraImpuestos();
        double ingreso = 25000;

        calculadora.setEstrategia(new PersonaNatural());
        vista.mostrar("Persona Natural (ingreso " + ingreso + "): $" + calculadora.calcularImpuesto(ingreso));

        calculadora.setEstrategia(new PersonaJuridica());
        vista.mostrar("Persona Jurídica (ingreso " + ingreso + "): $" + calculadora.calcularImpuesto(ingreso));

        calculadora.setEstrategia(new Emprendedor());
        vista.mostrar("Emprendedor (ingreso " + ingreso + "): $" + calculadora.calcularImpuesto(ingreso));
    }
}
