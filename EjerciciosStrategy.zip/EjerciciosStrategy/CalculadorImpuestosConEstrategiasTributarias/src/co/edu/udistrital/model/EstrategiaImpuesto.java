package co.edu.udistrital.model;

public interface EstrategiaImpuesto {
	double calcular(double ingreso);
}
