package co.edu.udistrital.model;

public class Emprendedor implements EstrategiaImpuesto {
    @Override
    public double calcular(double ingreso) {
        if (ingreso < 20000) {
            return ingreso * 0.10;
        } else {
            return ingreso * 0.20;
        }
    }
}

