package co.edu.udistrital.model;

public class CalculadoraImpuestos {
    private EstrategiaImpuesto estrategia;

    public void setEstrategia(EstrategiaImpuesto estrategia) {
        this.estrategia = estrategia;
    }

    public double calcularImpuesto(double ingreso) {
        if (estrategia == null) {
            throw new IllegalStateException("No se ha asignado una estrategia.");
        }
        return estrategia.calcular(ingreso);
    }
}
