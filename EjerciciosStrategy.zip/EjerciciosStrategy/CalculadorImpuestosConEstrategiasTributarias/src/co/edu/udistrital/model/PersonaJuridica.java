package co.edu.udistrital.model;

public class PersonaJuridica implements EstrategiaImpuesto {
    @Override
    public double calcular(double ingreso) {
        return ingreso * 0.30 + 1000; // impuesto base
    }
}

