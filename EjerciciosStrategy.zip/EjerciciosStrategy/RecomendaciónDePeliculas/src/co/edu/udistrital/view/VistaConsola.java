package co.edu.udistrital.view;

import co.edu.udistrital.model.*;
import java.util.List;

public class VistaConsola {
    public void mostrar(String mensaje) {
        System.out.println("\n[Recomendador de Películas]");
        System.out.println(mensaje);
    }

    public void mostrarPeliculas(List<Pelicula> peliculas) {
        for (Pelicula p : peliculas) {
            System.out.println("- " + p);
        }
    }
}
