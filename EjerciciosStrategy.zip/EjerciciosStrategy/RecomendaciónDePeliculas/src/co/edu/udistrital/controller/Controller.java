package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.ArrayList;
import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        List<Pelicula> catalogo = new ArrayList<>();
        catalogo.add(new Pelicula("Inception", "Ciencia Ficción", 9.0, 95));
        catalogo.add(new Pelicula("Titanic", "Romance", 8.5, 80));
        catalogo.add(new Pelicula("Avengers", "Acción", 8.8, 100));
        catalogo.add(new Pelicula("Interstellar", "Ciencia Ficción", 9.3, 88));
        catalogo.add(new Pelicula("Amélie", "Comedia", 8.4, 75));

        Recomendador recomendador = new Recomendador();

        recomendador.setEstrategia(new PorGenero("Ciencia Ficción"));
        vista.mostrar("🎬 Recomendación por género: Ciencia Ficción");
        vista.mostrarPeliculas(recomendador.recomendar(catalogo));

        recomendador.setEstrategia(new PorCalificacion());
        vista.mostrar("⭐ Recomendación por calificación:");
        vista.mostrarPeliculas(recomendador.recomendar(catalogo));

        recomendador.setEstrategia(new PorPopularidad());
        vista.mostrar("🔥 Recomendación por popularidad:");
        vista.mostrarPeliculas(recomendador.recomendar(catalogo));
    }
}
