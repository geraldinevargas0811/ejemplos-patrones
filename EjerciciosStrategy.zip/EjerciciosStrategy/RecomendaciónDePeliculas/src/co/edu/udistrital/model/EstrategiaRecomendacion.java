package co.edu.udistrital.model;

import java.util.List;

public interface EstrategiaRecomendacion {
    List<Pelicula> recomendar(List<Pelicula> catalogo);
}
