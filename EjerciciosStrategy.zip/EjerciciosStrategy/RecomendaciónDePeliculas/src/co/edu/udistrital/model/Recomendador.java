package co.edu.udistrital.model;

import java.util.List;

public class Recomendador {
    private EstrategiaRecomendacion estrategia;

    public void setEstrategia(EstrategiaRecomendacion estrategia) {
        this.estrategia = estrategia;
    }

    public List<Pelicula> recomendar(List<Pelicula> catalogo) {
        if (estrategia == null) {
            throw new IllegalStateException("No se ha asignado una estrategia.");
        }
        return estrategia.recomendar(catalogo);
    }
}
