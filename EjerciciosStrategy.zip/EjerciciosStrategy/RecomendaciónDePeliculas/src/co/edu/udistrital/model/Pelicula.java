package co.edu.udistrital.model;

public class Pelicula {
    private String titulo;
    private String genero;
    private double calificacion;
    private int popularidad;

    public Pelicula(String titulo, String genero, double calificacion, int popularidad) {
        this.titulo = titulo;
        this.genero = genero;
        this.calificacion = calificacion;
        this.popularidad = popularidad;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getGenero() {
        return genero;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public int getPopularidad() {
        return popularidad;
    }

    @Override
    public String toString() {
        return titulo + " (" + genero + ", ⭐ " + calificacion + ", 🔥 " + popularidad + ")";
    }
}

