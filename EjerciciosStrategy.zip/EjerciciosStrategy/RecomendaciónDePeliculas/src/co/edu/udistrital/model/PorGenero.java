package co.edu.udistrital.model;

import java.util.List;
import java.util.stream.Collectors;

public class PorGenero implements EstrategiaRecomendacion {
    private String generoDeseado;

    public PorGenero(String generoDeseado) {
        this.generoDeseado = generoDeseado;
    }

    @Override
    public List<Pelicula> recomendar(List<Pelicula> catalogo) {
        return catalogo.stream()
                .filter(p -> p.getGenero().equalsIgnoreCase(generoDeseado))
                .collect(Collectors.toList());
    }
}

