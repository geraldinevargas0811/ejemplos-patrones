package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        String mensaje = "Hola Mundo";
        Encriptador encriptador = new Encriptador();

        encriptador.setEstrategia(new Reversa());
        vista.mostrar("🔁 Reversa: " + encriptador.encriptarMensaje(mensaje));

        encriptador.setEstrategia(new Cesar(3));
        vista.mostrar("🔐 César (3): " + encriptador.encriptarMensaje(mensaje));

        encriptador.setEstrategia(new SustitucionVocales());
        vista.mostrar("🅰️ Sustitución de vocales: " + encriptador.encriptarMensaje(mensaje));
    }
}

