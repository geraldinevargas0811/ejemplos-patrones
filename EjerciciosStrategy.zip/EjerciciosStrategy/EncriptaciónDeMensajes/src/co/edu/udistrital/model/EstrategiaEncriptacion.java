package co.edu.udistrital.model;

public interface EstrategiaEncriptacion {
    String encriptar(String mensaje);
}
