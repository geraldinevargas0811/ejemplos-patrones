package co.edu.udistrital.model;

public class Reversa implements EstrategiaEncriptacion {

    @Override
    public String encriptar(String mensaje) {
        return new StringBuilder(mensaje).reverse().toString();
    }
}
