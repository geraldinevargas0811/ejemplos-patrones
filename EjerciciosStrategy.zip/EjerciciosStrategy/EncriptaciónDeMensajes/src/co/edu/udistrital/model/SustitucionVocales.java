package co.edu.udistrital.model;

public class SustitucionVocales implements EstrategiaEncriptacion {

    @Override
    public String encriptar(String mensaje) {
        return mensaje.replaceAll("[aeiouAEIOU]", "*");
    }
}
