package co.edu.udistrital.model;

public class Cesar implements EstrategiaEncriptacion {
    private int desplazamiento;

    public Cesar(int desplazamiento) {
        this.desplazamiento = desplazamiento;
    }

    @Override
    public String encriptar(String mensaje) {
        StringBuilder resultado = new StringBuilder();

        for (char c : mensaje.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                char cifrado = (char) ((c - base + desplazamiento) % 26 + base);
                resultado.append(cifrado);
            } else {
                resultado.append(c);
            }
        }

        return resultado.toString();
    }
}

