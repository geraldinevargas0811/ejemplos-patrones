package co.edu.udistrital.model;

public class Encriptador {
    private EstrategiaEncriptacion estrategia;

    public void setEstrategia(EstrategiaEncriptacion estrategia) {
        this.estrategia = estrategia;
    }

    public String encriptarMensaje(String mensaje) {
        if (estrategia == null) {
            throw new IllegalStateException("No se ha definido estrategia.");
        }
        return estrategia.encriptar(mensaje);
    }
}
