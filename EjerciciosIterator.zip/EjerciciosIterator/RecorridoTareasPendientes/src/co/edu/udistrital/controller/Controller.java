package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Agenda agenda = new Agenda();

        agenda.agregarTarea(new Tarea("Enviar informe", 1));
        agenda.agregarTarea(new Tarea("Revisar correos", 2));
        agenda.agregarTarea(new Tarea("Llamar a proveedor", 1));
        agenda.agregarTarea(new Tarea("Leer capítulo del libro", 3));

        Iterador iterador = agenda.crearIterador();

        while (iterador.tieneSiguiente()) {
            Tarea tarea = iterador.siguiente();
            String info = "Tarea: " + tarea.getNombre() + " | Prioridad: " + tarea.getPrioridad();
            vista.mostrarTarea(info);
        }
    }
}
