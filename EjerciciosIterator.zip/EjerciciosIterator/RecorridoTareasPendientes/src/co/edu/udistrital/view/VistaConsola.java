package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarTarea(String texto) {
        System.out.println("[Tarea]");
        System.out.println(texto);
    }
}
