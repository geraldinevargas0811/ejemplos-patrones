package co.edu.udistrital.model;

import java.util.List;

public class IteradorAgenda implements Iterador {
    private List<Tarea> tareas;
    private int posicion = 0;

    public IteradorAgenda(List<Tarea> tareas) {
        this.tareas = tareas;
    }

    @Override
    public boolean tieneSiguiente() {
        return posicion < tareas.size();
    }

    @Override
    public Tarea siguiente() {
        if (tieneSiguiente()) {
            return tareas.get(posicion++);
        }
        return null;
    }
}
