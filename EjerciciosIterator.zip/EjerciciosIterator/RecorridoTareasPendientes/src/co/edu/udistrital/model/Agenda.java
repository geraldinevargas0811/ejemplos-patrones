package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Agenda {
    private List<Tarea> tareas;

    public Agenda() {
        tareas = new ArrayList<>();
    }

    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }

    public Iterador crearIterador() {
        return new IteradorAgenda(tareas);
    }
}
