package co.edu.udistrital.model;

public interface Iterador {
	boolean tieneSiguiente();
    Tarea siguiente();
}
