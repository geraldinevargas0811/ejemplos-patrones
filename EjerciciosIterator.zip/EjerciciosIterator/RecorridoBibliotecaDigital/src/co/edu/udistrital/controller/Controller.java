package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Biblioteca biblioteca = new Biblioteca();

        biblioteca.agregarLibro(new Libro("1984", "George Orwell"));
        biblioteca.agregarLibro(new Libro("Crónica de una muerte anunciada", "Gabriel García Márquez"));
        biblioteca.agregarLibro(new Libro("Fahrenheit 451", "Ray Bradbury"));

        Iterador iterador = biblioteca.crearIterador();

        while (iterador.tieneSiguiente()) {
            Libro libro = iterador.siguiente();
            vista.mostrarLibro("Título: " + libro.getTitulo() + " | Autor: " + libro.getAutor());
        }
    }
}
