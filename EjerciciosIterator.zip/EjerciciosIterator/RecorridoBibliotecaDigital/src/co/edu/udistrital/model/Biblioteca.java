package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Libro> libros;

    public Biblioteca() {
        libros = new ArrayList<>();
    }

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public Iterador crearIterador() {
        return new IteradorBiblioteca(libros);
    }
}
