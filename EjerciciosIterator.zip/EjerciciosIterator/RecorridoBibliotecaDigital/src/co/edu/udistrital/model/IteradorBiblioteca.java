package co.edu.udistrital.model;

import java.util.List;

public class IteradorBiblioteca implements Iterador {
    private List<Libro> libros;
    private int posicion = 0;

    public IteradorBiblioteca(List<Libro> libros) {
        this.libros = libros;
    }

    @Override
    public boolean tieneSiguiente() {
        return posicion < libros.size();
    }

    @Override
    public Libro siguiente() {
        if (tieneSiguiente()) {
            return libros.get(posicion++);
        }
        return null;
    }
}
