package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarLibro(String texto) {
        System.out.println("[Libro]");
        System.out.println(texto);
    }
}
