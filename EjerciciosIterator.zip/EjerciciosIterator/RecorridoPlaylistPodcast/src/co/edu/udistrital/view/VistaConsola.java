package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarEpisodio(String texto) {
        System.out.println("-----Reproduciendo Podcast-----");
        System.out.println(texto);
    }
}
