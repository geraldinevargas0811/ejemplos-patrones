package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Playlist playlist = new Playlist();

        playlist.agregarEpisodio(new Episodio("Intro al desarrollo", 12));
        playlist.agregarEpisodio(new Episodio("Patrones de diseño", 18));
        playlist.agregarEpisodio(new Episodio("Entrevista con un ingeniero", 24));

        Iterador iterador = playlist.crearIterador();

        while (iterador.tieneSiguiente()) {
            Episodio ep = iterador.siguiente();
            String info = "Título: " + ep.getTitulo() + " | Duración: " + ep.getDuracionMin() + " min";
            vista.mostrarEpisodio(info);
        }
    }
}
