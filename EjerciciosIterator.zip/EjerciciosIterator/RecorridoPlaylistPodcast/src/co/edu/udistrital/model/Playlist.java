package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Playlist {
    private List<Episodio> episodios;

    public Playlist() {
        episodios = new ArrayList<>();
    }

    public void agregarEpisodio(Episodio ep) {
        episodios.add(ep);
    }

    public Iterador crearIterador() {
        return new IteradorPlaylist(episodios);
    }
}

