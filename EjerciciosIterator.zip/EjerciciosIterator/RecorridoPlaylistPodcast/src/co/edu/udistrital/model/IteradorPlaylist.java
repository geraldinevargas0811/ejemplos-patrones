package co.edu.udistrital.model;

import java.util.List;

public class IteradorPlaylist implements Iterador {
    private List<Episodio> episodios;
    private int posicion = 0;

    public IteradorPlaylist(List<Episodio> episodios) {
        this.episodios = episodios;
    }

    @Override
    public boolean tieneSiguiente() {
        return posicion < episodios.size();
    }

    @Override
    public Episodio siguiente() {
        if (tieneSiguiente()) {
            return episodios.get(posicion++);
        }
        return null;
    }
}
