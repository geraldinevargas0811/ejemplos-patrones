package co.edu.udistrital.model;

public class Episodio {
    private String titulo;
    private int duracionMin;

    public Episodio(String titulo, int duracionMin) {
        this.titulo = titulo;
        this.duracionMin = duracionMin;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracionMin() {
        return duracionMin;
    }
}

