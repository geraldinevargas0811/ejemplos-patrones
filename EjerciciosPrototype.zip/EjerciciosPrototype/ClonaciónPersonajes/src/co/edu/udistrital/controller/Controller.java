package co.edu.udistrital.controller;

import co.edu.udistrital.model.Personaje;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		Personaje base = new Personaje("Guerrero Base", "Guerrero", 1, 100);
		vista.mostrarInformacion("Personaje Base:");
		mostrarPersonaje(base);

		Personaje mago = base.clone();
		mago.setNombre("Mago del Fuego");
		mago.setTipo("Mago");
		mago.setNivel(3);
		mago.setSalud(80);

		Personaje arquero = base.clone();
		arquero.setNombre("Arquero Silencioso");
		arquero.setTipo("Arquero");
		arquero.setNivel(2);
		arquero.setSalud(90);

		vista.mostrarInformacion("\nPersonaje Clonado 1:");
		mostrarPersonaje(mago);

		vista.mostrarInformacion("\nPersonaje Clonado 2:");
		mostrarPersonaje(arquero);
	}

	private void mostrarPersonaje(Personaje p) {
		vista.mostrarInformacion("Nombre: " + p.getNombre());
		vista.mostrarInformacion("Tipo: " + p.getTipo());
		vista.mostrarInformacion("Nivel: " + p.getNivel());
		vista.mostrarInformacion("Salud: " + p.getSalud());
	}
}
