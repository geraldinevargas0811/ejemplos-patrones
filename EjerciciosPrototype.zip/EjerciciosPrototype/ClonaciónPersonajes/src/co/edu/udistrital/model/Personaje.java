package co.edu.udistrital.model;

public class Personaje implements Cloneable {

	private String nombre;
	private String tipo;
	private int nivel;
	private int salud;

	public Personaje(String nombre, String tipo, int nivel, int salud) {
		this.nombre = nombre;
		this.tipo = tipo;
		this.nivel = nivel;
		this.salud = salud;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public int getSalud() {
		return salud;
	}

	public void setSalud(int salud) {
		this.salud = salud;
	}

	@Override
	public Personaje clone() {
		try {
			return (Personaje) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new AssertionError("No se pudo clonar el personaje.");
		}
	}
}
