/**
 * 
 */
/**
 * 
 */
module ClonaciónFiguras {
}