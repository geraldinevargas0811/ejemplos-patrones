package co.edu.udistrital.controller;

import co.edu.udistrital.model.Configuracion;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		Configuracion configBase = new Configuracion("Oscuro", "Arial", true);
		vista.mostrarInformacion("Configuración Base:");
		vista.mostrarInformacion("Tema: " + configBase.getTema());
		vista.mostrarInformacion("Fuente: " + configBase.getFuente());
		vista.mostrarInformacion("Notificaciones: " + (configBase.isNotificacionesActivadas() ? "Activadas" : "Desactivadas"));

		Configuracion configUsuario1 = configBase.clone();
		configUsuario1.setTema("Claro");
		configUsuario1.setFuente("Calibri");

		vista.mostrarInformacion("\nConfiguración Usuario 1 (Clon):");
		vista.mostrarInformacion("Tema: " + configUsuario1.getTema());
		vista.mostrarInformacion("Fuente: " + configUsuario1.getFuente());
		vista.mostrarInformacion("Notificaciones: " + (configUsuario1.isNotificacionesActivadas() ? "Activadas" : "Desactivadas"));

		Configuracion configUsuario2 = configBase.clone();
		configUsuario2.setTema("Alto Contraste");
		configUsuario2.setFuente("Verdana");
		configUsuario2.setNotificacionesActivadas(false);

		vista.mostrarInformacion("\nConfiguración Usuario 2 (Clon):");
		vista.mostrarInformacion("Tema: " + configUsuario2.getTema());
		vista.mostrarInformacion("Fuente: " + configUsuario2.getFuente());
		vista.mostrarInformacion("Notificaciones: " + (configUsuario2.isNotificacionesActivadas() ? "Activadas" : "Desactivadas"));
	}
}
