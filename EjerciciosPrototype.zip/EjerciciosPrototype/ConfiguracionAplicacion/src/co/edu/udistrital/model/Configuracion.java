package co.edu.udistrital.model;

public class Configuracion implements Cloneable {

	private String tema;
	private String fuente;
	private boolean notificacionesActivadas;

	public Configuracion(String tema, String fuente, boolean notificacionesActivadas) {
		this.tema = tema;
		this.fuente = fuente;
		this.notificacionesActivadas = notificacionesActivadas;
	}

	public String getTema() {
		return tema;
	}

	public void setTema(String tema) {
		this.tema = tema;
	}

	public String getFuente() {
		return fuente;
	}

	public void setFuente(String fuente) {
		this.fuente = fuente;
	}

	public boolean isNotificacionesActivadas() {
		return notificacionesActivadas;
	}

	public void setNotificacionesActivadas(boolean notificacionesActivadas) {
		this.notificacionesActivadas = notificacionesActivadas;
	}

	@Override
	public Configuracion clone() {
		try {
			return (Configuracion) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new AssertionError("No se pudo clonar Configuracion");
		}
	}
}
