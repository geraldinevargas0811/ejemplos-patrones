package co.edu.udistrital.controller;

import co.edu.udistrital.model.Empleado;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		vista.mostrarInformacion("=== Registro de Empleados (Prototype) ===");

		Empleado empleadoBase = new Empleado("GENÉRICO", "Auxiliar", "Indefinido", 1800000);

		int cantidad = 3;
		for (int i = 1; i <= cantidad; i++) {
			vista.mostrarInformacion("\n--- Registro del empleado #" + i + " ---");
			String nombre = vista.leerTexto("Nombre del empleado: ");
			double salario = vista.leerDatoDecimal("Salario del empleado: ");

			Empleado nuevo = empleadoBase.clone();
			nuevo.setNombre(nombre);
			nuevo.setSalario(salario);

			vista.mostrarInformacion("\nEmpleado registrado:");
			mostrarEmpleado(nuevo);
		}
	}

	private void mostrarEmpleado(Empleado e) {
		vista.mostrarInformacion("Nombre: " + e.getNombre());
		vista.mostrarInformacion("Cargo: " + e.getCargo());
		vista.mostrarInformacion("Tipo de contrato: " + e.getTipoContrato());
		vista.mostrarInformacion("Salario: $" + e.getSalario());
	}
}