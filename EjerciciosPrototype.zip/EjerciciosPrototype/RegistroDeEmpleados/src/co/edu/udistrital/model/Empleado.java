package co.edu.udistrital.model;

public class Empleado implements Cloneable {

	private String nombre;
	private String cargo;
	private String tipoContrato;
	private double salario;

	public Empleado(String nombre, String cargo, String tipoContrato, double salario) {
		this.nombre = nombre;
		this.cargo = cargo;
		this.tipoContrato = tipoContrato;
		this.salario = salario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getTipoContrato() {
		return tipoContrato;
	}

	public void setTipoContrato(String tipoContrato) {
		this.tipoContrato = tipoContrato;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	@Override
	public Empleado clone() {
		try {
			return (Empleado) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new AssertionError("No se pudo clonar el empleado.");
		}
	}
}
