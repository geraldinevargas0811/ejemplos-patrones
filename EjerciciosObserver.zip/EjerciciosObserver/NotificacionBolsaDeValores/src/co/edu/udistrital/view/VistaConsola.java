package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrar(String mensaje) {
        System.out.println("$$ Sistema Bolsa $$");
        System.out.println(mensaje);
    }
}
