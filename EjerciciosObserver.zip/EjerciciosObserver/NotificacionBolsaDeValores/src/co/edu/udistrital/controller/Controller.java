package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Accion apple = new Accion("AAPL", 120.0);
        Observador alerta = new AlertaPrecioMinimo(100.0);
        Observador recomendacion = new RecomendacionVenta();

        apple.agregarObservador(alerta);
        apple.agregarObservador(recomendacion);

        vista.mostrar("🧾 Cambio de valor: $95.0");
        List<String> mensajes = apple.setValor(95.0);
        for (String msg : mensajes) {
            vista.mostrar(msg);
        }

        vista.mostrar("🧾 Cambio de valor: $160.0");
        mensajes = apple.setValor(160.0);
        for (String msg : mensajes) {
            vista.mostrar(msg);
        }
    }
}
