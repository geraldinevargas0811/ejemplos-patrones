package co.edu.udistrital.model;

public class RecomendacionVenta implements Observador {

    @Override
    public String actualizar(double nuevoValor) {
        if (nuevoValor > 150.0) {
            return "📢 Recomendación: ¡Vende tus acciones ahora!";
        } else {
            return "📊 Sugerencia: Espera un poco más.";
        }
    }
}

