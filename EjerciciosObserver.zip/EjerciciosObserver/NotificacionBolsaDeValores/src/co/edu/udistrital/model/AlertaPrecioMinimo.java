package co.edu.udistrital.model;

public class AlertaPrecioMinimo implements Observador {
    private double umbral;

    public AlertaPrecioMinimo(double umbral) {
        this.umbral = umbral;
    }

    @Override
    public String actualizar(double nuevoValor) {
        if (nuevoValor < umbral) {
            return "⚠️ ¡Alerta! El valor bajó del umbral mínimo (" + umbral + ")";
        } else {
            return "✅ Valor actual por encima del umbral mínimo.";
        }
    }
}

