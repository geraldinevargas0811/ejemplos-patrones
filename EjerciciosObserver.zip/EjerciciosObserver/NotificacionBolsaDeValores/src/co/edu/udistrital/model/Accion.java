package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Accion implements Sujeto {
    private List<Observador> observadores;
    private String nombre;
    private double valor;

    public Accion(String nombre, double valorInicial) {
        this.nombre = nombre;
        this.valor = valorInicial;
        this.observadores = new ArrayList<>();
    }

    public List<String> setValor(double nuevoValor) {
        this.valor = nuevoValor;
        return notificarObservadores();
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public void agregarObservador(Observador o) {
        observadores.add(o);
    }

    @Override
    public void eliminarObservador(Observador o) {
        observadores.remove(o);
    }

    @Override
    public List<String> notificarObservadores() {
        List<String> mensajes = new ArrayList<>();
        for (Observador o : observadores) {
            mensajes.add(o.actualizar(valor));
        }
        return mensajes;
    }
}
