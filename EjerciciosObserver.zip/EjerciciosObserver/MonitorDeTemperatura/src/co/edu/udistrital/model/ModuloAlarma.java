package co.edu.udistrital.model;

public class ModuloAlarma implements Observador {
    @Override
    public String actualizar(int nuevaTemperatura) {
        if (nuevaTemperatura > 35) {
            return "🚨 Alarma activada: temperatura excesiva.";
        }
        return "✅ Temperatura bajo control.";
    }
}
