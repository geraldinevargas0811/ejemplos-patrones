package co.edu.udistrital.model;

public class ModuloRiego implements Observador {
    @Override
    public String actualizar(int nuevaTemperatura) {
        if (nuevaTemperatura < 20) {
            return "☁️ El módulo de riego permanece apagado.";
        } else {
            return "💧 El módulo de riego se ha activado.";
        }
    }
}
