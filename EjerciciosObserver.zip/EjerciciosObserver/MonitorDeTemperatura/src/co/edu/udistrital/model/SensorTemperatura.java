package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class SensorTemperatura implements Sujeto {
    private List<Observador> observadores;
    private int temperatura;

    public SensorTemperatura() {
        observadores = new ArrayList<>();
    }

    public List<String> setTemperatura(int t) {
        this.temperatura = t;
        return notificarObservadores();
    }

    @Override
    public void agregarObservador(Observador o) {
        observadores.add(o);
    }

    @Override
    public void eliminarObservador(Observador o) {
        observadores.remove(o);
    }

    @Override
    public List<String> notificarObservadores() {
        List<String> respuestas = new ArrayList<>();
        for (Observador o : observadores) {
            respuestas.add(o.actualizar(temperatura));
        }
        return respuestas;
    }
}
