package co.edu.udistrital.model;

import java.util.List;

public interface Sujeto {
    void agregarObservador(Observador o);
    void eliminarObservador(Observador o);
    List<String> notificarObservadores();
}

