package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        SensorTemperatura sensor = new SensorTemperatura();
        Observador riego = new ModuloRiego();
        Observador alarma = new ModuloAlarma();

        sensor.agregarObservador(riego);
        sensor.agregarObservador(alarma);

        List<String> mensajes = sensor.setTemperatura(22);
        for (String msg : mensajes) {
            vista.mostrarMensaje(msg);
        }

        mensajes = sensor.setTemperatura(38);
        for (String msg : mensajes) {
            vista.mostrarMensaje(msg);
        }
    }
}
