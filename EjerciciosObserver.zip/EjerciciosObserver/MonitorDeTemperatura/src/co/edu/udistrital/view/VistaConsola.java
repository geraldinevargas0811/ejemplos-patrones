package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarMensaje(String m) {
        System.out.println("-----Granja automatizada------");
        System.out.println(m);
    }
}
