package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrar(String mensaje) {
        System.out.println("[Sistema Educativo]");
        System.out.println(mensaje);
    }
}
