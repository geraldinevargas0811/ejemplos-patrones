package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Estudiante estudiante = new Estudiante("Laura Gómez");
        Observador certificacion = new ModuloCertificacion();
        Observador notificacionPadres = new ModuloNotificacionPadres("Sr. Gómez");

        estudiante.agregarObservador(certificacion);
        estudiante.agregarObservador(notificacionPadres);

        vista.mostrar("📊 Progreso actualizado al 40%");
        List<String> mensajes = estudiante.setProgreso(40);
        for (String msg : mensajes) {
            vista.mostrar(msg);
        }

        vista.mostrar("📊 Progreso actualizado al 100%");
        mensajes = estudiante.setProgreso(100);
        for (String msg : mensajes) {
            vista.mostrar(msg);
        }
    }
}

