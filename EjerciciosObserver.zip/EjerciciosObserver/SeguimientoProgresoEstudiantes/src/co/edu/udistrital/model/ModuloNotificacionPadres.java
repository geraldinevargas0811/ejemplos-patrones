package co.edu.udistrital.model;

public class ModuloNotificacionPadres implements Observador {
    private String nombrePadre;

    public ModuloNotificacionPadres(String nombrePadre) {
        this.nombrePadre = nombrePadre;
    }

    @Override
    public String actualizar(int nuevoProgreso) {
        return "📩 Notificación a " + nombrePadre + ": el estudiante tiene un progreso del " + nuevoProgreso + "%.";
    }
}
