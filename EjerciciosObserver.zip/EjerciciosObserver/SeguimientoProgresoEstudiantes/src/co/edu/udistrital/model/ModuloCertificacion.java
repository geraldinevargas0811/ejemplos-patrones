package co.edu.udistrital.model;

public class ModuloCertificacion implements Observador {

    @Override
    public String actualizar(int nuevoProgreso) {
        if (nuevoProgreso >= 100) {
            return "🎓 ¡Estudiante elegible para certificación!";
        } else {
            return "📘 Progreso actual: " + nuevoProgreso + "% (certificación aún no disponible)";
        }
    }
}
