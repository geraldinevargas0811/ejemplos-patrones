package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Estudiante implements Sujeto {
    private String nombre;
    private int progreso;
    private List<Observador> observadores;

    public Estudiante(String nombre) {
        this.nombre = nombre;
        this.progreso = 0;
        this.observadores = new ArrayList<>();
    }

    public List<String> setProgreso(int nuevoProgreso) {
        this.progreso = nuevoProgreso;
        return notificarObservadores();
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public void agregarObservador(Observador o) {
        observadores.add(o);
    }

    @Override
    public void eliminarObservador(Observador o) {
        observadores.remove(o);
    }

    @Override
    public List<String> notificarObservadores() {
        List<String> mensajes = new ArrayList<>();
        for (Observador o : observadores) {
            mensajes.add(o.actualizar(progreso));
        }
        return mensajes;
    }
}
