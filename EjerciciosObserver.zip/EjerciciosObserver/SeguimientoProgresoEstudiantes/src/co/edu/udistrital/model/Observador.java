package co.edu.udistrital.model;

public interface Observador {
	String actualizar(int nuevoProgreso);
}
