package co.edu.udistrital.model;

public interface Imagen {
	String mostrar();
}
