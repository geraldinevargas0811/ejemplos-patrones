package co.edu.udistrital.model;

public class ImagenProxy implements Imagen {
    private String nombre;
    private ImagenReal imagenReal;

    public ImagenProxy(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String mostrar() {
        if (imagenReal == null) {
            imagenReal = new ImagenReal(nombre); // carga real
        }
        return imagenReal.mostrar();
    }
}

