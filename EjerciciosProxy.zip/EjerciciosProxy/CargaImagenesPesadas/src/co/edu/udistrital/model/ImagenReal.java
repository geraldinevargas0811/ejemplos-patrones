package co.edu.udistrital.model;

public class ImagenReal implements Imagen {
    private String nombre;

    public ImagenReal(String nombre) {
        this.nombre = nombre;
        cargarDesdeDisco(nombre);
    }

    private void cargarDesdeDisco(String nombre) {
        System.out.println("Cargando imagen real '" + nombre + "' desde el disco...");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String mostrar() {
        return "Imagen mostrada: " + nombre + " [alta resolución]";
    }
}
