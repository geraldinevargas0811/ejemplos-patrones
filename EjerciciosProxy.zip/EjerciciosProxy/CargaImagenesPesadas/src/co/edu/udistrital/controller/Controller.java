package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        // Creamos la imagen en proxy (no se carga aún)
        Imagen imagen = new ImagenProxy("playa_hd.jpg");

        // Simula navegación sin abrir la imagen
        vista.mostrarMensaje("Miniatura de 'playa_hd.jpg' visible (imagen aún no cargada)");

        // Ahora el usuario decide abrirla
        String resultado = imagen.mostrar();
        vista.mostrarMensaje(resultado);
    }
}
