package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarMensaje(String texto) {
        System.out.println("[Galería de imágenes]");
        System.out.println(texto);
    }
}
