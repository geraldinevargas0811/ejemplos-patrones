package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        vista.mostrarInformacion("=== SISTEMA DE ACCESO A DOCUMENTOS ===");
        vista.mostrarInformacion("1. Admin");
        vista.mostrarInformacion("2. Gerente");
        vista.mostrarInformacion("3. Estudiante");

        int opcion = vista.leerDatoEntero("Ingrese una opción (1-3): ");
        String usuario;

        switch (opcion) {
            case 1:
                usuario = "admin";
                break;
            case 2:
                usuario = "gerente";
                break;
            case 3:
                usuario = "estudiante";
                break;
            default:
                vista.mostrarInformacion("❌ Opción inválida. Finalizando.");
                return;
        }

        Documento doc = new DocumentoProxy(usuario);
        String resultado = doc.mostrarContenido();

        vista.mostrarInformacion("\nResultado para el usuario '" + usuario + "':");
        vista.mostrarInformacion(resultado);
    }
}