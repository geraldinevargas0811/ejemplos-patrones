package co.edu.udistrital.model;

public interface Documento {
	String mostrarContenido();
}
