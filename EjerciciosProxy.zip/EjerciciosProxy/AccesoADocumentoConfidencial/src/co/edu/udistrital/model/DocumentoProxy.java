package co.edu.udistrital.model;

public class DocumentoProxy implements Documento {
    private DocumentoReal documentoReal;
    private String usuario;

    public DocumentoProxy(String usuario) {
        this.usuario = usuario;
    }

    @Override
    public String mostrarContenido() {
    	if (usuario.equalsIgnoreCase("admin") || usuario.equalsIgnoreCase("gerente")) {
            documentoReal = new DocumentoReal();
            return documentoReal.mostrarContenido();
        } else {
            return "❌ Acceso denegado: el usuario '" + usuario + "' no tiene permiso para ver el documento.";
        }
    }
}
