package co.edu.udistrital.model;

public class DocumentoReal implements Documento {
    private String contenido;

    public DocumentoReal() {
        this.contenido = "Contenido confidencial: Proyecto secreto de inteligencia artificial.";
    }

    @Override
    public String mostrarContenido() {
        return contenido;
    }
}

