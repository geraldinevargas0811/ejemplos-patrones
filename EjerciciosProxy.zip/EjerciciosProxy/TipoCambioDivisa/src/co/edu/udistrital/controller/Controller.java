package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        ServicioCambio servicio = new ServicioCambioProxy();

        double tasa1 = servicio.obtenerTasa("USD", "COP");
        vista.mostrarResultado("1 USD = " + tasa1 + " COP");

        double tasa2 = servicio.obtenerTasa("EUR", "COP");
        vista.mostrarResultado("1 EUR = " + tasa2 + " COP");

        double tasa3 = servicio.obtenerTasa("USD", "COP"); // Se usará caché
        vista.mostrarResultado("1 USD (caché) = " + tasa3 + " COP");
    }
}

