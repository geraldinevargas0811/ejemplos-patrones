package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

public class ServicioCambioProxy implements ServicioCambio {
    private ServicioCambioReal servicioReal;
    private Map<String, Double> cache;

    public ServicioCambioProxy() {
        servicioReal = new ServicioCambioReal();
        cache = new HashMap<>();
    }

    @Override
    public double obtenerTasa(String monedaOrigen, String monedaDestino) {
        String clave = monedaOrigen + "-" + monedaDestino;
        if (cache.containsKey(clave)) {
            System.out.println("Usando tasa en caché...");
            return cache.get(clave);
        } else {
            double tasa = servicioReal.obtenerTasa(monedaOrigen, monedaDestino);
            cache.put(clave, tasa);
            return tasa;
        }
    }
}
