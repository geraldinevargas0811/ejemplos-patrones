package co.edu.udistrital.model;

public interface ServicioCambio {
	double obtenerTasa(String monedaOrigen, String monedaDestino);
}
