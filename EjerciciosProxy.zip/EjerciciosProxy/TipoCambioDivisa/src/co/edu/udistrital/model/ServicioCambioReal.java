package co.edu.udistrital.model;

public class ServicioCambioReal implements ServicioCambio{
	
	@Override
    public double obtenerTasa(String monedaOrigen, String monedaDestino) {
        // Simula acceso a un servicio externo lento
        System.out.println("Consultando servidor externo para tasa...");
        try {
            Thread.sleep(1500); // Simula latencia
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // Se simulan tasas fijas
        if (monedaOrigen.equals("USD") && monedaDestino.equals("COP")) {
            return 4000.0;
        } else if (monedaOrigen.equals("EUR") && monedaDestino.equals("COP")) {
            return 4300.0;
        }
        return 1.0;
    }
}
