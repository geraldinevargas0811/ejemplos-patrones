package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarResultado(String resultado) {
        System.out.println("[Consulta de Cambio de Divisas]");
        System.out.println(resultado);
    }
}
