package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        EditorTexto editor = new EditorTexto();
        Historial historial = new Historial();

        // Primer texto
        editor.escribir("Hola, mundo.\n");
        historial.guardar(editor.guardar());
        vista.mostrar("Contenido actual:\n" + editor.obtenerContenido());

        // Segundo texto
        editor.escribir("Estoy aprendiendo el patrón Memento.\n");
        historial.guardar(editor.guardar());
        vista.mostrar("Contenido actual:\n" + editor.obtenerContenido());

        // Tercer texto (error del usuario)
        editor.escribir("Ups! No debía escribir eso.\n");
        vista.mostrar("Contenido antes de deshacer:\n" + editor.obtenerContenido());

        // Deshacer
        editor.restaurar(historial.deshacer());
        vista.mostrar("Contenido tras deshacer:\n" + editor.obtenerContenido());

        // Otro deshacer
        editor.restaurar(historial.deshacer());
        vista.mostrar("Contenido tras segundo deshacer:\n" + editor.obtenerContenido());
    }
}

