package co.edu.udistrital.model;

public class EditorMemento {
    private final String estadoGuardado;

    public EditorMemento(String estado) {
        this.estadoGuardado = estado;
    }

    public String getEstado() {
        return estadoGuardado;
    }
}
