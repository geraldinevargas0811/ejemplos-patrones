package co.edu.udistrital.model;

public class EditorTexto {
    private String contenido = "";

    public void escribir(String texto) {
        contenido += texto;
    }

    public String obtenerContenido() {
        return contenido;
    }

    public EditorMemento guardar() {
        return new EditorMemento(contenido);
    }

    public void restaurar(EditorMemento memento) {
        this.contenido = memento.getEstado();
    }
}
