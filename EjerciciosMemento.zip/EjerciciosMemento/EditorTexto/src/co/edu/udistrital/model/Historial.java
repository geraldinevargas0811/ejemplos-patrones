package co.edu.udistrital.model;

import java.util.Stack;

public class Historial {
    private Stack<EditorMemento> versiones = new Stack<>();

    public void guardar(EditorMemento m) {
        versiones.push(m);
    }

    public EditorMemento deshacer() {
        if (!versiones.isEmpty()) {
            return versiones.pop();
        } else {
            return new EditorMemento(""); // estado vacío si no hay versiones
        }
    }
}
