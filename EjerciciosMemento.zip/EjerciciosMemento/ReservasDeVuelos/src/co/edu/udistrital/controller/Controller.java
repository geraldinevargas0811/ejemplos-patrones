package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Reserva reserva = new Reserva("Bogotá", "Cartagena", "2025-08-01");
        HistorialCambios historial = new HistorialCambios();

        vista.mostrar(reserva.mostrar());
        historial.guardar(reserva.guardar());

        // Modificación 1
        reserva.modificar("Bogotá", "Medellín", "2025-08-03");
        historial.guardar(reserva.guardar());
        vista.mostrar("✏️ Reserva modificada:\n" + reserva.mostrar());

        // Modificación 2
        reserva.modificar("Bogotá", "Cali", "2025-08-05");
        vista.mostrar("✏️ Segunda modificación:\n" + reserva.mostrar());

        // Deshacer cambio
        ReservaMemento versionAnterior = historial.deshacer();
        if (versionAnterior != null) {
            reserva.restaurar(versionAnterior);
            vista.mostrar("↩️ Deshacer:\n" + reserva.mostrar());
        }

        // Otro deshacer
        versionAnterior = historial.deshacer();
        if (versionAnterior != null) {
            reserva.restaurar(versionAnterior);
            vista.mostrar("↩️ Segundo deshacer:\n" + reserva.mostrar());
        }
    }
}

