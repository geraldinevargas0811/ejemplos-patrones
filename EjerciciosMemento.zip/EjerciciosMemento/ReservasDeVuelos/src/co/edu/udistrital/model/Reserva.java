package co.edu.udistrital.model;

public class Reserva {
    private String origen;
    private String destino;
    private String fecha;

    public Reserva(String origen, String destino, String fecha) {
        this.origen = origen;
        this.destino = destino;
        this.fecha = fecha;
    }

    public void modificar(String origen, String destino, String fecha) {
        this.origen = origen;
        this.destino = destino;
        this.fecha = fecha;
    }

    public String mostrar() {
        return "🛫 Reserva:\nOrigen: " + origen + "\nDestino: " + destino + "\nFecha: " + fecha;
    }

    public ReservaMemento guardar() {
        return new ReservaMemento(origen, destino, fecha);
    }

    public void restaurar(ReservaMemento m) {
        this.origen = m.getOrigen();
        this.destino = m.getDestino();
        this.fecha = m.getFecha();
    }
}

