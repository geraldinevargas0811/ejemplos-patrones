package co.edu.udistrital.model;

public class ReservaMemento {
    private final String estadoOrigen;
    private final String estadoDestino;
    private final String estadoFecha;

    public ReservaMemento(String origen, String destino, String fecha) {
        this.estadoOrigen = origen;
        this.estadoDestino = destino;
        this.estadoFecha = fecha;
    }

    public String getOrigen() {
        return estadoOrigen;
    }

    public String getDestino() {
        return estadoDestino;
    }

    public String getFecha() {
        return estadoFecha;
    }
}

