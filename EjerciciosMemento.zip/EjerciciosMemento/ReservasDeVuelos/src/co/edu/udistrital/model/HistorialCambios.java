package co.edu.udistrital.model;

import java.util.Stack;

public class HistorialCambios {
    private Stack<ReservaMemento> historial = new Stack<>();

    public void guardar(ReservaMemento m) {
        historial.push(m);
    }

    public ReservaMemento deshacer() {
        if (!historial.isEmpty()) {
            return historial.pop();
        } else {
            return null;
        }
    }
}

