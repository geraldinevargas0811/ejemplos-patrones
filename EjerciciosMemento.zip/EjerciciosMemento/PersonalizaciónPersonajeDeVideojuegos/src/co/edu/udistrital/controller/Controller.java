package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Personaje personaje = new Personaje("Axel", "Guerrero", 1);
        GestorPersonalizacion gestor = new GestorPersonalizacion();

        vista.mostrar(personaje.mostrar());
        gestor.guardar(personaje.guardar());

        // Cambio 1
        personaje.personalizar("Axel", "Mago", 2);
        gestor.guardar(personaje.guardar());
        vista.mostrar("🧙‍ Cambio de clase:\n" + personaje.mostrar());

        // Cambio 2
        personaje.personalizar("Zara", "Arquera", 3);
        vista.mostrar("🏹 Segundo cambio:\n" + personaje.mostrar());

        // Deshacer 1
        PersonajeMemento previo = gestor.deshacer();
        if (previo != null) {
            personaje.restaurar(previo);
            vista.mostrar("↩️ Deshacer:\n" + personaje.mostrar());
        }

        // Deshacer 2
        previo = gestor.deshacer();
        if (previo != null) {
            personaje.restaurar(previo);
            vista.mostrar("↩️ Segundo deshacer:\n" + personaje.mostrar());
        }
    }
}

