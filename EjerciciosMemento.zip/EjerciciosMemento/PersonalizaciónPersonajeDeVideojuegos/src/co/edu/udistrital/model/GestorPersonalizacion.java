package co.edu.udistrital.model;

import java.util.Stack;

public class GestorPersonalizacion {
    private Stack<PersonajeMemento> historial = new Stack<>();

    public void guardar(PersonajeMemento m) {
        historial.push(m);
    }

    public PersonajeMemento deshacer() {
        if (!historial.isEmpty()) {
            return historial.pop();
        } else {
            return null;
        }
    }
}
