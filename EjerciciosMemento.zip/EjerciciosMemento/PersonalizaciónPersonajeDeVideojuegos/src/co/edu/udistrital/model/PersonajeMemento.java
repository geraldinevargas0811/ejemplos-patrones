package co.edu.udistrital.model;

public class PersonajeMemento {
    private final String estadoNombre;
    private final String estadoClase;
    private final int estadoNivel;

    public PersonajeMemento(String nombre, String clase, int nivel) {
        this.estadoNombre = nombre;
        this.estadoClase = clase;
        this.estadoNivel = nivel;
    }

    public String getNombre() {
        return estadoNombre;
    }

    public String getClase() {
        return estadoClase;
    }

    public int getNivel() {
        return estadoNivel;
    }
}

