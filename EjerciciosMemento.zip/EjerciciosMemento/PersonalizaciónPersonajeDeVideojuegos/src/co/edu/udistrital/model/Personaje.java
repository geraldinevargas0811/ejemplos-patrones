package co.edu.udistrital.model;

public class Personaje {
    private String nombre;
    private String clase;
    private int nivel;

    public Personaje(String nombre, String clase, int nivel) {
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public void personalizar(String nombre, String clase, int nivel) {
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public String mostrar() {
        return "🎮 Personaje:\nNombre: " + nombre + "\nClase: " + clase + "\nNivel: " + nivel;
    }

    public PersonajeMemento guardar() {
        return new PersonajeMemento(nombre, clase, nivel);
    }

    public void restaurar(PersonajeMemento m) {
        this.nombre = m.getNombre();
        this.clase = m.getClase();
        this.nivel = m.getNivel();
    }
}

