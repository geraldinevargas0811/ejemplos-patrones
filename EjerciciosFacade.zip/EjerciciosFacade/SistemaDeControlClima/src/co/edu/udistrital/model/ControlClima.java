package co.edu.udistrital.model;

public class ControlClima {
    private SensorTemperatura sensor;
    private AireAcondicionado aire;
    private Ventilacion ventilacion;
    private Humidificador humidificador;

    public ControlClima() {
        sensor = new SensorTemperatura();
        aire = new AireAcondicionado();
        ventilacion = new Ventilacion();
        humidificador = new Humidificador();
    }

    public String regularClima() {
        double temp = sensor.obtenerTemperatura();
        StringBuilder sb = new StringBuilder();
        sb.append("Temperatura actual: ").append(String.format("%.2f", temp)).append("°C\n");

        if (temp > 35) {
            sb.append(aire.encender()).append("\n");
            sb.append(ventilacion.activar()).append("\n");
            sb.append(humidificador.iniciar());
        } else {
            sb.append(aire.apagar()).append("\n");
            sb.append(ventilacion.desactivar()).append("\n");
            sb.append(humidificador.detener());
        }

        return sb.toString();
    }
}
