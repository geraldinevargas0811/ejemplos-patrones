package co.edu.udistrital.model;

public class Humidificador {
    public String iniciar() {
        return "Humidificador iniciado";
    }

    public String detener() {
        return "Humidificador detenido";
    }
}
