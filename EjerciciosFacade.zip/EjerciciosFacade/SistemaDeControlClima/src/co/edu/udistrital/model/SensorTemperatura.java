package co.edu.udistrital.model;

public class SensorTemperatura {
	public double obtenerTemperatura() {
        return 30 + Math.random() * 10;
    }
}
