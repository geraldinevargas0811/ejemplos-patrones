package co.edu.udistrital.model;

public class AireAcondicionado {
    public String encender() {
        return "Aire acondicionado encendido";
    }

    public String apagar() {
        return "Aire acondicionado apagado";
    }
}
