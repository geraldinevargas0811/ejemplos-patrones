package co.edu.udistrital.model;

public class Ventilacion {
    public String activar() {
        return "Ventilación activada";
    }

    public String desactivar() {
        return "Ventilación desactivada";
    }
}

