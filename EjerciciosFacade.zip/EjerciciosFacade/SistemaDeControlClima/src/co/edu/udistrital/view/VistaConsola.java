package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarEstado(String estado) {
        System.out.println("-----Sistema de Clima Inteligente-----");
        System.out.println(estado);
    }
}
