package co.edu.udistrital.model;

public class ProcesadorTexto {
	public String abrir() {
        return "Procesador de texto abierto (Word)";
    }
}
