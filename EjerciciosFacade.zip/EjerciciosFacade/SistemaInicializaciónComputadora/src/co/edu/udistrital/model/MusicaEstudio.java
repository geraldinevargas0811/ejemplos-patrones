package co.edu.udistrital.model;

public class MusicaEstudio {
	public String reproducirPlaylist() {
        return "Playlist de concentración reproducida en Spotify";
    }
}
