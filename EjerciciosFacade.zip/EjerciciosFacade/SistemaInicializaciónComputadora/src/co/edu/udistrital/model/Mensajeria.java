package co.edu.udistrital.model;

public class Mensajeria {
	public String iniciarSesion() {
        return "Mensajería académica iniciada (Teams)";
    }
}
