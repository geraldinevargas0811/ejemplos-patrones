package co.edu.udistrital.model;

public class NavegadorWeb {
	public String abrirPaginas() {
        return "Páginas académicas abiertas: Moodle, Google Scholar, ChatGPT";
    }
}
