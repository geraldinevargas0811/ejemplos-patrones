package co.edu.udistrital.model;

public class EstudioFacade {
    private ProcesadorTexto word;
    private NavegadorWeb chrome;
    private MusicaEstudio musica;
    private Mensajeria chat;

    public EstudioFacade() {
        word = new ProcesadorTexto();
        chrome = new NavegadorWeb();
        musica = new MusicaEstudio();
        chat = new Mensajeria();
    }

    public String iniciarSesionEstudio() {
        StringBuilder sb = new StringBuilder();
        sb.append(word.abrir()).append("\n");
        sb.append(chrome.abrirPaginas()).append("\n");
        sb.append(musica.reproducirPlaylist()).append("\n");
        sb.append(chat.iniciarSesion());
        return sb.toString();
    }
}
