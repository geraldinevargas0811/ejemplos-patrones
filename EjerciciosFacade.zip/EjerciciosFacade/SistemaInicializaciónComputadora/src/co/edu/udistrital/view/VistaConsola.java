package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarEstado(String estado) {
        System.out.println("[Sesión de Estudio Iniciada]");
        System.out.println(estado);
    }
}
