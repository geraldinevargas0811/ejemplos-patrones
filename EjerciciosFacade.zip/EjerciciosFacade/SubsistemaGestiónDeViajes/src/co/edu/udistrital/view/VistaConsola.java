package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarViaje(String datos) {
        System.out.println("[Agencia de Viajes]");
        System.out.println(datos);
    }
}
