package co.edu.udistrital.model;

public class SeguroViaje {
	public String contratarSeguro() {
        return "Seguro de viaje contratado";
    }
}
