package co.edu.udistrital.model;

public class ReservadorHotel {
    public String reservarHotel(String destino) {
        return "Hotel reservado en " + destino;
    }
}

