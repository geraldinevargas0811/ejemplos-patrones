package co.edu.udistrital.model;


public class GestorViaje {
    private ReservadorVuelos vuelos;
    private ReservadorHotel hotel;
    private AlquiladorVehiculo vehiculo;
    private SeguroViaje seguro;

    public GestorViaje() {
        vuelos = new ReservadorVuelos();
        hotel = new ReservadorHotel();
        vehiculo = new AlquiladorVehiculo();
        seguro = new SeguroViaje();
    }

    public String planearViaje(String destino) {
        StringBuilder sb = new StringBuilder();
        sb.append(vuelos.reservarVuelo(destino)).append("\n");
        sb.append(hotel.reservarHotel(destino)).append("\n");
        sb.append(vehiculo.alquilarAuto(destino)).append("\n");
        sb.append(seguro.contratarSeguro());
        return sb.toString();
    }
}
