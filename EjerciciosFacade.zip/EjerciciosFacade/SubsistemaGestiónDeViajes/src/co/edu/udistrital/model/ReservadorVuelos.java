package co.edu.udistrital.model;

public class ReservadorVuelos {
	public String reservarVuelo(String destino) {
        return "Vuelo reservado a " + destino;
    }
}
