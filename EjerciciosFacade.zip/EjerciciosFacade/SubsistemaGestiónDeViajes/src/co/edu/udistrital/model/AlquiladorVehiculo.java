package co.edu.udistrital.model;

public class AlquiladorVehiculo {
    public String alquilarAuto(String destino) {
        return "Vehículo alquilado en " + destino;
    }
}

