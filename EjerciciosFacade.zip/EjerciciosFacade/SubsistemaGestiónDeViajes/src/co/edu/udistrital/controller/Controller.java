package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        GestorViaje gestor = new GestorViaje();
        String datosViaje = gestor.planearViaje("San Andrés");
        vista.mostrarViaje(datosViaje);
    }
}

