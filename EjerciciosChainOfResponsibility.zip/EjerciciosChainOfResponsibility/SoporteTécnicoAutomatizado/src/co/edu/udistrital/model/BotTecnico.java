package co.edu.udistrital.model;

public class BotTecnico implements ManejadorSoporte {
    private ManejadorSoporte siguiente;

    @Override
    public void setSiguiente(ManejadorSoporte m) {
        this.siguiente = m;
    }

    @Override
    public String responder(Pregunta p) {
        if (p.getContenido().toLowerCase().contains("error") ||
            p.getContenido().toLowerCase().contains("no funciona")) {
            return "🛠️ Bot Técnico: Reinicie la aplicación y asegúrese de tener conexión.";
        } else if (siguiente != null) {
            return "Bot Técnico no puede responder. Pasando...\n" + siguiente.responder(p);
        } else {
            return "❌ Nadie pudo responder a su pregunta.";
        }
    }
}

