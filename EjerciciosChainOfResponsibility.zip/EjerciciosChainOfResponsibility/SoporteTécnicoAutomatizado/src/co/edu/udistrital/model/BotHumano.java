package co.edu.udistrital.model;

public class BotHumano implements ManejadorSoporte {
    private ManejadorSoporte siguiente;

    @Override
    public void setSiguiente(ManejadorSoporte m) {
        this.siguiente = m;
    }

    @Override
    public String responder(Pregunta p) {
        if (p.getContenido().toLowerCase().contains("devolución") ||
            p.getContenido().toLowerCase().contains("reclamo")) {
            return "👤 Agente Humano: Su solicitud será revisada por un representante.";
        } else {
            return "❌ Su pregunta no puede ser respondida automáticamente. Contacte soporte.";
        }
    }
}
