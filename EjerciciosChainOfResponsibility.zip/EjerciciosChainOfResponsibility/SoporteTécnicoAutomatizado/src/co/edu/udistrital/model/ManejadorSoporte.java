package co.edu.udistrital.model;

public interface ManejadorSoporte {
	void setSiguiente(ManejadorSoporte m);
    String responder(Pregunta p);
}
