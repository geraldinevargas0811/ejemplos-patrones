package co.edu.udistrital.model;

public class BotGeneral implements ManejadorSoporte {
    private ManejadorSoporte siguiente;

    @Override
    public void setSiguiente(ManejadorSoporte m) {
        this.siguiente = m;
    }

    @Override
    public String responder(Pregunta p) {
        if (p.getContenido().toLowerCase().contains("horario") ||
            p.getContenido().toLowerCase().contains("precio")) {
            return "🤖 Bot General: Puede consultar los horarios y precios en la sección 'Información'.";
        } else if (siguiente != null) {
            return "Bot General no puede responder. Pasando...\n" + siguiente.responder(p);
        } else {
            return "❌ Nadie pudo responder a su pregunta.";
        }
    }
}
