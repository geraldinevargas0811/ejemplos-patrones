package co.edu.udistrital.model;

public class Pregunta {
    private String contenido;

    public Pregunta(String contenido) {
        this.contenido = contenido;
    }

    public String getContenido() {
        return contenido;
    }
}
