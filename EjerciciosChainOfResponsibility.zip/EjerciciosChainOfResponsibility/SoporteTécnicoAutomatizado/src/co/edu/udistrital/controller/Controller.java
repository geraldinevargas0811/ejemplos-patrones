package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        ManejadorSoporte botGeneral = new BotGeneral();
        ManejadorSoporte botTecnico = new BotTecnico();
        ManejadorSoporte botHumano = new BotHumano();

        // Configurar la cadena
        botGeneral.setSiguiente(botTecnico);
        botTecnico.setSiguiente(botHumano);

        Pregunta p1 = new Pregunta("¿Cuál es el horario de atención?");
        Pregunta p2 = new Pregunta("Mi app no funciona");
        Pregunta p3 = new Pregunta("Quiero hacer una devolución");
        Pregunta p4 = new Pregunta("¿Qué opinan de la vida extraterrestre?");

        vista.mostrar("Consulta 1:");
        vista.mostrar(botGeneral.responder(p1));

        vista.mostrar("Consulta 2:");
        vista.mostrar(botGeneral.responder(p2));

        vista.mostrar("Consulta 3:");
        vista.mostrar(botGeneral.responder(p3));

        vista.mostrar("Consulta 4:");
        vista.mostrar(botGeneral.responder(p4));
    }
}
