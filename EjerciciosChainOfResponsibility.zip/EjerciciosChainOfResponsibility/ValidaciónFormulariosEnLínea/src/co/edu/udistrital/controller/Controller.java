package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        // Crear validadores
        Validador vNombre = new ValidadorNombre();
        Validador vCorreo = new ValidadorCorreo();
        Validador vContrasena = new ValidadorContrasena();

        // Establecer cadena
        vNombre.setSiguiente(vCorreo);
        vCorreo.setSiguiente(vContrasena);

        // Formularios de prueba
        Formulario f1 = new Formulario("Ana", "ana@email.com", "123456");
        Formulario f2 = new Formulario("Jo", "joemail.com", "123");
        Formulario f3 = new Formulario("Pedro", "pedro@", "abc");

        vista.mostrar("📝 Validando Formulario 1:");
        vista.mostrar(vNombre.validar(f1));

        vista.mostrar("📝 Validando Formulario 2:");
        vista.mostrar(vNombre.validar(f2));

        vista.mostrar("📝 Validando Formulario 3:");
        vista.mostrar(vNombre.validar(f3));
    }
}
