package co.edu.udistrital.model;

public class ValidadorContrasena implements Validador {
    private Validador siguiente;

    @Override
    public void setSiguiente(Validador v) {
        this.siguiente = v;
    }

    @Override
    public String validar(Formulario f) {
        if (f.getContrasena() == null || f.getContrasena().length() < 6) {
            return "❌ Contraseña demasiado corta.";
        } else if (siguiente != null) {
            return siguiente.validar(f);
        } else {
            return "✅ Validación completada.";
        }
    }
}

