package co.edu.udistrital.model;

public interface Validador {
    void setSiguiente(Validador v);
    String validar(Formulario f);
}
