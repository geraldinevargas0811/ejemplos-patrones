package co.edu.udistrital.model;

public class ValidadorNombre implements Validador {
    private Validador siguiente;

    @Override
    public void setSiguiente(Validador v) {
        this.siguiente = v;
    }

    @Override
    public String validar(Formulario f) {
        if (f.getNombre() == null || f.getNombre().length() < 3) {
            return "❌ Nombre inválido (mínimo 3 caracteres).";
        } else if (siguiente != null) {
            return siguiente.validar(f);
        } else {
            return "✅ Validación completada.";
        }
    }
}
