package co.edu.udistrital.model;

public class ValidadorCorreo implements Validador {
    private Validador siguiente;

    @Override
    public void setSiguiente(Validador v) {
        this.siguiente = v;
    }

    @Override
    public String validar(Formulario f) {
        if (f.getCorreo() == null || !f.getCorreo().contains("@")) {
            return "❌ Correo inválido.";
        } else if (siguiente != null) {
            return siguiente.validar(f);
        } else {
            return "✅ Validación completada.";
        }
    }
}

