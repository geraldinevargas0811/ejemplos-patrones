package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        ManejadorSolicitud coordinador = new Coordinador();
        ManejadorSolicitud decano = new Decano();
        ManejadorSolicitud rector = new Rector();

        coordinador.setSiguiente(decano);
        decano.setSiguiente(rector);

        Solicitud solicitud1 = new Solicitud("cambio asignatura", "Cambio de Física a Química.");
        Solicitud solicitud2 = new Solicitud("aplazamiento", "Aplazamiento por salud.");
        Solicitud solicitud3 = new Solicitud("beca especial", "Beca por excelencia académica.");
        Solicitud solicitud4 = new Solicitud("reintegro", "Reingreso después de sanción.");

        vista.mostrar(coordinador.procesar(solicitud1));
        vista.mostrar(coordinador.procesar(solicitud2));
        vista.mostrar(coordinador.procesar(solicitud3));
        vista.mostrar(coordinador.procesar(solicitud4));
    }
}
