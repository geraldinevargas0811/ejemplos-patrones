package co.edu.udistrital.model;

public class Coordinador implements ManejadorSolicitud {
    private ManejadorSolicitud siguiente;

    @Override
    public void setSiguiente(ManejadorSolicitud m) {
        this.siguiente = m;
    }

    @Override
    public String procesar(Solicitud s) {
        if (s.getTipo().equalsIgnoreCase("cambio asignatura")) {
            return "✅ Coordinador aprobó solicitud: " + s.getDescripcion();
        } else if (siguiente != null) {
            return "🔁 Coordinador reenvió al siguiente.\n" + siguiente.procesar(s);
        } else {
            return "❌ Solicitud no pudo ser procesada.";
        }
    }
}

