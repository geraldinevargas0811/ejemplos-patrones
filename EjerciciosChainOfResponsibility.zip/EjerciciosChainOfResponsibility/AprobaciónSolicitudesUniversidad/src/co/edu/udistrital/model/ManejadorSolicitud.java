package co.edu.udistrital.model;

public interface ManejadorSolicitud {
    void setSiguiente(ManejadorSolicitud m);
    String procesar(Solicitud s);
}
