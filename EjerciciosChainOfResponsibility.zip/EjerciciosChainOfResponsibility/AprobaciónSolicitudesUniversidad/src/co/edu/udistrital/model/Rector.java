package co.edu.udistrital.model;

public class Rector implements ManejadorSolicitud {
    private ManejadorSolicitud siguiente;

    @Override
    public void setSiguiente(ManejadorSolicitud m) {
        this.siguiente = m;
    }

    @Override
    public String procesar(Solicitud s) {
        if (s.getTipo().equalsIgnoreCase("beca especial")) {
            return "✅ Rector aprobó solicitud: " + s.getDescripcion();
        } else {
            return "❌ Rector no pudo procesar la solicitud: " + s.getDescripcion();
        }
    }
}

