package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

import java.util.ArrayList;
import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        List<Vehiculo> vehiculos = new ArrayList<>();
        vehiculos.add(new Carro("Mazda 3", 2012));
        vehiculos.add(new Bus(45));
        vehiculos.add(new Camion(8.5));

        VisitorVehiculo visitanteImpuesto = new VisitorImpuesto();
        VisitorVehiculo visitanteInspeccion = new VisitorInspeccion();

        vista.mostrar("💰 Cálculo de Impuestos:");
        for (Vehiculo v : vehiculos) {
            vista.mostrar(v.aceptar(visitanteImpuesto));
        }

        vista.mostrar("\n🔎 Reporte de Inspección:");
        for (Vehiculo v : vehiculos) {
            vista.mostrar(v.aceptar(visitanteInspeccion));
        }
    }
}
