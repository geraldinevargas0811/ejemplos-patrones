package co.edu.udistrital.model;

public class Carro implements Vehiculo {
    private String modelo;
    private int anio;

    public Carro(String modelo, int anio) {
        this.modelo = modelo;
        this.anio = anio;
    }

    public String getModelo() {
        return modelo;
    }

    public int getAnio() {
        return anio;
    }

    @Override
    public String aceptar(VisitorVehiculo visitor) {
        return visitor.visitar(this);
    }
}
