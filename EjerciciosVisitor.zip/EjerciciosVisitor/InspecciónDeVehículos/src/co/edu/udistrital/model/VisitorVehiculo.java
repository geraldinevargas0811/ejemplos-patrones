package co.edu.udistrital.model;

public interface VisitorVehiculo {
    String visitar(Carro c);
    String visitar(Bus b);
    String visitar(Camion c);
}
