package co.edu.udistrital.model;

public class VisitorImpuesto implements VisitorVehiculo {

    @Override
    public String visitar(Carro c) {
        double impuesto = c.getAnio() < 2015 ? 500 : 800;
        return "🚗 Impuesto para carro modelo " + c.getModelo() + ": $" + impuesto;
    }

    @Override
    public String visitar(Bus b) {
        double impuesto = 20 * b.getCapacidadPasajeros();
        return "🚌 Impuesto para bus con " + b.getCapacidadPasajeros() + " pasajeros: $" + impuesto;
    }

    @Override
    public String visitar(Camion c) {
        double impuesto = c.getToneladas() * 100;
        return "🚚 Impuesto para camión de " + c.getToneladas() + " toneladas: $" + impuesto;
    }
}

