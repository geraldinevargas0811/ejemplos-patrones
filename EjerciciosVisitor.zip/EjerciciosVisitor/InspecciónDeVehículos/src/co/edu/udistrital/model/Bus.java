package co.edu.udistrital.model;

public class Bus implements Vehiculo {
    private int capacidadPasajeros;

    public Bus(int capacidadPasajeros) {
        this.capacidadPasajeros = capacidadPasajeros;
    }

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }

    @Override
    public String aceptar(VisitorVehiculo visitor) {
        return visitor.visitar(this);
    }
}
