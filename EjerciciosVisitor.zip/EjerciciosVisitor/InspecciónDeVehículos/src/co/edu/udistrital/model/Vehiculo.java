package co.edu.udistrital.model;

public interface Vehiculo {
	String aceptar(VisitorVehiculo visitor);
}
