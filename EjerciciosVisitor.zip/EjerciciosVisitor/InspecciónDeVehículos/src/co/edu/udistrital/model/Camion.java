package co.edu.udistrital.model;

public class Camion implements Vehiculo {
    private double toneladas;

    public Camion(double toneladas) {
        this.toneladas = toneladas;
    }

    public double getToneladas() {
        return toneladas;
    }

    @Override
    public String aceptar(VisitorVehiculo visitor) {
        return visitor.visitar(this);
    }
}

