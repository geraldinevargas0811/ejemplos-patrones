package co.edu.udistrital.model;

public class VisitorInspeccion implements VisitorVehiculo {

    @Override
    public String visitar(Carro c) {
        return "🔍 Inspección del carro: Revisar frenos y motor (" + c.getModelo() + ")";
    }

    @Override
    public String visitar(Bus b) {
        return "🔍 Inspección del bus: Verificar luces y extintores";
    }

    @Override
    public String visitar(Camion c) {
        return "🔍 Inspección del camión: Revisar presión de neumáticos y carga";
    }
}

