package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.ArrayList;
import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        List<Figura> figuras = new ArrayList<>();
        figuras.add(new Circulo(3));
        figuras.add(new Rectangulo(4, 5));
        figuras.add(new Triangulo(6, 2));

        VisitorFigura visitanteArea = new VisitorArea();
        VisitorFigura visitanteDescripcion = new VisitorDescripcion();

        vista.mostrar("📐 Descripciones:");
        for (Figura f : figuras) {
            vista.mostrar(f.aceptar(visitanteDescripcion));
        }

        vista.mostrar("\n📏 Áreas:");
        for (Figura f : figuras) {
            vista.mostrar(f.aceptar(visitanteArea));
        }
    }
}
