package co.edu.udistrital.model;

public class Rectangulo implements Figura {
    private double base, altura;

    public Rectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public double getAltura() {
        return altura;
    }

    @Override
    public String aceptar(VisitorFigura visitor) {
        return visitor.visitar(this);
    }
}
