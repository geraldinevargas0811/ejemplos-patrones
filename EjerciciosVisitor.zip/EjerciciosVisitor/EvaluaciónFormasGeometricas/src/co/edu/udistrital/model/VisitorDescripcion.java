package co.edu.udistrital.model;

public class VisitorDescripcion implements VisitorFigura {

    @Override
    public String visitar(Circulo c) {
        return "🔵 Círculo de radio " + c.getRadio();
    }

    @Override
    public String visitar(Rectangulo r) {
        return "⬛ Rectángulo de " + r.getBase() + " x " + r.getAltura();
    }

    @Override
    public String visitar(Triangulo t) {
        return "🔺 Triángulo de base " + t.getBase() + " y altura " + t.getAltura();
    }
}
