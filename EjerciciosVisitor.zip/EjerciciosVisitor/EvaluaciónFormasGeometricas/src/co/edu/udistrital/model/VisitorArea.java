package co.edu.udistrital.model;

public class VisitorArea implements VisitorFigura {

    @Override
    public String visitar(Circulo c) {
        double area = Math.PI * Math.pow(c.getRadio(), 2);
        return "Área del círculo: " + String.format("%.2f", area);
    }

    @Override
    public String visitar(Rectangulo r) {
        double area = r.getBase() * r.getAltura();
        return "Área del rectángulo: " + area;
    }

    @Override
    public String visitar(Triangulo t) {
        double area = (t.getBase() * t.getAltura()) / 2;
        return "Área del triángulo: " + area;
    }
}
