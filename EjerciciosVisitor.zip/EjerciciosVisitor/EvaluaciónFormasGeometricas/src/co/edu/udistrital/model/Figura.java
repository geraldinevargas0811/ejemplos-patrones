package co.edu.udistrital.model;

public interface Figura {
    String aceptar(VisitorFigura visitor);
}
