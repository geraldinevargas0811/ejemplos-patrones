package co.edu.udistrital.model;

public class Circulo implements Figura {
    private double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    @Override
    public String aceptar(VisitorFigura visitor) {
        return visitor.visitar(this);
    }
}
