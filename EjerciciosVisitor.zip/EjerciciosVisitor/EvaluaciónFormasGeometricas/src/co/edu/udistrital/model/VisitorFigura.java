package co.edu.udistrital.model;

public interface VisitorFigura {
    String visitar(Circulo c);
    String visitar(Rectangulo r);
    String visitar(Triangulo t);
}
