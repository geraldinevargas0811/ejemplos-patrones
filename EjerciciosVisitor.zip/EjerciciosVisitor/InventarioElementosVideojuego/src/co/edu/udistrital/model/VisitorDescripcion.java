package co.edu.udistrital.model;

public class VisitorDescripcion implements VisitorElemento {

    @Override
    public String visitar(Arma a) {
        return "🗡️ Arma: " + a.getNombre() + " (Daño: " + a.getDanio() + ")";
    }

    @Override
    public String visitar(Pocion p) {
        return "🧪 Pocion de " + p.getTipo() + " (Potencia: " + p.getPotencia() + ")";
    }

    @Override
    public String visitar(Armadura a) {
        return "🛡️ Armadura con defensa de " + a.getDefensa();
    }
}
