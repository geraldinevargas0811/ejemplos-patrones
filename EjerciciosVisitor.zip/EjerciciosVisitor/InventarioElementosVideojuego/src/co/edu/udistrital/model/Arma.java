package co.edu.udistrital.model;

public class Arma implements ElementoInventario {
    private String nombre;
    private int danio;

    public Arma(String nombre, int danio) {
        this.nombre = nombre;
        this.danio = danio;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDanio() {
        return danio;
    }

    @Override
    public String aceptar(VisitorElemento visitor) {
        return visitor.visitar(this);
    }
}

