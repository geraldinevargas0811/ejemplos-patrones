package co.edu.udistrital.model;

public class Armadura implements ElementoInventario {
    private int defensa;

    public Armadura(int defensa) {
        this.defensa = defensa;
    }

    public int getDefensa() {
        return defensa;
    }

    @Override
    public String aceptar(VisitorElemento visitor) {
        return visitor.visitar(this);
    }
}

