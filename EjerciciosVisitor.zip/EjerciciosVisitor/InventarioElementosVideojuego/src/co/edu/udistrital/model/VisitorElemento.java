package co.edu.udistrital.model;

public interface VisitorElemento {
    String visitar(Arma a);
    String visitar(Pocion p);
    String visitar(Armadura a);
}
