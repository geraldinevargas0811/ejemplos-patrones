package co.edu.udistrital.model;

public class Pocion implements ElementoInventario {
    private String tipo;
    private int potencia;

    public Pocion(String tipo, int potencia) {
        this.tipo = tipo;
        this.potencia = potencia;
    }

    public String getTipo() {
        return tipo;
    }

    public int getPotencia() {
        return potencia;
    }

    @Override
    public String aceptar(VisitorElemento visitor) {
        return visitor.visitar(this);
    }
}

