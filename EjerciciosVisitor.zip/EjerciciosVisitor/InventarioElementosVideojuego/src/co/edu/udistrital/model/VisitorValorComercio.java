package co.edu.udistrital.model;

public class VisitorValorComercio implements VisitorElemento {

    @Override
    public String visitar(Arma a) {
        return "💰 Valor de " + a.getNombre() + ": " + (a.getDanio() * 10) + " oro";
    }

    @Override
    public String visitar(Pocion p) {
        return "💰 Valor de poción de " + p.getTipo() + ": " + (p.getPotencia() * 5) + " oro";
    }

    @Override
    public String visitar(Armadura a) {
        return "💰 Valor de armadura: " + (a.getDefensa() * 15) + " oro";
    }
}

