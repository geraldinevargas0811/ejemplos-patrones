package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.ArrayList;
import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        List<ElementoInventario> inventario = new ArrayList<>();
        inventario.add(new Arma("Espada del amanecer", 15));
        inventario.add(new Pocion("Salud", 20));
        inventario.add(new Armadura(12));

        VisitorElemento visitanteDescripcion = new VisitorDescripcion();
        VisitorElemento visitanteValor = new VisitorValorComercio();

        vista.mostrar("📋 Descripción del inventario:");
        for (ElementoInventario e : inventario) {
            vista.mostrar(e.aceptar(visitanteDescripcion));
        }

        vista.mostrar("\n🛒 Valor en oro:");
        for (ElementoInventario e : inventario) {
            vista.mostrar(e.aceptar(visitanteValor));
        }
    }
}

