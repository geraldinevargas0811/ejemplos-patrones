package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Vehiculo;

public class Camion extends Vehiculo {
	
	public Camion (String ti, double p) {
		super(ti, p);
	}

	@Override
	public String calcularImpuesto() {
		double x;
		String total;
		x= Precio * 0.25;
		total = Double.toString(x);
		return total;
	}

	@Override
	public String calcularPrecioFinal() {
		double x;
		double impuesto = Double.parseDouble(calcularImpuesto());
		String total;
		x= Precio + impuesto;
		total = Double.toString(x);
		return total;
	}

}
