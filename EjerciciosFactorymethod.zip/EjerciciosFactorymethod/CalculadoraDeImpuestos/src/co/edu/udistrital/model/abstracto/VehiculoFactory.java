package co.edu.udistrital.model.abstracto;

public interface VehiculoFactory {
	
	Vehiculo crearVehculo(String tipo, double precio);

}
