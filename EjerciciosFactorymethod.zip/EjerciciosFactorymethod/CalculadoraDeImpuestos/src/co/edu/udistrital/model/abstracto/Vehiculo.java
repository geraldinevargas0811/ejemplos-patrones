package co.edu.udistrital.model.abstracto;

public abstract class Vehiculo {
	protected String Tipo;
	protected double Precio;
	
	public Vehiculo (String tipo, double precio) {
		this.Tipo = tipo;
		this.Precio = precio;
	}
	
	public abstract String calcularImpuesto();
	
	public abstract String calcularPrecioFinal();
	

}
