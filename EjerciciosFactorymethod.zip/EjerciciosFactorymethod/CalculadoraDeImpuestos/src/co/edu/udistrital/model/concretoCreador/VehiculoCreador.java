package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.Camion;
import co.edu.udistrital.model.Carro;
import co.edu.udistrital.model.Moto;
import co.edu.udistrital.model.abstracto.Vehiculo;
import co.edu.udistrital.model.abstracto.VehiculoFactory;

public class VehiculoCreador implements VehiculoFactory{

	@Override
	public Vehiculo crearVehculo(String tipo, double precio) {
		if (tipo.equalsIgnoreCase("camion")) {
			return new Camion(tipo, precio);
		} else if (tipo.equalsIgnoreCase("carro")) {
			return new Carro(tipo, precio);
		}else if (tipo.equalsIgnoreCase("moto")) {
	        return new Moto(tipo, precio);
		} else {
			return null;
		}
	}
	

}
