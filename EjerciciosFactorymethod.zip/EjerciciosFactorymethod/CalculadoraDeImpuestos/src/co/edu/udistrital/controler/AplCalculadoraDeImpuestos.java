package co.edu.udistrital.controler;

import co.edu.udistrital.controler.Controller;

public class AplCalculadoraDeImpuestos {
	
	public static void main(String[] args) {

		Controller control;
		control = new Controller();
		control.run();

	}

}
