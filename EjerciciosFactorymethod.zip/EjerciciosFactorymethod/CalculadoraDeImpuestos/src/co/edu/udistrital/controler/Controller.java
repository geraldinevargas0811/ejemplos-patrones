package co.edu.udistrital.controler;

import co.edu.udistrital.model.abstracto.Vehiculo;
import co.edu.udistrital.model.abstracto.VehiculoFactory;
import co.edu.udistrital.model.concretoCreador.VehiculoCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	String ti = "";
    	double p = 0;
    	
    	vista.mostrarInformacion("Ingrese los datos del vehiculo que desea cotizar");
        
        ti = vista.leerTexto("\t" + "Digite el tipo de vehiculo a cotizar (camion, carro, moto): ");
        p = vista.leerDatoDecimal("\t" + "Digite el precio del vehiculo: ");
        
        VehiculoFactory fabrica= new VehiculoCreador();
        
        Vehiculo vehiculo = fabrica.crearVehculo(ti, p);

        vista.mostrarInformacion("El impuesto del vehiculo es: " + vehiculo.calcularImpuesto() );
        vista.mostrarInformacion("El valor total del vehiculo es: " + vehiculo.calcularPrecioFinal());
    	
    }

}
