package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	
	private VistaConsola vista;
	
	public Controller() {
		vista = new VistaConsola();
	}
	
	public void run() {
		double a = 0;
		double b = 0;
		double c = 0;
		double p = 0;
	
		vista.mostrarInformacion("Ingrese las notas del estudiante");
 
		a = vista.leerDatoDecimal("\t" + "Digite la nota 1: ");
		b = vista.leerDatoDecimal("\t" + "Digite la nota 2: ");
		c = vista.leerDatoDecimal("\t" + "Digite la nota 3: ");
		
		p = (a + b + c) / 3;
    
		EstudianteFactory fabrica= new EstudianteCreador();
    
		Estudiante estudiante = fabrica.crearEstudiante(a,b,c,p);
		
		vista.mostrarInformacion("Tu promedio es: " + estudiante.calcularPromedio());
		vista.mostrarInformacion(estudiante.describir() );    
	}

}
