package co.edu.udistrital.model.abstracto;

public abstract class Estudiante {
	protected String Estado;
	protected double nota_1;
	protected double nota_2;
	protected double nota_3;
	protected double Promedio;
	

	public Estudiante(double nota_A, double nota_B, double nota_C, double promedio) {
		super();
		this.nota_1 = nota_A;
		this.nota_2 = nota_B;
		this.nota_3 = nota_C;
		this.Promedio = promedio;
	}
	
	public abstract String describir();
	public abstract String calcularPromedio();

}
