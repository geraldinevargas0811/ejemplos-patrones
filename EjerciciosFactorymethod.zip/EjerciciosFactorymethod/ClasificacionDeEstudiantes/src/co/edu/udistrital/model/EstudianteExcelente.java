package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Estudiante;

public class EstudianteExcelente extends Estudiante{
	
	public EstudianteExcelente(double a, double b, double c, double p) {
		
		super(a, b, c, p);
		
	}

	@Override
	public String describir() {
		return "!Felicitaciones¡ eres un excelente estudiante" ;
	}

	@Override
	public String calcularPromedio() {
		double x;
		String pro;
		x=(nota_1 + nota_2 + nota_3 )/3;
		pro = Double.toString(x);
		
		return pro;
	}

}
