package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.*;

public class EstudianteCreador implements EstudianteFactory{

	@Override
	public Estudiante crearEstudiante(double nota_A, double nota_B, double nota_C, double promedio) {
		if (promedio >= 4.5 ) {
			return new EstudianteExcelente(nota_A, nota_B, nota_C, promedio);
		} else if ((promedio < 4.5) && (promedio >= 3.5)) {
			return new EstudianteAprobado(nota_A, nota_B, nota_C, promedio);
		} else if (promedio < 3.5 ){
			return new EstudianteReprobado(nota_A, nota_B, nota_C, promedio);
		} else {
			return null;
		} 
		
	}

}
