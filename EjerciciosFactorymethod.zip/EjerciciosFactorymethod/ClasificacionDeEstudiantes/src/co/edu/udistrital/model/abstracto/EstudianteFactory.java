package co.edu.udistrital.model.abstracto;

public interface EstudianteFactory {
	
	Estudiante crearEstudiante (double nota_A, double nota_B, double nota_C, double promedio);

}
