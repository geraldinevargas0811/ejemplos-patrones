package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;

public class Controller {
	
private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	String ti = "";
    	String to = "";
    	int p = 0;
    	int c = 0;
    	
    	vista.mostrarInformacion("Ingrese los datos del producto que desea comprar");
        
        ti = vista.leerTexto("\t" + "Digite el tipo de produto (labial, pestañina, rubor): ");
        c = vista.leerDatoEntero("\t" + "Digite la cantidad de productos : ");
        
        ProductoFactory fabrica= new ProductosCreador();
        
        Producto producto = fabrica.crearProducto(ti, to, p, c);

        vista.mostrarInformacion("El tono de su producto es: " + producto.describir() );
        vista.mostrarInformacion("El valor total de su compra es: " + producto.calcularValorTotal());
    	
    }

}
