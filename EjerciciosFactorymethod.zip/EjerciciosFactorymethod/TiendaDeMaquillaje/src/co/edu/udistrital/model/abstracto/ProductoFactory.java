package co.edu.udistrital.model.abstracto;

public interface ProductoFactory {
	
	Producto crearProducto (String tipo, String tono, int precio, int cantidad);

}
