package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Producto;
import co.edu.udistrital.model.abstracto.ProductoFactory;

public class ProductosCreador implements ProductoFactory{

	@Override
	public Producto crearProducto(String tipo, String tono, int precio, int cantidad) {
		if (tipo.equalsIgnoreCase("labial")) {
			return new Labial(tipo, tono, precio ,cantidad);
		} else if (tipo.equalsIgnoreCase("pestañina")) {
			return new Pestañina(tipo, tono, precio ,cantidad);
		}else if (tipo.equalsIgnoreCase("rubor")) {
	        return new Rubor(tipo, tono, precio ,cantidad);
		} else {
			return null;
		}
	}
	

}
