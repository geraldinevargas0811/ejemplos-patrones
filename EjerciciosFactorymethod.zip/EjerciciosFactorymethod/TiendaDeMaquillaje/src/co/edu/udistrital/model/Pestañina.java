package co.edu.udistrital.model;
import co.edu.udistrital.model.abstracto.Producto;

public class Pestañina extends Producto{
	
	public Pestañina (String ti, String to, int p, int c) {
		super(ti,to,p,c);
	}

	@Override
	public String describir() {
		return "negro";
	}

	@Override
	public String calcularValorTotal() {
		int x;
		String total;
		Precio = 18000;
		x= Cantidad * Precio;
		total = Integer.toString(x);
		return total;
	}

}
