package co.edu.udistrital.model;
import co.edu.udistrital.model.abstracto.Producto;

public class Rubor extends Producto{
	
	public Rubor (String ti, String to, int p, int c) {
		super(ti,to,p,c);
	}

	@Override
	public String describir() {
		return "rosado";
	}

	@Override
	public String calcularValorTotal() {
		int x;
		String total;
		Precio = 12000;
		x= Cantidad * Precio;
		total = Integer.toString(x);
		return total;
	}

}
