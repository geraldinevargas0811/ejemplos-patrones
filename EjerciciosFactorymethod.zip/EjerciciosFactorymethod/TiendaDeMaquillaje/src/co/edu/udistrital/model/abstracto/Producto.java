package co.edu.udistrital.model.abstracto;

public abstract class Producto {
	protected String Tipo;
	protected String Tono;
	protected int Precio;
	protected int Cantidad;
	
	public Producto (String tipo, String tono, int precio, int cantidad) {
		this.Tipo = tipo;
		this.Tono = tono;
		this.Cantidad = cantidad;
		this.Precio = precio;
	}
	
	public abstract String describir();
	
	public abstract String calcularValorTotal();

}
