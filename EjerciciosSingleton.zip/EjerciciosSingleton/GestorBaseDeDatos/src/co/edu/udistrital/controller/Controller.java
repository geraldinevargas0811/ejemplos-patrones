package co.edu.udistrital.controller;

import co.edu.udistrital.model.ConexionBaseDeDatos;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
    	boolean continuar = true;

        while (continuar) {
            vista.mostrarInformacion("=== Inicio de sesión ===\n");

            String usuario = vista.leerTexto("Ingrese el usuario: \n");
            String contrasena = vista.leerTexto("Ingrese la contraseña: \n");

            ConexionBaseDeDatos conexion = ConexionBaseDeDatos.getInstancia(usuario, contrasena);

            vista.mostrarInformacion("Usuario conectado: " + conexion.getUsuario());
            vista.mostrarInformacion("Estado: " + conexion.getConnectionInfo()+"\n");


            int opcion = vista.leerDatoEntero("¿Desea iniciar sesión con otro usuario? (1 = Sí, 0 = No): ");
            continuar = (opcion == 1);
        }
    }
}