package co.edu.udistrital.model;

public class ConexionBaseDeDatos {
	
	private static ConexionBaseDeDatos instancia = null;

    private String connection;
    private String usuario;
    private String contrasena;
    
    private ConexionBaseDeDatos(String usuario, String contrasena) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.connection = "Conexión simulada establecida para el usuario: " + usuario;
        System.out.println("🟢 " + connection);
    }


    public static ConexionBaseDeDatos getInstancia(String usuario, String contrasena) {
        if (instancia == null) {
            instancia = new ConexionBaseDeDatos(usuario, contrasena);
        } else if (instancia.usuario.equals(usuario)) {
            System.out.println("❌ Error: El usuario '" + usuario + "' ya tiene una sesión activa.");
            return null;
        } else {
            System.out.println("⚠️ Ya existe una conexión activa con el usuario: " + instancia.usuario+"\n");
        }
        return instancia;
    }
    
   

    public String getConnectionInfo() {
        return connection;
    }

    public String getUsuario() {
        return usuario;
    }

}
