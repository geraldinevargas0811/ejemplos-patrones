package co.edu.udistrital.model;

public class AdministradorDeRecursos {
	
	private static AdministradorDeRecursos instancia = null;

    private boolean recursoEnUso;

    private AdministradorDeRecursos() {
        this.recursoEnUso = false;
        System.out.println("🧩 ResourceManager inicializado.");
    }

    public static AdministradorDeRecursos getInstancia() {
        if (instancia == null) {
            instancia = new AdministradorDeRecursos();
        }
        return instancia;
    }

    public boolean solicitarRecurso() {
        if (recursoEnUso) {
            System.out.println("❌ Recurso actualmente en uso. Espere a que se libere.");
            return false;
        } else {
            recursoEnUso = true;
            System.out.println("✅ Acceso concedido al recurso.");
            return true;
        }
    }

    public void liberarRecurso() {
        if (recursoEnUso) {
            recursoEnUso = false;
            System.out.println("🔓 Recurso liberado.");
        } else {
            System.out.println("⚠️ El recurso ya está libre.");
        }
    }

    public void mostrarEstado() {
        System.out.println("📄 Estado del recurso: " + (recursoEnUso ? "EN USO" : "LIBRE"));
    }

}
