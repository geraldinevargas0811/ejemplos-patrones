package co.edu.udistrital.controller;

public class AplControlAcceso {
	
	public static void main(String[] args) {

		Controller control;
		control = new Controller();
		control.run();

	}

}
