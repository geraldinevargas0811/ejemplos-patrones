package co.edu.udistrital.controller;

import co.edu.udistrital.model.AdministradorDeRecursos;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
    	AdministradorDeRecursos gestor = AdministradorDeRecursos.getInstancia();
        boolean continuar = true;

        while (continuar) {
            vista.mostrarInformacion("\n=== GESTOR DE RECURSOS ===");
            gestor.mostrarEstado();

            int opcion = vista.leerDatoEntero("""
                Opciones:
                1. Solicitar recurso
                2. Liberar recurso
                0. Salir
                -> Seleccione una opción: """);

            switch (opcion) {
                case 1:
                    gestor.solicitarRecurso();
                    break;
                case 2:
                    gestor.liberarRecurso();
                    break;
                case 0:
                    continuar = false;
                    break;
                default:
                    vista.mostrarInformacion("❌ Opción inválida.");
            }
        }

        vista.mostrarInformacion("Aplicación finalizada.");
    }

}
