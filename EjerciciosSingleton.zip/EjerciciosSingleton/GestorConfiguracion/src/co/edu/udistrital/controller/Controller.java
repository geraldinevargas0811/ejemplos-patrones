package co.edu.udistrital.controller;

import co.edu.udistrital.model.ConfiguracionAplicacion;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
    	ConfiguracionAplicacion config = ConfiguracionAplicacion.getInstancia();
        config.mostrarConfiguracion();

        int opcion = vista.leerDatoEntero("¿Desea modificar la configuración? (1 = Sí, 0 = No): ");

        if (opcion == 1) {
            vista.leerTexto("");
            String nuevoIdioma = vista.leerTexto("Nuevo idioma (ej: es, en): ");
            String nuevaRuta = vista.leerTexto("Nueva ruta base: ");
            int debug = vista.leerDatoEntero("¿Activar modo debug? (1 = Sí, 0 = No): ");

            boolean nuevoDebug = (debug == 1);

            config.aplicarConfiguracion(nuevoIdioma, nuevaRuta, nuevoDebug);
        }

        config.mostrarConfiguracion();
    }

}
