package co.edu.udistrital.model;

public class ConfiguracionAplicacion {
	
	private static ConfiguracionAplicacion instancia = null;

    private String idioma;
    private String rutaBase;
    private boolean modoDebug;


    private ConfiguracionAplicacion() {
        this.idioma = "es";
        this.rutaBase = "/default/path/";
        this.modoDebug = false;
        System.out.println("AppConfig inicializado con valores por defecto.");
    }

    public static ConfiguracionAplicacion getInstancia() {
        if (instancia == null) {
            instancia = new ConfiguracionAplicacion();
        }
        return instancia;
    }
    
    public boolean configEsIgual(String idioma, String ruta, boolean debug) {
        return this.idioma.equals(idioma) &&
               this.rutaBase.equals(ruta) &&
               this.modoDebug == debug;
    }
    
    public boolean aplicarConfiguracion(String nuevoIdioma, String nuevaRuta, boolean nuevoDebug) {
        if (configEsIgual(nuevoIdioma, nuevaRuta, nuevoDebug)) {
            System.out.println("❌ Error: La configuración ingresada es idéntica a la actual. No se realizaron cambios.");
            return false;
        }

        this.idioma = nuevoIdioma;
        this.rutaBase = nuevaRuta;
        this.modoDebug = nuevoDebug;
        System.out.println("✅ Configuración actualizada correctamente.");
        return true;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getRutaBase() {
        return rutaBase;
    }

    public void setRutaBase(String rutaBase) {
        this.rutaBase = rutaBase;
    }

    public boolean isModoDebug() {
        return modoDebug;
    }

    public void setModoDebug(boolean modoDebug) {
        this.modoDebug = modoDebug;
    }

    public void mostrarConfiguracion() {
        System.out.println(" Configuración actual:");
        System.out.println("Idioma: " + idioma);
        System.out.println("Ruta base: " + rutaBase);
        System.out.println("Modo Debug: " + (modoDebug ? "Activado" : "Desactivado"));
    }

}
