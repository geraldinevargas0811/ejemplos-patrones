package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.model.creador.*;
import co.edu.udistrital.model.director.*;
import co.edu.udistrital.view.*;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();   
    }

    public void run() {
        int opcion;
        VehiculoBuilder builder = new VehiculoConcretoBuilder();
        VehiculoDirector director = new VehiculoDirector(builder);
        
        Vehiculo vehiculo = null;

        do {
            opcion = menuPrincipal();
            switch (opcion) {
                case 1:
                	director.construirVehiculo();
                    vehiculo = builder.obtenerVehiculo();
                    vista.mostrarInformacion("Vehículo construido con éxito.\n");
                    break;
                case 2:
                    if (vehiculo != null) {
                        vista.mostrarInformacion("=== Vehículo Configurado ===");
                        vista.mostrarInformacion(vehiculo.toString());
                    } else {
                        vista.mostrarInformacion("Primero debe construir el vehículo.\n");
                    }
                    break;
                case 3:
                    vista.mostrarInformacion("Saliendo del configurador de vehículos...");
                    break;
                default:
                    vista.mostrarInformacion("Opción inválida. Intente de nuevo.\n");
            }
        } while (opcion != 3);
    }

    private int menuPrincipal() {
        String menu = """
                === CONFIGURADOR DE VEHÍCULOS ===
                1. Construir vehículo predeterminado
                2. Mostrar vehículo
                3. Salir
                Seleccione una opción: """;
        return vista.leerDatoEntero(menu);
    }


}