package co.edu.udistrital.model.creador;

import co.edu.udistrital.model.*;

public interface VehiculoBuilder {
	
	void construirMotor();
    void construirColor();
    void construirLlantas();
    void construirAccesorios();
    Vehiculo obtenerVehiculo();

}
