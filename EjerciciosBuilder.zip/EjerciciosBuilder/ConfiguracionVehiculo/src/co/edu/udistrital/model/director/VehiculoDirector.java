package co.edu.udistrital.model.director;

import co.edu.udistrital.model.creador.VehiculoBuilder;

public class VehiculoDirector {
	
	private VehiculoBuilder builder;

    public VehiculoDirector(VehiculoBuilder builder) {
        this.builder = builder;
    }

    public void construirVehiculo() {
        builder.construirMotor();
        builder.construirColor();
        builder.construirLlantas();
        builder.construirAccesorios();
    }

}
