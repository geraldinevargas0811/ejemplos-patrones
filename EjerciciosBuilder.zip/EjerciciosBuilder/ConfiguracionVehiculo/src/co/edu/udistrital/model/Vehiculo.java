package co.edu.udistrital.model;

public class Vehiculo {
	
	private String motor;
    private String color;
    private String llantas;
    private String accesorios;


    public void setMotor(String motor) {
        this.motor = motor;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setLlantas(String llantas) {
        this.llantas = llantas;
    }

    public void setAccesorios(String accesorios) {
        this.accesorios = accesorios;
    }

    @Override
    public String toString() {
        return "===== VEHÍCULO =====\n"
        		+ "Motor: " + motor 
        		+ "\nColor: " + color 
        		+ "\nllantas: " + llantas 
        		+ "\nAccesorios: " + accesorios;
    }

}
