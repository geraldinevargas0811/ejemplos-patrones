package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.creador.*;

public class VehiculoConcretoBuilder implements VehiculoBuilder {
    private Vehiculo vehiculo;

    public VehiculoConcretoBuilder() {
        this.vehiculo = new Vehiculo();
    }

    @Override
    public void construirMotor() {
        vehiculo.setMotor("Motor Eléctrico");
    }

    @Override
    public void construirColor() {
        vehiculo.setColor("Rojo");
    }

    @Override
    public void construirLlantas() {
        vehiculo.setLlantas("Llantas de aleación");
    }

    @Override
    public void construirAccesorios() {
        vehiculo.setAccesorios("Asientos de cuero, Cámara de reversa");
    }

    @Override
    public Vehiculo obtenerVehiculo() {
        return vehiculo;
    }
}