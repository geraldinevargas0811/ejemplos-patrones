package co.edu.udistrital.controller;

import co.edu.udistrital.model.Perfil;
import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.concretoCredor.*;
import co.edu.udistrital.model.creador.*;
import co.edu.udistrital.model.director.*;

public class Controller {
	
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        int opcion;
        PerfilBuilder builder = new PerfilConcretoBuilder();
        PerfilDirector director = new PerfilDirector(builder);

        Perfil perfil = null;

        do {
            opcion = menuPrincipal();
            switch (opcion) {
                case 1:
                    String nombre = vista.leerTexto("Nombre del usuario: ");
                    String bio = vista.leerTexto("Biografía: ");
                    String intereses = vista.leerTexto("Intereses (separados por coma): ");
                    String privacidad = vista.leerTexto("Nivel de privacidad (Público/Privado/Amigos): ");

                    director.construirPerfil(nombre, bio, intereses, privacidad);
                    perfil = director.obtenerPerfil();

                    vista.mostrarInformacion("Perfil creado con éxito.");
                    break;
                case 2:
                    if (perfil != null) {
                        vista.mostrarInformacion(perfil.toString());
                    } else {
                        vista.mostrarInformacion("Aún no se ha creado ningún perfil.");
                    }
                    break;
                case 3:
                    vista.mostrarInformacion("Saliendo del sistema de perfiles...");
                    break;
                default:
                    vista.mostrarInformacion("Opción inválida.");
            }
        } while (opcion != 3);
    }

    private int menuPrincipal() {
        String menu = """
                === SISTEMA DE PERFILES ===
                1. Crear nuevo perfil
                2. Mostrar perfil
                3. Salir
                Seleccione una opción:
                """;
        return vista.leerDatoEntero(menu);
    }

}
