package co.edu.udistrital.model.director;

import co.edu.udistrital.model.Perfil;
import co.edu.udistrital.model.creador.PerfilBuilder;

public class PerfilDirector {
	
	private PerfilBuilder builder;

    public PerfilDirector(PerfilBuilder builder) {
        this.builder = builder;
    }

    public void construirPerfil(String nombre, String biografia, String intereses, String privacidad) {
        builder.crearNuevoPerfil();
        builder.construirNombre(nombre);
        builder.construirBiografia(biografia);
        builder.construirIntereses(intereses);
        builder.construirPrivacidad(privacidad);
    }

    public Perfil obtenerPerfil() {
        return builder.getPerfil();
    }

}
