package co.edu.udistrital.model;

public class Perfil {
	
	private String nombre;
    private String biografia;
    private String intereses;
    private String privacidad;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }

    public void setIntereses(String intereses) {
        this.intereses = intereses;
    }

    public void setPrivacidad(String privacidad) {
        this.privacidad = privacidad;
    }
    
    @Override
    public String toString() {
		return "=== PERFIL DE USUARIO ===\n"
				+ "Nombre: " + nombre 
				+ "\nBiografía: " + biografia 
				+ "\nIntereses: " + intereses
				+ "\nPrivacidad: " + privacidad;		
    	
    }


}
