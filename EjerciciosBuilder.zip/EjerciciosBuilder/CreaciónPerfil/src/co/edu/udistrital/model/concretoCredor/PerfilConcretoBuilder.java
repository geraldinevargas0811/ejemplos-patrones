package co.edu.udistrital.model.concretoCredor;

import co.edu.udistrital.model.Perfil;
import co.edu.udistrital.model.creador.PerfilBuilder;

public class PerfilConcretoBuilder implements PerfilBuilder{

	private Perfil perfil;

    @Override
    public void crearNuevoPerfil() {
        perfil = new Perfil();
    }

    @Override
    public void construirNombre(String nombre) {
        perfil.setNombre(nombre);
    }

    @Override
    public void construirBiografia(String biografia) {
        perfil.setBiografia(biografia);
    }

    @Override
    public void construirIntereses(String intereses) {
        perfil.setIntereses(intereses);
    }

    @Override
    public void construirPrivacidad(String privacidad) {
        perfil.setPrivacidad(privacidad);
    }

    @Override
    public Perfil getPerfil() {
        return perfil;
    }

}
