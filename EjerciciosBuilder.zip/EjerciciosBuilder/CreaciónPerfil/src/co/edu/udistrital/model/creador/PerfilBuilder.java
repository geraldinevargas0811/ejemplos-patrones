package co.edu.udistrital.model.creador;

import co.edu.udistrital.model.Perfil;

public interface PerfilBuilder {
	
	void crearNuevoPerfil();
    void construirNombre(String nombre);
    void construirBiografia(String biografia);
    void construirIntereses(String intereses);
    void construirPrivacidad(String privacidad);
    Perfil getPerfil();

}
