package co.edu.udistrital.model;

public class Pedido {
	
	private String cliente;
    private String productos;
    private double total;
    private String observaciones;

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public void setProductos(String productos) {
        this.productos = productos;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
		return "=== REPORTE DE PEDIDO ===\n"
				+ "Cliente: " + cliente
	            + "\nProductos: " + productos
	            + "\nTotal: $" + total
	            + "\nObservaciones: " + observaciones;
    }
    
}
