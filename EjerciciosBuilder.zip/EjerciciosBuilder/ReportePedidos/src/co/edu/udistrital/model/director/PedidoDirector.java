package co.edu.udistrital.model.director;

import co.edu.udistrital.model.Pedido;
import co.edu.udistrital.model.creador.PedidoBuilder;

public class PedidoDirector {
    private PedidoBuilder builder;

    public PedidoDirector(PedidoBuilder builder) {
        this.builder = builder;
    }

    public void construirPedido(String cliente, String productos, double total, String observaciones) {
        builder.crearNuevoPedido();
        builder.construirCliente(cliente);
        builder.construirProductos(productos);
        builder.construirTotal(total);
        builder.construirObservaciones(observaciones);
    }

    public Pedido obtenerPedido() {
        return builder.getPedido();
    }
}