package co.edu.udistrital.model.creador;

import co.edu.udistrital.model.*;

public interface PedidoBuilder {
	
	void crearNuevoPedido();
    void construirCliente(String cliente);
    void construirProductos(String productos);
    void construirTotal(double total);
    void construirObservaciones(String observaciones);
    Pedido getPedido();

}
