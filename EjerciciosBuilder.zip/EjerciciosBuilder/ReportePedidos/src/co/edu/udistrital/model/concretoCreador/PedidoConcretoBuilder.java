package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.Pedido;
import co.edu.udistrital.model.creador.PedidoBuilder;

public class PedidoConcretoBuilder implements PedidoBuilder {
    private Pedido pedido;

    @Override
    public void crearNuevoPedido() {
        pedido = new Pedido();
    }

    @Override
    public void construirCliente(String cliente) {
        pedido.setCliente(cliente);
    }

    @Override
    public void construirProductos(String productos) {
        pedido.setProductos(productos);
    }

    @Override
    public void construirTotal(double total) {
        pedido.setTotal(total);
    }

    @Override
    public void construirObservaciones(String observaciones) {
        pedido.setObservaciones(observaciones);
    }

    @Override
    public Pedido getPedido() {
        return pedido;
    }
}