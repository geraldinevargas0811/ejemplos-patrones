package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.model.creador.*;
import co.edu.udistrital.model.director.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        int opcion;
        PedidoBuilder builder = new PedidoConcretoBuilder();
        PedidoDirector director = new PedidoDirector(builder);
        
        Pedido pedido = null;
        
        do {
            opcion = menu();
            switch (opcion) {
                case 1:
                	String cliente = vista.leerTexto("Nombre del cliente: ");
                	String productos = vista.leerTexto("Productos (ej: hamburguesa, papas, bebida): ");
                	double total = vista.leerDatoDecimal("Total del pedido ($): ");
                	String observaciones = vista.leerTexto("Observaciones: ");
                	director.construirPedido(cliente, productos, total, observaciones);
                	pedido = director.obtenerPedido();
                	
                	vista.mostrarInformacion("Pedido creado con éxito.");
                	break;
                case 2:
                	if (pedido == null) {
                        vista.mostrarInformacion("Debe crear un pedido primero.");
                    } else {
                        vista.mostrarInformacion(pedido.toString());
                    }
                	break;
                case 3:
                	vista.mostrarInformacion("Saliendo del sistema de pedidos...");
                	break;
                default: 
                	vista.mostrarInformacion("Opción inválida.");
            }
        } while (opcion != 3);
    }

    private int menu() {
        String texto = """
                === SISTEMA DE PEDIDOS ===
                1. Crear nuevo pedido
                2. Mostrar reporte del pedido
                3. Salir
                Seleccione una opción: """;
        return vista.leerDatoEntero(texto);
    }
}
