package co.edu.udistrital.model;

public class Ingrediente extends ComponenteReceta {
    private String nombre;
    private int calorias;

    public Ingrediente(String nombre, int calorias) {
        this.nombre = nombre;
        this.calorias = calorias;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getCalorias() {
        return calorias;
    }

    @Override
    public String mostrar(String prefijo) {
        return prefijo + "- " + nombre + " (" + calorias + " kcal)";
    }
}
