package co.edu.udistrital.model;

public abstract class ComponenteReceta {
    public abstract String getNombre();
    public abstract int getCalorias();
    public abstract String mostrar(String prefijo);
}
