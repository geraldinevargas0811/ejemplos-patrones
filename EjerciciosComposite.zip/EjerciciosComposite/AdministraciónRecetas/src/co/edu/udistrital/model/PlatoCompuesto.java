package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class PlatoCompuesto extends ComponenteReceta {
    private String nombre;
    private List<ComponenteReceta> componentes;

    public PlatoCompuesto(String nombre) {
        this.nombre = nombre;
        this.componentes = new ArrayList<>();
    }

    public void agregar(ComponenteReceta componente) {
        componentes.add(componente);
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getCalorias() {
        int total = 0;
        for (ComponenteReceta c : componentes) {
            total += c.getCalorias();
        }
        return total;
    }

    @Override
    public String mostrar(String prefijo) {
        StringBuilder sb = new StringBuilder();
        sb.append(prefijo).append("+ ").append(nombre)
          .append(" (").append(getCalorias()).append(" kcal)\n");
        for (ComponenteReceta c : componentes) {
            sb.append(c.mostrar(prefijo + "   ")).append("\n");
        }
        return sb.toString().trim();
    }
}