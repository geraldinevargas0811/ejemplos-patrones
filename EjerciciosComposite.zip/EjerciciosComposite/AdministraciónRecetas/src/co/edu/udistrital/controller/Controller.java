package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        ComponenteReceta tomate = new Ingrediente("Tomate", 20);
        ComponenteReceta cebolla = new Ingrediente("Cebolla", 15);
        ComponenteReceta ajo = new Ingrediente("Ajo", 5);
        ComponenteReceta carne = new Ingrediente("Carne molida", 200);
        ComponenteReceta pasta = new Ingrediente("Pasta", 300);
        ComponenteReceta queso = new Ingrediente("Queso mozzarella", 250);

        PlatoCompuesto salsa = new PlatoCompuesto("Salsa napolitana");
        salsa.agregar(tomate);
        salsa.agregar(cebolla);
        salsa.agregar(ajo);

        PlatoCompuesto lasagna = new PlatoCompuesto("Lasaña");
        lasagna.agregar(pasta);
        lasagna.agregar(carne);
        lasagna.agregar(salsa);
        lasagna.agregar(queso);

        String resultado = lasagna.mostrar("");
        vista.mostrarReceta(resultado);
    }
}
