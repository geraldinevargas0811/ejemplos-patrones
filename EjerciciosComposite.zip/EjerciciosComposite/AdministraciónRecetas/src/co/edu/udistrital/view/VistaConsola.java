package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarReceta(String resultado) {
        System.out.println("Receta generada:");
        System.out.println(resultado);
    }
}
