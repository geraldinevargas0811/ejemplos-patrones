package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class TareaCompuesta extends Tarea {
    private String nombre;
    private List<Tarea> subtareas;

    public TareaCompuesta(String nombre) {
        this.nombre = nombre;
        this.subtareas = new ArrayList<>();
    }

    public void agregar(Tarea tarea) {
        subtareas.add(tarea);
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getDuracion() {
        int total = 0;
        for (Tarea t : subtareas) {
            total += t.getDuracion();
        }
        return total;
    }

    @Override
    public String mostrar(String prefijo) {
        StringBuilder sb = new StringBuilder();
        sb.append(prefijo).append("+ ").append(nombre)
          .append(" (").append(getDuracion()).append(" h)\n");
        for (Tarea t : subtareas) {
            sb.append(t.mostrar(prefijo + "   ")).append("\n");
        }
        return sb.toString().trim();
    }
}