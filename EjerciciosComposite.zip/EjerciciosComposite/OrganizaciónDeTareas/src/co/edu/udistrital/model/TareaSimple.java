package co.edu.udistrital.model;

public class TareaSimple extends Tarea {
    private String nombre;
    private int duracionHoras;

    public TareaSimple(String nombre, int duracionHoras) {
        this.nombre = nombre;
        this.duracionHoras = duracionHoras;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getDuracion() {
        return duracionHoras;
    }

    @Override
    public String mostrar(String prefijo) {
        return prefijo + "- " + nombre + " (" + duracionHoras + " h)";
    }
}
