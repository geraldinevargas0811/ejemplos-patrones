package co.edu.udistrital.model;

public abstract class Tarea {
    public abstract String getNombre();
    public abstract int getDuracion();
    public abstract String mostrar(String prefijo);
}
