package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarPlan(String resultado) {
        System.out.println("----Plan de trabajo: ----");
        System.out.println(resultado);
    }
}
