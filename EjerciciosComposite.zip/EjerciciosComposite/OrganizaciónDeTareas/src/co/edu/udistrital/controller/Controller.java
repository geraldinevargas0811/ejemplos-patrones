package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void generarPlan() {
        Tarea cortar = new TareaSimple("Cortar materiales", 2);
        Tarea soldar = new TareaSimple("Soldar componentes", 3);
        Tarea probar = new TareaSimple("Prueba eléctrica", 1);
        Tarea pintar = new TareaSimple("Pintar estructura", 2);

        TareaCompuesta ensamblar = new TareaCompuesta("Ensamblaje mecánico");
        ensamblar.agregar(cortar);
        ensamblar.agregar(soldar);

        TareaCompuesta verificacion = new TareaCompuesta("Verificación general");
        verificacion.agregar(probar);
        verificacion.agregar(pintar);

        TareaCompuesta proyecto = new TareaCompuesta("Proyecto de estructura");
        proyecto.agregar(ensamblar);
        proyecto.agregar(verificacion);

        String resultado = proyecto.mostrar("");
        vista.mostrarPlan(resultado);
    }
}
