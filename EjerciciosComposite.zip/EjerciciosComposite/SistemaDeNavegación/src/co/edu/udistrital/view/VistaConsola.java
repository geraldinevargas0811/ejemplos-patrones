package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarMenu(String menu) {
        System.out.println("-----Menú del sitio web: -----");
        System.out.println(menu);
    }
}
