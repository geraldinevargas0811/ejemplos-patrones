package co.edu.udistrital.model;

public class Enlace extends ElementoNavegacion {
    private String nombre;
    private String url;

    public Enlace(String nombre, String url) {
        this.nombre = nombre;
        this.url = url;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String mostrar(String prefijo) {
        return prefijo + "- " + nombre + " [" + url + "]";
    }
}

