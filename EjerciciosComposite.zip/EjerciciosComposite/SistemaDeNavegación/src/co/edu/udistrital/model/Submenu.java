package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Submenu extends ElementoNavegacion {
    private String nombre;
    private List<ElementoNavegacion> elementos;

    public Submenu(String nombre) {
        this.nombre = nombre;
        this.elementos = new ArrayList<>();
    }

    public void agregar(ElementoNavegacion elemento) {
        elementos.add(elemento);
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String mostrar(String prefijo) {
        StringBuilder sb = new StringBuilder();
        sb.append(prefijo).append("+ ").append(nombre).append("\n");
        for (ElementoNavegacion e : elementos) {
            sb.append(e.mostrar(prefijo + "   ")).append("\n");
        }
        return sb.toString().trim();
    }
}

