package co.edu.udistrital.model;

public abstract class ElementoNavegacion {
    public abstract String getNombre();
    public abstract String mostrar(String prefijo);
}