package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void construirMenu() {
        ElementoNavegacion inicio = new Enlace("Inicio", "/inicio");
        ElementoNavegacion contacto = new Enlace("Contacto", "/contacto");

        Submenu productos = new Submenu("Productos");
        productos.agregar(new Enlace("Electrónica", "/productos/electronica"));
        productos.agregar(new Enlace("Ropa", "/productos/ropa"));
        productos.agregar(new Enlace("Hogar", "/productos/hogar"));

        Submenu usuario = new Submenu("Mi cuenta");
        usuario.agregar(new Enlace("Perfil", "/usuario/perfil"));
        usuario.agregar(new Enlace("Historial", "/usuario/historial"));

        Submenu menuPrincipal = new Submenu("Menú Principal");
        menuPrincipal.agregar(inicio);
        menuPrincipal.agregar(productos);
        menuPrincipal.agregar(usuario);
        menuPrincipal.agregar(contacto);

        String menuTexto = menuPrincipal.mostrar("");
        vista.mostrarMenu(menuTexto);
    }
}
