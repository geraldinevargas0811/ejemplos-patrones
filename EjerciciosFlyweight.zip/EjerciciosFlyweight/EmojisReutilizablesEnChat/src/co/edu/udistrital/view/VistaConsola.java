package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarMensaje(String texto) {
        System.out.println("[Chat]");
        System.out.println(texto);
    }
}
