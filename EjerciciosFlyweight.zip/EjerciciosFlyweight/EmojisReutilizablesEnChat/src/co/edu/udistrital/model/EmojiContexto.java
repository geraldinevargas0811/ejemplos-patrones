package co.edu.udistrital.model;

public class EmojiContexto {
	private String usuario;
    private String hora;
    private EmojiFlyweight emoticon;

    public EmojiContexto(String usuario, String hora, EmojiFlyweight emoticon) {
        this.usuario = usuario;
        this.hora = hora;
        this.emoticon = emoticon;
    }

    public String mostrar() {
        return emoticon.mostrar(usuario, hora);
    }
}
