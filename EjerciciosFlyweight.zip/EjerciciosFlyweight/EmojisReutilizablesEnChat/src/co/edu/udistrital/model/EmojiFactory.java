package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

public class EmojiFactory {
	private Map<String, EmojiFlyweight> mapa = new HashMap<>();

    public EmojiFlyweight obtenerEmoticon(String simbolo) {
        if (!mapa.containsKey(simbolo)) {
            mapa.put(simbolo, new EmojiConcreto(simbolo));
        }
        return mapa.get(simbolo);
    }
}
