package co.edu.udistrital.model;

public class EmojiConcreto implements EmojiFlyweight {
	
	private String simbolo;

    public EmojiConcreto(String simbolo) {
        this.simbolo = simbolo;
    }

	@Override
	public String mostrar(String usuario, String hora) {
		return usuario + " envió '" + simbolo + "' a las " + hora;
	}

}
