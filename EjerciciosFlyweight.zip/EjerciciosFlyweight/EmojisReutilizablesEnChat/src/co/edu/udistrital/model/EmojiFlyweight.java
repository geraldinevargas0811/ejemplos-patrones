package co.edu.udistrital.model;

public interface EmojiFlyweight {
	String mostrar(String usuario, String hora);
}
