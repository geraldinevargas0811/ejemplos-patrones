package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        EmojiFactory factory = new EmojiFactory();

        EmojiFlyweight sonrisa = factory.obtenerEmoticon("😊");
        EmojiFlyweight corazon = factory.obtenerEmoticon("❤️");
        EmojiFlyweight lagrima = factory.obtenerEmoticon("😢");

        EmojiContexto e1 = new EmojiContexto("Laura", "10:00 AM", sonrisa);
        EmojiContexto e2 = new EmojiContexto("Pedro", "10:01 AM", corazon);
        EmojiContexto e3 = new EmojiContexto("Laura", "10:02 AM", sonrisa);
        EmojiContexto e4 = new EmojiContexto("María", "10:03 AM", lagrima);

        vista.mostrarMensaje(e1.mostrar());
        vista.mostrarMensaje(e2.mostrar());
        vista.mostrarMensaje(e3.mostrar());
        vista.mostrarMensaje(e4.mostrar());
    }
}
