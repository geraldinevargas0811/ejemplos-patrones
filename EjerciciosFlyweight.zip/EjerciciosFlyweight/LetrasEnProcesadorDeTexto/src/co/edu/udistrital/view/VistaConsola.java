package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarTexto(String texto) {
        System.out.println("[Visualización del texto]");
        System.out.println(texto);
    }
}
