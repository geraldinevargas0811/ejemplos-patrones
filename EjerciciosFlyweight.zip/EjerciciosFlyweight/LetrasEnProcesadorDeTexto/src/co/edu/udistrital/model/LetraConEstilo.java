package co.edu.udistrital.model;

public class LetraConEstilo {
    private int x, y;
    private int tamano;
    private String color;
    private LetraFlyweight letra;

    public LetraConEstilo(int x, int y, int tamano, String color, LetraFlyweight letra) {
        this.x = x;
        this.y = y;
        this.tamano = tamano;
        this.color = color;
        this.letra = letra;
    }

    public String mostrar() {
        return letra.mostrar(x, y, tamano, color);
    }
}
