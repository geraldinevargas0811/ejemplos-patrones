package co.edu.udistrital.model;

public class LetraConcreta implements LetraFlyweight {
    private char caracter;

    public LetraConcreta(char caracter) {
        this.caracter = caracter;
    }

    @Override
    public String mostrar(int x, int y, int tamano, String color) {
        return "Letra '" + caracter + "' en (" + x + "," + y + ") Tamaño: " + tamano + " Color: " + color;
    }
}
