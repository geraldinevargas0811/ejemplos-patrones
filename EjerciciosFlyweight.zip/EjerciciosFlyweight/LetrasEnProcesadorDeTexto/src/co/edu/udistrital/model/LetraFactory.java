package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

public class LetraFactory {
    private Map<Character, LetraFlyweight> letras = new HashMap<>();

    public LetraFlyweight obtenerLetra(char c) {
        if (!letras.containsKey(c)) {
            letras.put(c, new LetraConcreta(c));
        }
        return letras.get(c);
    }
}
