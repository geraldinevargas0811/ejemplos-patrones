package co.edu.udistrital.model;

public interface LetraFlyweight {
	String mostrar(int x, int y, int tamano, String color);
}
