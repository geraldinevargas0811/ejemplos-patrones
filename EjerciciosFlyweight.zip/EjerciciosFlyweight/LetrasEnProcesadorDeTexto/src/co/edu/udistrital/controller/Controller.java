package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        LetraFactory factory = new LetraFactory();

        LetraFlyweight l1 = factory.obtenerLetra('H');
        LetraFlyweight l2 = factory.obtenerLetra('o');
        LetraFlyweight l3 = factory.obtenerLetra('l');
        LetraFlyweight l4 = factory.obtenerLetra('a');

        LetraConEstilo c1 = new LetraConEstilo(0, 0, 12, "negro", l1);
        LetraConEstilo c2 = new LetraConEstilo(10, 0, 12, "negro", l2);
        LetraConEstilo c3 = new LetraConEstilo(20, 0, 12, "negro", l3);
        LetraConEstilo c4 = new LetraConEstilo(30, 0, 12, "rojo", l4); // mismo flyweight, distinto color

        vista.mostrarTexto(c1.mostrar());
        vista.mostrarTexto(c2.mostrar());
        vista.mostrarTexto(c3.mostrar());
        vista.mostrarTexto(c4.mostrar());
    }
}
