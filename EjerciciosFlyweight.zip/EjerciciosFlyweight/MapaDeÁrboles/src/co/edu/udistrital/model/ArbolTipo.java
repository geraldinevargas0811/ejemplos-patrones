package co.edu.udistrital.model;

public class ArbolTipo implements ArbolFlyweight {
    private String tipo;
    private String color;

    public ArbolTipo(String tipo, String color) {
        this.tipo = tipo;
        this.color = color;
    }

    @Override
    public String mostrar(int x, int y) {
        return "Árbol de tipo '" + tipo + "' y color '" + color + "' plantado en (" + x + ", " + y + ")";
    }
}

