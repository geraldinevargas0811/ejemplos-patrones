package co.edu.udistrital.model;

public interface ArbolFlyweight {
	String mostrar(int x, int y);
}
