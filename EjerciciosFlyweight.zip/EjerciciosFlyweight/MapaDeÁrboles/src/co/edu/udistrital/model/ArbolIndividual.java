package co.edu.udistrital.model;

public class ArbolIndividual {
    private int x;
    private int y;
    private ArbolFlyweight arbol;

    public ArbolIndividual(int x, int y, ArbolFlyweight arbol) {
        this.x = x;
        this.y = y;
        this.arbol = arbol;
    }

    public String mostrar() {
        return arbol.mostrar(x, y);
    }
}
