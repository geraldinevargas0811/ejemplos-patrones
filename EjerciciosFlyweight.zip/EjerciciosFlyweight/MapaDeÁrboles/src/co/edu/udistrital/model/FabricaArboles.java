package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

public class FabricaArboles {
    private Map<String, ArbolFlyweight> arboles = new HashMap<>();

    public ArbolFlyweight obtenerArbol(String tipo, String color) {
        String clave = tipo + "-" + color;
        if (!arboles.containsKey(clave)) {
            arboles.put(clave, new ArbolTipo(tipo, color));
        }
        return arboles.get(clave);
    }
}

