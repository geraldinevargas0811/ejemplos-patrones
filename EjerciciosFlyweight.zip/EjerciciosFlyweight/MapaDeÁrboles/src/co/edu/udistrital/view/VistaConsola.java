package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrarMensaje(String mensaje) {
        System.out.println("[Mapa de Ciudad]");
        System.out.println(mensaje);
    }
}
