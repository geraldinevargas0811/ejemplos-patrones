package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        FabricaArboles fabrica = new FabricaArboles();

        ArbolFlyweight robleVerde = fabrica.obtenerArbol("Roble", "Verde");
        ArbolFlyweight pinoVerde = fabrica.obtenerArbol("Pino", "Verde");
        ArbolFlyweight robleRojo = fabrica.obtenerArbol("Roble", "Rojo");

        ArbolIndividual a1 = new ArbolIndividual(10, 20, robleVerde);
        ArbolIndividual a2 = new ArbolIndividual(30, 40, robleVerde);
        ArbolIndividual a3 = new ArbolIndividual(50, 60, pinoVerde);
        ArbolIndividual a4 = new ArbolIndividual(70, 80, robleRojo);

        vista.mostrarMensaje(a1.mostrar());
        vista.mostrarMensaje(a2.mostrar());
        vista.mostrarMensaje(a3.mostrar());
        vista.mostrarMensaje(a4.mostrar());
    }
}

