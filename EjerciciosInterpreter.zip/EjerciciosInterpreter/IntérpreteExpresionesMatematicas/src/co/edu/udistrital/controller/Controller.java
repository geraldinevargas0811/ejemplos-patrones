package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        try {
            Expresion suma = new ExpresionSuma(new ExpresionConstante(5), new ExpresionConstante(3));
            Expresion resta = new ExpresionResta(new ExpresionConstante(10), new ExpresionConstante(2));
            Expresion mult = new ExpresionMultiplicacion(new ExpresionConstante(4), new ExpresionConstante(2));
            Expresion div = new ExpresionDivision(new ExpresionConstante(20), new ExpresionConstante(4));

            vista.mostrar("Resultado de 5 + 3 = " + suma.interpretar());
            vista.mostrar("Resultado de 10 - 2 = " + resta.interpretar());
            vista.mostrar("Resultado de 4 * 2 = " + mult.interpretar());
            vista.mostrar("Resultado de 20 / 4 = " + div.interpretar());

        } catch (ArithmeticException e) {
            vista.mostrar("Error: " + e.getMessage());
        }
    }
}
