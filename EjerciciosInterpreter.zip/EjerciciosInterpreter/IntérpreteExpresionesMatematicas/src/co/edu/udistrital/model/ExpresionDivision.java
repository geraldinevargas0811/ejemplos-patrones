package co.edu.udistrital.model;

public class ExpresionDivision implements Expresion {
    private Expresion izquierda, derecha;

    public ExpresionDivision(Expresion izquierda, Expresion derecha) {
        this.izquierda = izquierda;
        this.derecha = derecha;
    }

    @Override
    public int interpretar() {
        int divisor = derecha.interpretar();
        if (divisor == 0) {
            throw new ArithmeticException("División por cero");
        }
        return izquierda.interpretar() / divisor;
    }
}
