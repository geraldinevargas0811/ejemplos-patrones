package co.edu.udistrital.model;

public class ExpresionResta implements Expresion {
    private Expresion izquierda, derecha;

    public ExpresionResta(Expresion izquierda, Expresion derecha) {
        this.izquierda = izquierda;
        this.derecha = derecha;
    }

    @Override
    public int interpretar() {
        return izquierda.interpretar() - derecha.interpretar();
    }
}

