package co.edu.udistrital.model;

public class ExpresionConstante implements Expresion {
    private int valor;

    public ExpresionConstante(int valor) {
        this.valor = valor;
    }

    @Override
    public int interpretar() {
        return valor;
    }
}
