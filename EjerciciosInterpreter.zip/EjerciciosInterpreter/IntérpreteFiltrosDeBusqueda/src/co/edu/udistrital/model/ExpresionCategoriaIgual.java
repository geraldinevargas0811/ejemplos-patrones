package co.edu.udistrital.model;

public class ExpresionCategoriaIgual implements Expresion {
    private String categoriaBuscada;

    public ExpresionCategoriaIgual(String categoriaBuscada) {
        this.categoriaBuscada = categoriaBuscada;
    }

    @Override
    public boolean interpretar(Producto p) {
        return p.getCategoria().equalsIgnoreCase(categoriaBuscada);
    }
}
