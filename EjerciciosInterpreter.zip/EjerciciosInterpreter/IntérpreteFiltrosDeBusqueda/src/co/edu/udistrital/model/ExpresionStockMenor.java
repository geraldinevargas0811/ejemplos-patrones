package co.edu.udistrital.model;

public class ExpresionStockMenor implements Expresion {
    private int cantidad;

    public ExpresionStockMenor(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public boolean interpretar(Producto p) {
        return p.getStock() < cantidad;
    }
}
