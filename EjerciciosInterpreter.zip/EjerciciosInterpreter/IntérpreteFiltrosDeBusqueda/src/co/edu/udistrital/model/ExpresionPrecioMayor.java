package co.edu.udistrital.model;

public class ExpresionPrecioMayor implements Expresion {
    private double valor;

    public ExpresionPrecioMayor(double valor) {
        this.valor = valor;
    }

    @Override
    public boolean interpretar(Producto p) {
        return p.getPrecio() > valor;
    }
}
