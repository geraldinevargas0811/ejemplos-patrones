package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.ArrayList;
import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        List<Producto> productos = new ArrayList<>();
        productos.add(new Producto("Laptop Lenovo", 2500, "Electrónica", 15));
        productos.add(new Producto("Silla ergonómica", 450, "Oficina", 5));
        productos.add(new Producto("Smartphone", 900, "Electrónica", 30));
        productos.add(new Producto("Cuaderno", 10, "Papelería", 80));

        Expresion filtro1 = new ExpresionPrecioMayor(500);
        Expresion filtro2 = new ExpresionCategoriaIgual("Electrónica");
        Expresion filtro3 = new ExpresionStockMenor(20);

        vista.mostrar("🔎 Productos con precio > 500:");
        for (Producto p : productos) {
            if (filtro1.interpretar(p)) {
                vista.mostrar("- " + p.getNombre());
            }
        }

        vista.mostrar("\n🔎 Productos en categoría 'Electrónica':");
        for (Producto p : productos) {
            if (filtro2.interpretar(p)) {
                vista.mostrar("- " + p.getNombre());
            }
        }

        vista.mostrar("\n🔎 Productos con stock < 20:");
        for (Producto p : productos) {
            if (filtro3.interpretar(p)) {
                vista.mostrar("- " + p.getNombre());
            }
        }
    }
}
