package co.edu.udistrital.model;

public class ExpresionTriangulo implements Expresion {

    @Override
    public String interpretar(Contexto contexto) {
        if (contexto.getComando().equalsIgnoreCase("DIBUJAR TRIANGULO")) {
            return "🔺\n🔺🔺\n🔺🔺🔺";
        }
        return "";
    }
}

