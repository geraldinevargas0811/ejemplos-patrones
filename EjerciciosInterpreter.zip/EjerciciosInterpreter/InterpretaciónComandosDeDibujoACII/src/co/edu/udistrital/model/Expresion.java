package co.edu.udistrital.model;

public interface Expresion {
	String interpretar(Contexto contexto);
}
