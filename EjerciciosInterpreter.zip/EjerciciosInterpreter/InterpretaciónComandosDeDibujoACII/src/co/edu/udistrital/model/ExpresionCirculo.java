package co.edu.udistrital.model;

public class ExpresionCirculo implements Expresion {

    @Override
    public String interpretar(Contexto contexto) {
        if (contexto.getComando().equalsIgnoreCase("DIBUJAR CIRCULO")) {
            return " ⭕ ";
        }
        return "";
    }
}

