package co.edu.udistrital.model;

public class ExpresionCuadrado implements Expresion {

    @Override
    public String interpretar(Contexto contexto) {
        if (contexto.getComando().equalsIgnoreCase("DIBUJAR CUADRADO")) {
            return "⬜\n⬜\n⬜";
        }
        return "";
    }
}
