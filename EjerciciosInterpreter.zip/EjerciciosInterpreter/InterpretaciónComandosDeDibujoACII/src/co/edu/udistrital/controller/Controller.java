package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.ArrayList;
import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        List<Expresion> interpretes = new ArrayList<>();
        interpretes.add(new ExpresionCuadrado());
        interpretes.add(new ExpresionTriangulo());
        interpretes.add(new ExpresionCirculo());

        String[] comandos = {
            "DIBUJAR CIRCULO",
            "DIBUJAR CUADRADO",
            "DIBUJAR TRIANGULO",
            "DIBUJAR HEXAGONO" // comando no interpretado
        };

        for (String comando : comandos) {
            Contexto contexto = new Contexto(comando);
            boolean interpretado = false;

            for (Expresion expresion : interpretes) {
                String resultado = expresion.interpretar(contexto);
                if (!resultado.isEmpty()) {
                    vista.mostrar("▶ " + comando + ":\n" + resultado + "\n");
                    interpretado = true;
                    break;
                }
            }

            if (!interpretado) {
                vista.mostrar("⚠ Comando no reconocido: " + comando + "\n");
            }
        }
    }
}

