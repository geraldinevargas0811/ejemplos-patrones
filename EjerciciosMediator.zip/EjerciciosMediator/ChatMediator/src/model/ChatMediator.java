package model;

public interface ChatMediator {
    String sendMessage(User sender, String message);
}