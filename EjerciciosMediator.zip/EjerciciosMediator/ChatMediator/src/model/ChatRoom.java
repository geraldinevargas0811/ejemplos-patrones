package model;

import java.util.ArrayList;
import java.util.List;

public class ChatRoom implements ChatMediator {
    private List<User> users;

    public ChatRoom() {
        this.users = new ArrayList<>();
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void removeUser(User user) {
        users.remove(user);
    }

    @Override
    public String sendMessage(User sender, String message) {
    	String output = "";
        for (User user : users) {
            if (user != sender) {
                output += user.receiveMessage(sender.getName() + ": " + message)+"\n";
            }
        }
		return output;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }
}