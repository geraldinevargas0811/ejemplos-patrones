package view;

import java.util.Scanner;

public class ConsoleView {
    private Scanner scanner;

    public ConsoleView() {
        this.scanner = new Scanner(System.in);
    }

    public void print(String message) {
        System.out.println(message);
    }

    public int readInt(String message){
        print(message);
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                print("Invalid input. Please enter a valid integer.");
            }
        }
    }

    public String readString(String message){
        print(message);
        String input = scanner.nextLine();
        if (input.isEmpty()) {
            print("Input cannot be empty. Please try again.");
            return readString(message);
        }
        return input;
    }
}
