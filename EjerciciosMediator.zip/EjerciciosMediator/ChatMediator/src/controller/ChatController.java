package controller;

import model.ChatRoom;
import model.User;
import view.ConsoleView;

import java.util.ArrayList;
import java.util.List;

public class ChatController {
    private ChatRoom chatRoom;
    private ConsoleView view;

    public ChatController() {
        this.chatRoom = new ChatRoom();
        this.view = new ConsoleView();
    }

    public void run() {
        view.print("Welcome to the Chat Room!");
        
        int numUsers = view.readInt("Enter number of users: ");
        
        for (int i = 0; i < numUsers; i++) {
            String userName = view.readString("Enter name for user " + (i + 1) + ": ");
            User user = new User(userName, chatRoom);
            chatRoom.addUser(user);
        }
        
        view.print("Chat room initialized with " + numUsers + " users.");
        
        while (true) {
            displayUsers();
            int senderIndex = view.readInt("Select sender (0 to exit): ");
            
            if (senderIndex == 0) {
                view.print("Goodbye!");
                break;
            }
            
            if (senderIndex < 1 || senderIndex > chatRoom.getUsers().size()) {
                view.print("Invalid user selection.");
                continue;
            }
            
            String message = view.readString("Enter message: ");
            User sender = chatRoom.getUsers().get(senderIndex - 1);
            view.print(sender.send(message));
            view.print("");
        }
    }
    
    private void displayUsers() {
        view.print("Available users:");
        for (int i = 0; i < chatRoom.getUsers().size(); i++) {
            view.print((i + 1) + ". " + chatRoom.getUsers().get(i).getName());
        }
    }

    public ChatRoom getChatRoom() {
        return chatRoom;
    }

    public void setChatRoom(ChatRoom chatRoom) {
        this.chatRoom = chatRoom;
    }

    public ConsoleView getView() {
        return view;
    }

    public void setView(ConsoleView view) {
        this.view = view;
    }
}