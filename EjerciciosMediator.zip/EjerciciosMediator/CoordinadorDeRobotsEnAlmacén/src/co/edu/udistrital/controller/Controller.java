package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Mediador coordinador = new CoordinadorAlmacen();

        Robot carga = new RobotCarga(coordinador);
        Robot inspeccion = new RobotInspeccion(coordinador);
        Robot embalaje = new RobotEmbalaje(coordinador);

        coordinador.registrar(carga);
        coordinador.registrar(inspeccion);
        coordinador.registrar(embalaje);

        vista.mostrar("🔄 Robot Inspección informa:");
        List<String> mensajes = inspeccion.enviar("Producto aprobado, enviar a embalaje.");
        for (String m : mensajes) {
            vista.mostrar(m);
        }

        vista.mostrar("🔄 Robot Carga informa:");
        mensajes = carga.enviar("Producto listo, esperando inspección.");
        for (String m : mensajes) {
            vista.mostrar(m);
        }
    }
}
