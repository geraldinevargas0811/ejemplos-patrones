package co.edu.udistrital.model;

import java.util.List;

public interface Mediador {
    void registrar(Robot r);
    List<String> enviar(String mensaje, Robot emisor);
}
