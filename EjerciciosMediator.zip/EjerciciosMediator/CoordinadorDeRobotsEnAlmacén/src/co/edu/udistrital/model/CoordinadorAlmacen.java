package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class CoordinadorAlmacen implements Mediador {
    private List<Robot> robots;

    public CoordinadorAlmacen() {
        robots = new ArrayList<>();
    }

    @Override
    public void registrar(Robot r) {
        robots.add(r);
    }

    @Override
    public List<String> enviar(String mensaje, Robot emisor) {
        List<String> respuestas = new ArrayList<>();
        for (Robot r : robots) {
            if (!r.equals(emisor)) {
                respuestas.add(r.recibir("De " + emisor.getNombre() + ": " + mensaje));
            }
        }
        return respuestas;
    }
}
