package co.edu.udistrital.model;

import java.util.List;

public abstract class Robot {
    protected String nombre;
    protected Mediador mediador;

    public Robot(String nombre, Mediador mediador) {
        this.nombre = nombre;
        this.mediador = mediador;
    }

    public String getNombre() {
        return nombre;
    }

    public List<String> enviar(String mensaje) {
        return mediador.enviar(mensaje, this);
    }

    public abstract String recibir(String mensaje);
}

