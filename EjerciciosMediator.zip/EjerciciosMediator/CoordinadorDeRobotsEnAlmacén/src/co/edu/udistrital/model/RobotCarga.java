package co.edu.udistrital.model;

public class RobotCarga extends Robot {
    public RobotCarga(Mediador mediador) {
        super("Robot Carga", mediador);
    }

    @Override
    public String recibir(String mensaje) {
        return "📦 Robot Carga recibió: " + mensaje;
    }
}

