package co.edu.udistrital.model;

public class RobotInspeccion extends Robot {
    public RobotInspeccion(Mediador mediador) {
        super("Robot Inspección", mediador);
    }

    @Override
    public String recibir(String mensaje) {
        return "🔍 Robot Inspección recibió: " + mensaje;
    }
}
