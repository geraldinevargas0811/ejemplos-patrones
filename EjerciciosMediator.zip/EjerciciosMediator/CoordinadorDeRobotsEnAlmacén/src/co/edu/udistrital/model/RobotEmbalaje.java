package co.edu.udistrital.model;

public class RobotEmbalaje extends Robot {
    public RobotEmbalaje(Mediador mediador) {
        super("Robot Embalaje", mediador);
    }

    @Override
    public String recibir(String mensaje) {
        return "📦🛠️ Robot Embalaje recibió: " + mensaje;
    }
}

