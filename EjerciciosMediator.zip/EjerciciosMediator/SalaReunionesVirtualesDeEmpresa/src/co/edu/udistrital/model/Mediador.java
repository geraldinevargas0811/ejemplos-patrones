package co.edu.udistrital.model;

import java.util.List;

public interface Mediador {
    List<String> enviarMensaje(String mensaje, Departamento emisor);
    void registrar(Departamento depto);
}

