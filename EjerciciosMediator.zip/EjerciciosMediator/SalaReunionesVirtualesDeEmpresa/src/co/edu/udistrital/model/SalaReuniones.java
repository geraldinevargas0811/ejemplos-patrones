package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class SalaReuniones implements Mediador {
    private List<Departamento> departamentos;

    public SalaReuniones() {
        departamentos = new ArrayList<>();
    }

    @Override
    public void registrar(Departamento depto) {
        departamentos.add(depto);
    }

    @Override
    public List<String> enviarMensaje(String mensaje, Departamento emisor) {
        List<String> respuestas = new ArrayList<>();
        for (Departamento d : departamentos) {
            if (!d.equals(emisor)) {
                respuestas.add(d.recibir("Mensaje de " + emisor.getNombre() + ": " + mensaje));
            }
        }
        return respuestas;
    }
}
