package co.edu.udistrital.model;

public class Tecnologia extends Departamento {
    public Tecnologia(Mediador mediador) {
        super("Tecnología", mediador);
    }

    @Override
    public String recibir(String mensaje) {
        return "💻 Tecnología recibió: " + mensaje;
    }
}
