package co.edu.udistrital.model;

public class RecursosHumanos extends Departamento {
    public RecursosHumanos(Mediador mediador) {
        super("Recursos Humanos", mediador);
    }

    @Override
    public String recibir(String mensaje) {
        return "👥 Recursos Humanos recibió: " + mensaje;
    }
}

