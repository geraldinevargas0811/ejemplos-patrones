package co.edu.udistrital.model;

import java.util.List;

public abstract class Departamento {
    protected String nombre;
    protected Mediador mediador;

    public Departamento(String nombre, Mediador mediador) {
        this.nombre = nombre;
        this.mediador = mediador;
    }

    public String getNombre() {
        return nombre;
    }

    public List<String> enviar(String mensaje) {
        return mediador.enviarMensaje(mensaje, this);
    }

    public abstract String recibir(String mensaje);
}
