package co.edu.udistrital.model;

public class Marketing extends Departamento {
    public Marketing(Mediador mediador) {
        super("Marketing", mediador);
    }

    @Override
    public String recibir(String mensaje) {
        return "📣 Marketing recibió: " + mensaje;
    }
}
