package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

import java.util.List;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        Mediador sala = new SalaReuniones();

        Departamento tecnologia = new Tecnologia(sala);
        Departamento rh = new RecursosHumanos(sala);
        Departamento marketing = new Marketing(sala);

        sala.registrar(tecnologia);
        sala.registrar(rh);
        sala.registrar(marketing);

        vista.mostrar("🗨️ Tecnología envía un mensaje a todos:");
        List<String> respuestas = tecnologia.enviar("Hemos actualizado el servidor.");
        for (String r : respuestas) {
            vista.mostrar(r);
        }

        vista.mostrar("🗨️ Marketing responde:");
        respuestas = marketing.enviar("Gracias, lanzaremos la campaña.");
        for (String r : respuestas) {
            vista.mostrar(r);
        }
    }
}

