package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        PreparadorBebida bebida;

        bebida = new Cafe();
        vista.mostrar("☕ Café:\n" + bebida.preparar());

        bebida = new Te();
        vista.mostrar("\n🍵 Té:\n" + bebida.preparar());

        bebida = new Chocolate();
        vista.mostrar("\n🍫 Chocolate:\n" + bebida.preparar());
    }
}
