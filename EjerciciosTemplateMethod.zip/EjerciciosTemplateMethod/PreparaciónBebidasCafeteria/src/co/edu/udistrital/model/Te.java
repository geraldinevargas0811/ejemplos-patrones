package co.edu.udistrital.model;

public class Te extends PreparadorBebida {

    @Override
    protected String prepararIngrediente() {
        return "🍃 Infusionar la bolsa de té";
    }

    @Override
    protected String agregarComplementos() {
        return "🍯 Agregar miel y limón";
    }
}

