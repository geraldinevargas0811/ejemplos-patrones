package co.edu.udistrital.model;

public abstract class PreparadorBebida {
    public final String preparar() {
        StringBuilder sb = new StringBuilder();
        sb.append(hervirAgua()).append("\n");
        sb.append(prepararIngrediente()).append("\n");
        sb.append(verterEnTaza()).append("\n");
        sb.append(agregarComplementos());
        return sb.toString();
    }

    protected String hervirAgua() {
        return "💧 Hervir agua";
    }

    protected String verterEnTaza() {
        return "☕ Verter en la taza";
    }

    protected abstract String prepararIngrediente();
    protected abstract String agregarComplementos();
}
