package co.edu.udistrital.model;

public class Chocolate extends PreparadorBebida {

    @Override
    protected String prepararIngrediente() {
        return "🍫 Derretir el chocolate en polvo";
    }

    @Override
    protected String agregarComplementos() {
        return "🍬 Agregar crema batida";
    }
}
