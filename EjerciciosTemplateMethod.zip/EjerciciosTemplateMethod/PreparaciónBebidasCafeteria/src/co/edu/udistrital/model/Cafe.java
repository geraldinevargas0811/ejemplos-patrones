package co.edu.udistrital.model;

public class Cafe extends PreparadorBebida {

    @Override
    protected String prepararIngrediente() {
        return "☕ Preparar café molido";
    }

    @Override
    protected String agregarComplementos() {
        return "🧂 Agregar azúcar y leche";
    }
}
