package co.edu.udistrital.model;

public class RegistroWebinar extends RegistroEvento {

    @Override
    protected boolean validar(String usuario) {
        return usuario != null && usuario.contains("@");
    }

    @Override
    protected String notificar(String usuario, String codigo) {
        return "📧 Se ha enviado un enlace de acceso al correo " + usuario + ". Código: " + codigo;
    }
}
