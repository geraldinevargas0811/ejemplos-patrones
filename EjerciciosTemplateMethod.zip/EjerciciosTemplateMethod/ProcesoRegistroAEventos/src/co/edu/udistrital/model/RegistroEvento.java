package co.edu.udistrital.model;

public abstract class RegistroEvento {
    public final String registrar(String usuario) {
        if (!validar(usuario)) {
            return "❌ Registro denegado para: " + usuario;
        }
        String codigo = generarCodigo();
        return notificar(usuario, codigo);
    }

    protected abstract boolean validar(String usuario);
    protected String generarCodigo() {
        return "EVT" + (int)(Math.random() * 10000);
    }
    protected String notificar(String usuario, String codigo) {
        return "✅ Registro exitoso para " + usuario + ". Código: " + codigo;
    }
}
