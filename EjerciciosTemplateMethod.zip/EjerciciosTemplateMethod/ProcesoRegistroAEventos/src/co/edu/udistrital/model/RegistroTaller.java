package co.edu.udistrital.model;

public class RegistroTaller extends RegistroEvento {

    @Override
    protected boolean validar(String usuario) {
        return usuario != null && !usuario.isBlank();
    }

    @Override
    protected String generarCodigo() {
        return "TLR-" + System.currentTimeMillis();
    }
}
