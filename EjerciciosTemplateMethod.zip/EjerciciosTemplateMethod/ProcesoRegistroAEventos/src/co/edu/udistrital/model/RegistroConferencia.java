package co.edu.udistrital.model;

public class RegistroConferencia extends RegistroEvento {

    @Override
    protected boolean validar(String usuario) {
        return usuario != null && usuario.length() > 3;
    }

    @Override
    protected String notificar(String usuario, String codigo) {
        return "📢 Estimado " + usuario + ", estás inscrito a la conferencia. Código: " + codigo;
    }
}

