package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        RegistroEvento conferencia = new RegistroConferencia();
        RegistroEvento taller = new RegistroTaller();
        RegistroEvento webinar = new RegistroWebinar();

        vista.mostrar(conferencia.registrar("Carlos"));
        vista.mostrar(taller.registrar("Ana"));
        vista.mostrar(webinar.registrar("ana@email.com"));
        vista.mostrar(webinar.registrar("usuario_sin_correo"));
    }
}
