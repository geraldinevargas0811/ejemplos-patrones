package co.edu.udistrital.model;

public class PublicadorTwitter extends PublicadorRedSocial {

    @Override
    protected String crearContenido() {
        return "📝 Tweet: \"¡Hola mundo en 280 caracteres!\"";
    }
}
