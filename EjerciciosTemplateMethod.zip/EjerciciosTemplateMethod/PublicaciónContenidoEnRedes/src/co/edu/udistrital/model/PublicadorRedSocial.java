package co.edu.udistrital.model;

public abstract class PublicadorRedSocial {

    public final String publicar(String usuario) {
        if (!autenticar(usuario)) {
            return "❌ Falló la autenticación para " + usuario;
        }
        String contenido = crearContenido();
        String resultado = subirContenido(contenido);
        return resultado + "\n" + notificar(usuario);
    }

    protected boolean autenticar(String usuario) {
        return usuario != null && !usuario.isBlank();
    }

    protected abstract String crearContenido();

    protected String subirContenido(String contenido) {
        return "📤 Contenido subido: " + contenido;
    }

    protected String notificar(String usuario) {
        return "📩 Notificación enviada a " + usuario;
    }
}
