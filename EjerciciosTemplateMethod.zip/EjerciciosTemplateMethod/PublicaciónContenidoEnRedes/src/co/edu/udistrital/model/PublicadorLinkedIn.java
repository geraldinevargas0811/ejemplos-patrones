package co.edu.udistrital.model;

public class PublicadorLinkedIn extends PublicadorRedSocial {

    @Override
    protected boolean autenticar(String usuario) {
        return usuario != null && usuario.endsWith("@empresa.com");
    }

    @Override
    protected String crearContenido() {
        return "💼 Publicación profesional: \"5 claves para mejorar tu perfil\"";
    }

    @Override
    protected String subirContenido(String contenido) {
        return "🔗 Contenido corporativo subido: " + contenido;
    }
}

