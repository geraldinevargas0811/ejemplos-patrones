package co.edu.udistrital.model;

public class PublicadorInstagram extends PublicadorRedSocial {

    @Override
    protected String crearContenido() {
        return "📸 Imagen con filtro #Naturaleza";
    }

    @Override
    protected String notificar(String usuario) {
        return "📱 Notificación vía app Instagram para " + usuario;
    }
}
