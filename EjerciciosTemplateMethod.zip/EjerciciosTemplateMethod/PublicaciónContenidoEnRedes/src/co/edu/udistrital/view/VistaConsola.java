package co.edu.udistrital.view;

public class VistaConsola {
	public void mostrar(String mensaje) {
        System.out.println("---- Publicador de Contenido ----");
        System.out.println(mensaje);
    }
}
