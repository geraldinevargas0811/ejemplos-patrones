package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;
import co.edu.udistrital.model.*;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void ejecutar() {
        PublicadorRedSocial publicador;

        publicador = new PublicadorInstagram();
        vista.mostrar("Instagram:\n" + publicador.publicar("luisa123"));

        publicador = new PublicadorTwitter();
        vista.mostrar("\nTwitter:\n" + publicador.publicar("andres_dev"));

        publicador = new PublicadorLinkedIn();
        vista.mostrar("\nLinkedIn válido:\n" + publicador.publicar("juan@empresa.com"));
        vista.mostrar("\nLinkedIn inválido:\n" + publicador.publicar("invitado@gmail.com"));
    }
}
